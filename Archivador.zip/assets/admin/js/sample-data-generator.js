jQuery(document).ready(function(n){let a=!1;const l=n("#generate-all"),g=n("#generate-destinations"),p=n("#generate-tours"),f=n("#generate-pages"),u=n("#clean-data"),i=n("#generation-progress"),s=n(".progress-fill"),h=n("#progress-text"),c=n("#generation-controls"),d=n("#generation-results"),m=n("#results-content"),v=n("#reset-generator");function w(e,o=0){c.hide(),i.show(),h.text(e),s.css("width",o+"%")}function k(e){i.hide();let o='<div class="notice notice-success"><h4>¡Generación completada!</h4>';e.destinations&&(o+=`<p><strong>Destinos:</strong> ${e.destinations.created} creados de ${e.destinations.total}</p>`),e.tours&&(o+=`<p><strong>Tours:</strong> ${e.tours.created} creados de ${e.tours.total}</p>`),e.pages&&(o+=`<p><strong>Páginas:</strong> ${e.pages.created} creadas de ${e.pages.total}</p>`,e.pages.pages_created&&e.pages.pages_created.length>0&&(o+='<div style="margin-top: 10px;"><strong>Páginas creadas:</strong><ul style="margin-left: 20px;">',e.pages.pages_created.forEach(t=>{o+=`<li><a href="${t.url}" target="_blank">${t.title}</a> (ID: ${t.id})</li>`}),o+="</ul></div>")),e.menu&&(o+=`<p><strong>Menú:</strong> ${e.menu.created?"Creado exitosamente":"Ya existía"}</p>`),e.cleaned&&(o+="<h4>Datos eliminados:</h4>",o+=`<p>Tours: ${e.cleaned.tours}, Páginas: ${e.cleaned.pages}, Destinos: ${e.cleaned.destinations}</p>`),o+="</div>",e.destinations&&e.destinations.errors.length>0&&(o+='<div class="notice notice-warning"><h4>Advertencias en destinos:</h4><ul>',e.destinations.errors.forEach(t=>{o+=`<li>${t}</li>`}),o+="</ul></div>"),e.tours&&e.tours.errors.length>0&&(o+='<div class="notice notice-warning"><h4>Advertencias en tours:</h4><ul>',e.tours.errors.forEach(t=>{o+=`<li>${t}</li>`}),o+="</ul></div>"),m.html(o),d.show(),a=!1}function x(e){i.hide(),c.show();const o=`<div class="notice notice-error"><h4>Error</h4><p>${e}</p></div>`;m.html(o),d.show(),a=!1}function r(e,o){if(a){alert("Ya hay una generación en progreso. Por favor, espera.");return}a=!0,w(o,10),n.ajax({url:sampleData.ajax_url,type:"POST",data:{action:"generate_sample_data",action_type:e,nonce:sampleData.nonce},beforeSend:function(){s.css("width","30%")},success:function(t){s.css("width","100%"),h.text("¡Completado!"),setTimeout(function(){t.success?k(t.data):x(t.data||"Error desconocido")},500)},error:function(t,E,b){console.error("Error AJAX:",b),x("Error de conexión: "+b)}})}l.on("click",function(){confirm("Esto generará todos los datos de ejemplo. ¿Continuar?")&&r("generate_all","Generando todos los datos de ejemplo...")}),g.on("click",function(){r("generate_destinations","Generando destinos...")}),p.on("click",function(){r("generate_tours","Generando tours...")}),f.on("click",function(){r("generate_pages","Generando páginas...")}),u.on("click",function(){confirm("¿Estás seguro de que quieres eliminar TODOS los tours, destinos y páginas de ejemplo? Esta acción no se puede deshacer.")&&confirm("Esta acción eliminará permanentemente todo el contenido generado. ¿Proceder?")&&r("clean_data","Limpiando datos de ejemplo...")}),v.on("click",function(){d.hide(),c.show(),a=!1}),l.attr("title","Genera tours, destinos, páginas y menú de navegación completo"),g.attr("title","Solo genera los destinos turísticos"),p.attr("title","Solo genera los tours con galerías de imágenes"),f.attr("title","Solo genera páginas institucionales básicas"),u.attr("title","Elimina todo el contenido de ejemplo generado"),n(".button").hover(function(){n(this).css("transform","translateY(-2px)")},function(){n(this).css("transform","translateY(0)")}),n("<style>").prop("type","text/css").html(`
            .button {
                transition: all 0.2s ease;
                position: relative;
            }
            
            .button-hero {
                font-size: 16px !important;
                padding: 12px 24px !important;
                height: auto !important;
            }
            
            .progress-bar {
                position: relative;
                overflow: hidden;
            }
            
            .progress-fill {
                position: relative;
            }
            
            .progress-fill::after {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(
                    90deg, 
                    rgba(255,255,255,0) 0%, 
                    rgba(255,255,255,0.4) 50%, 
                    rgba(255,255,255,0) 100%
                );
                animation: progressShine 2s infinite;
            }
            
            @keyframes progressShine {
                0% { transform: translateX(-100%); }
                100% { transform: translateX(100%); }
            }
            
            .notice {
                margin: 15px 0;
                padding: 12px;
                border-radius: 4px;
            }
            
            .notice-success {
                background: #d4edda;
                border-left: 4px solid #28a745;
                color: #155724;
            }
            
            .notice-warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                color: #856404;
            }
            
            .notice-error {
                background: #f8d7da;
                border-left: 4px solid #dc3545;
                color: #721c24;
            }
            
            .notice-info {
                background: #d1ecf1;
                border-left: 4px solid #17a2b8;
                color: #0c5460;
            }
        `).appendTo("head")});
