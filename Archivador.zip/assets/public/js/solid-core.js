let H = U;
const y = 1, E = 2, B = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var u = null;
let x = null, P = null, d = null, p = null, w = null, b = 0;
function W(e, t) {
  const n = d, s = u, i = e.length === 0, o = t === void 0 ? s : t, r = i ? B : {
    owned: null,
    cleanups: null,
    context: o ? o.context : null,
    owner: o
  }, l = i ? e : () => e(() => L(() => C(r)));
  u = r, d = null;
  try {
    return m(l, !0);
  } finally {
    d = n, u = s;
  }
}
function T(e, t, n) {
  const s = Q(e, t, !1, y);
  _(s);
}
function L(e) {
  if (d === null) return e();
  const t = d;
  d = null;
  try {
    return e();
  } finally {
    d = t;
  }
}
function G(e, t, n) {
  let s = e.value;
  return (!e.comparator || !e.comparator(s, t)) && (e.value = t, e.observers && e.observers.length && m(() => {
    for (let i = 0; i < e.observers.length; i += 1) {
      const o = e.observers[i], r = x && x.running;
      r && x.disposed.has(o), (r ? !o.tState : !o.state) && (o.pure ? p.push(o) : w.push(o), o.observers && $(o)), r || (o.state = y);
    }
    if (p.length > 1e6)
      throw p = [], new Error();
  }, !1)), t;
}
function _(e) {
  if (!e.fn) return;
  C(e);
  const t = b;
  J(
    e,
    e.value,
    t
  );
}
function J(e, t, n) {
  let s;
  const i = u, o = d;
  d = u = e;
  try {
    s = e.fn(t);
  } catch (r) {
    return e.pure && (e.state = y, e.owned && e.owned.forEach(C), e.owned = null), e.updatedAt = n + 1, j(r);
  } finally {
    d = o, u = i;
  }
  (!e.updatedAt || e.updatedAt <= n) && (e.updatedAt != null && "observers" in e ? G(e, s) : e.value = s, e.updatedAt = n);
}
function Q(e, t, n, s = y, i) {
  const o = {
    fn: e,
    state: s,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: u,
    context: u ? u.context : null,
    pure: n
  };
  return u === null || u !== B && (u.owned ? u.owned.push(o) : u.owned = [o]), o;
}
function M(e) {
  if (e.state === 0) return;
  if (e.state === E) return O(e);
  if (e.suspense && L(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < b); )
    e.state && t.push(e);
  for (let n = t.length - 1; n >= 0; n--)
    if (e = t[n], e.state === y)
      _(e);
    else if (e.state === E) {
      const s = p;
      p = null, m(() => O(e, t[0]), !1), p = s;
    }
}
function m(e, t) {
  if (p) return e();
  let n = !1;
  t || (p = []), w ? n = !0 : w = [], b++;
  try {
    const s = e();
    return K(n), s;
  } catch (s) {
    n || (w = null), p = null, j(s);
  }
}
function K(e) {
  if (p && (U(p), p = null), e) return;
  const t = w;
  w = null, t.length && m(() => H(t), !1);
}
function U(e) {
  for (let t = 0; t < e.length; t++) M(e[t]);
}
function O(e, t) {
  e.state = 0;
  for (let n = 0; n < e.sources.length; n += 1) {
    const s = e.sources[n];
    if (s.sources) {
      const i = s.state;
      i === y ? s !== t && (!s.updatedAt || s.updatedAt < b) && M(s) : i === E && O(s, t);
    }
  }
}
function $(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const n = e.observers[t];
    n.state || (n.state = E, n.pure ? p.push(n) : w.push(n), n.observers && $(n));
  }
}
function C(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const n = e.sources.pop(), s = e.sourceSlots.pop(), i = n.observers;
      if (i && i.length) {
        const o = i.pop(), r = n.observerSlots.pop();
        s < i.length && (o.sourceSlots[r] = s, i[s] = o, n.observerSlots[s] = r);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) C(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) C(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function X(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function j(e, t = u) {
  throw X(e);
}
function Y(e, t, n) {
  let s = n.length, i = t.length, o = s, r = 0, l = 0, f = t[i - 1].nextSibling, a = null;
  for (; r < i || l < o; ) {
    if (t[r] === n[l]) {
      r++, l++;
      continue;
    }
    for (; t[i - 1] === n[o - 1]; )
      i--, o--;
    if (i === r) {
      const c = o < s ? l ? n[l - 1].nextSibling : n[o - l] : f;
      for (; l < o; ) e.insertBefore(n[l++], c);
    } else if (o === l)
      for (; r < i; )
        (!a || !a.has(t[r])) && t[r].remove(), r++;
    else if (t[r] === n[o - 1] && n[l] === t[i - 1]) {
      const c = t[--i].nextSibling;
      e.insertBefore(n[l++], t[r++].nextSibling), e.insertBefore(n[--o], c), t[i] = n[o];
    } else {
      if (!a) {
        a = /* @__PURE__ */ new Map();
        let h = l;
        for (; h < o; ) a.set(n[h], h++);
      }
      const c = a.get(t[r]);
      if (c != null)
        if (l < c && c < o) {
          let h = r, S = 1, N;
          for (; ++h < i && h < o && !((N = a.get(t[h])) == null || N !== c + S); )
            S++;
          if (S > c - l) {
            const F = t[r];
            for (; l < c; ) e.insertBefore(n[l++], F);
          } else e.replaceChild(n[l++], t[r++]);
        } else r++;
      else t[r++].remove();
    }
  }
}
function Z(e, t, n, s = {}) {
  let i;
  return W((o) => {
    i = o, t === document ? e() : z(t, e(), t.firstChild ? null : void 0, n);
  }, s.owner), () => {
    i(), t.textContent = "";
  };
}
function z(e, t, n, s) {
  if (n !== void 0 && !s && (s = []), typeof t != "function") return A(e, t, s, n);
  T((i) => A(e, t(), i, n), s);
}
function A(e, t, n, s, i) {
  for (; typeof n == "function"; ) n = n();
  if (t === n) return n;
  const o = typeof t, r = s !== void 0;
  if (e = r && n[0] && n[0].parentNode || e, o === "string" || o === "number") {
    if (o === "number" && (t = t.toString(), t === n))
      return n;
    if (r) {
      let l = n[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), n = g(e, n, s, l);
    } else
      n !== "" && typeof n == "string" ? n = e.firstChild.data = t : n = e.textContent = t;
  } else if (t == null || o === "boolean")
    n = g(e, n, s);
  else {
    if (o === "function")
      return T(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        n = A(e, l, n, s);
      }), () => n;
    if (Array.isArray(t)) {
      const l = [], f = n && Array.isArray(n);
      if (v(l, t, n, i))
        return T(() => n = A(e, l, n, s, !0)), () => n;
      if (l.length === 0) {
        if (n = g(e, n, s), r) return n;
      } else f ? n.length === 0 ? D(e, l, s) : Y(e, n, l) : (n && g(e), D(e, l));
      n = l;
    } else if (t.nodeType) {
      if (Array.isArray(n)) {
        if (r) return n = g(e, n, s, t);
        g(e, n, null, t);
      } else n == null || n === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      n = t;
    }
  }
  return n;
}
function v(e, t, n, s) {
  let i = !1;
  for (let o = 0, r = t.length; o < r; o++) {
    let l = t[o], f = n && n[e.length], a;
    if (!(l == null || l === !0 || l === !1)) if ((a = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      i = v(e, l, f) || i;
    else if (a === "function")
      if (s) {
        for (; typeof l == "function"; ) l = l();
        i = v(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(f) ? f : [f]
        ) || i;
      } else
        e.push(l), i = !0;
    else {
      const c = String(l);
      f && f.nodeType === 3 && f.data === c ? e.push(f) : e.push(document.createTextNode(c));
    }
  }
  return i;
}
function D(e, t, n = null) {
  for (let s = 0, i = t.length; s < i; s++) e.insertBefore(t[s], n);
}
function g(e, t, n, s) {
  if (n === void 0) return e.textContent = "";
  const i = s || document.createTextNode("");
  if (t.length) {
    let o = !1;
    for (let r = t.length - 1; r >= 0; r--) {
      const l = t[r];
      if (i !== l) {
        const f = l.parentNode === e;
        !o && !r ? f ? e.replaceChild(i, l) : e.insertBefore(i, n) : f && l.remove();
      } else o = !0;
    }
  } else e.insertBefore(i, n);
  return [i];
}
const k = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, se = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const n = k();
  return n[e] ? n[e] : e;
}, R = {}, ee = () => document.readyState !== "loading";
function te(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  R[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function V(e) {
  return R[e] || null;
}
function q(e, t, n = {}) {
  const s = V(e);
  if (!s)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const i = Z(() => s(n), t);
    return t.dataset.solidInitialized = "true", i;
  } catch (i) {
    return console.error(`Error al renderizar el componente '${e}':`, i), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${i.message}</p>
      </div>
    `, null;
  }
}
function I() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const n = t.dataset.solidComponent;
    if (!n || t.dataset.solidInitialized === "true") return;
    let s = {};
    try {
      t.dataset.props && (s = JSON.parse(t.dataset.props));
    } catch (i) {
      console.warn(
        `Error al parsear propiedades para ${n}:`,
        i
      );
    }
    q(n, t, s);
  });
}
ee() ? I() : document.addEventListener("DOMContentLoaded", I);
const ne = {
  registerComponent: te,
  getComponent: V,
  renderComponent: q,
  initComponents: I
};
window.solidCore = ne;
export {
  se as __,
  ne as default,
  V as getComponent,
  I as initComponents,
  te as registerComponent,
  q as renderComponent
};
