const pn = (t, e) => t === e, fn = Symbol("solid-track"), rr = {
  equals: pn
};
let Fr = Hr;
const vt = 1, nr = 2, Or = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var ke = null;
let br = null, hn = null, he = null, Pe = null, st = null, ar = 0;
function Zt(t, e) {
  const r = he, n = ke, a = t.length === 0, s = e === void 0 ? n : e, g = a ? Or : {
    owned: null,
    cleanups: null,
    context: s ? s.context : null,
    owner: s
  }, d = a ? t : () => t(() => bt(() => Ht(g)));
  ke = g, he = null;
  try {
    return Yt(d, !0);
  } finally {
    he = r, ke = n;
  }
}
function A(t, e) {
  e = e ? Object.assign({}, rr, e) : rr;
  const r = {
    value: t,
    observers: null,
    observerSlots: null,
    comparator: e.equals || void 0
  }, n = (a) => (typeof a == "function" && (a = a(r.value)), Ir(r, a));
  return [qr.bind(r), n];
}
function D(t, e, r) {
  const n = Sr(t, e, !1, vt);
  Gt(n);
}
function mt(t, e, r) {
  Fr = vn;
  const n = Sr(t, e, !1, vt);
  n.user = !0, st ? st.push(n) : Gt(n);
}
function oe(t, e, r) {
  r = r ? Object.assign({}, rr, r) : rr;
  const n = Sr(t, e, !0, 0);
  return n.observers = null, n.observerSlots = null, n.comparator = r.equals || void 0, Gt(n), qr.bind(n);
}
function bt(t) {
  if (he === null) return t();
  const e = he;
  he = null;
  try {
    return t();
  } finally {
    he = e;
  }
}
function _r(t) {
  mt(() => bt(t));
}
function kr(t) {
  return ke === null || (ke.cleanups === null ? ke.cleanups = [t] : ke.cleanups.push(t)), t;
}
function qr() {
  if (this.sources && this.state)
    if (this.state === vt) Gt(this);
    else {
      const t = Pe;
      Pe = null, Yt(() => ir(this), !1), Pe = t;
    }
  if (he) {
    const t = this.observers ? this.observers.length : 0;
    he.sources ? (he.sources.push(this), he.sourceSlots.push(t)) : (he.sources = [this], he.sourceSlots = [t]), this.observers ? (this.observers.push(he), this.observerSlots.push(he.sources.length - 1)) : (this.observers = [he], this.observerSlots = [he.sources.length - 1]);
  }
  return this.value;
}
function Ir(t, e, r) {
  let n = t.value;
  return (!t.comparator || !t.comparator(n, e)) && (t.value = e, t.observers && t.observers.length && Yt(() => {
    for (let a = 0; a < t.observers.length; a += 1) {
      const s = t.observers[a], g = br && br.running;
      g && br.disposed.has(s), (g ? !s.tState : !s.state) && (s.pure ? Pe.push(s) : st.push(s), s.observers && Gr(s)), g || (s.state = vt);
    }
    if (Pe.length > 1e6)
      throw Pe = [], new Error();
  }, !1)), e;
}
function Gt(t) {
  if (!t.fn) return;
  Ht(t);
  const e = ar;
  mn(
    t,
    t.value,
    e
  );
}
function mn(t, e, r) {
  let n;
  const a = ke, s = he;
  he = ke = t;
  try {
    n = t.fn(e);
  } catch (g) {
    return t.pure && (t.state = vt, t.owned && t.owned.forEach(Ht), t.owned = null), t.updatedAt = r + 1, Yr(g);
  } finally {
    he = s, ke = a;
  }
  (!t.updatedAt || t.updatedAt <= r) && (t.updatedAt != null && "observers" in t ? Ir(t, n) : t.value = n, t.updatedAt = r);
}
function Sr(t, e, r, n = vt, a) {
  const s = {
    fn: t,
    state: n,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: e,
    owner: ke,
    context: ke ? ke.context : null,
    pure: r
  };
  return ke === null || ke !== Or && (ke.owned ? ke.owned.push(s) : ke.owned = [s]), s;
}
function or(t) {
  if (t.state === 0) return;
  if (t.state === nr) return ir(t);
  if (t.suspense && bt(t.suspense.inFallback)) return t.suspense.effects.push(t);
  const e = [t];
  for (; (t = t.owner) && (!t.updatedAt || t.updatedAt < ar); )
    t.state && e.push(t);
  for (let r = e.length - 1; r >= 0; r--)
    if (t = e[r], t.state === vt)
      Gt(t);
    else if (t.state === nr) {
      const n = Pe;
      Pe = null, Yt(() => ir(t, e[0]), !1), Pe = n;
    }
}
function Yt(t, e) {
  if (Pe) return t();
  let r = !1;
  e || (Pe = []), st ? r = !0 : st = [], ar++;
  try {
    const n = t();
    return bn(r), n;
  } catch (n) {
    r || (st = null), Pe = null, Yr(n);
  }
}
function bn(t) {
  if (Pe && (Hr(Pe), Pe = null), t) return;
  const e = st;
  st = null, e.length && Yt(() => Fr(e), !1);
}
function Hr(t) {
  for (let e = 0; e < t.length; e++) or(t[e]);
}
function vn(t) {
  let e, r = 0;
  for (e = 0; e < t.length; e++) {
    const n = t[e];
    n.user ? t[r++] = n : or(n);
  }
  for (e = 0; e < r; e++) or(t[e]);
}
function ir(t, e) {
  t.state = 0;
  for (let r = 0; r < t.sources.length; r += 1) {
    const n = t.sources[r];
    if (n.sources) {
      const a = n.state;
      a === vt ? n !== e && (!n.updatedAt || n.updatedAt < ar) && or(n) : a === nr && ir(n, e);
    }
  }
}
function Gr(t) {
  for (let e = 0; e < t.observers.length; e += 1) {
    const r = t.observers[e];
    r.state || (r.state = nr, r.pure ? Pe.push(r) : st.push(r), r.observers && Gr(r));
  }
}
function Ht(t) {
  let e;
  if (t.sources)
    for (; t.sources.length; ) {
      const r = t.sources.pop(), n = t.sourceSlots.pop(), a = r.observers;
      if (a && a.length) {
        const s = a.pop(), g = r.observerSlots.pop();
        n < a.length && (s.sourceSlots[g] = n, a[n] = s, r.observerSlots[n] = g);
      }
    }
  if (t.tOwned) {
    for (e = t.tOwned.length - 1; e >= 0; e--) Ht(t.tOwned[e]);
    delete t.tOwned;
  }
  if (t.owned) {
    for (e = t.owned.length - 1; e >= 0; e--) Ht(t.owned[e]);
    t.owned = null;
  }
  if (t.cleanups) {
    for (e = t.cleanups.length - 1; e >= 0; e--) t.cleanups[e]();
    t.cleanups = null;
  }
  t.state = 0;
}
function yn(t) {
  return t instanceof Error ? t : new Error(typeof t == "string" ? t : "Unknown error", {
    cause: t
  });
}
function Yr(t, e = ke) {
  throw yn(t);
}
const $n = Symbol("fallback");
function Nr(t) {
  for (let e = 0; e < t.length; e++) t[e]();
}
function xn(t, e, r = {}) {
  let n = [], a = [], s = [], g = 0, d = e.length > 1 ? [] : null;
  return kr(() => Nr(s)), () => {
    let u = t() || [], y = u.length, x, f;
    return u[fn], bt(() => {
      let G, R, ee, re, ie, K, F, pe, be;
      if (y === 0)
        g !== 0 && (Nr(s), s = [], n = [], a = [], g = 0, d && (d = [])), r.fallback && (n = [$n], a[0] = Zt((O) => (s[0] = O, r.fallback())), g = 1);
      else if (g === 0) {
        for (a = new Array(y), f = 0; f < y; f++)
          n[f] = u[f], a[f] = Zt(me);
        g = y;
      } else {
        for (ee = new Array(y), re = new Array(y), d && (ie = new Array(y)), K = 0, F = Math.min(g, y); K < F && n[K] === u[K]; K++) ;
        for (F = g - 1, pe = y - 1; F >= K && pe >= K && n[F] === u[pe]; F--, pe--)
          ee[pe] = a[F], re[pe] = s[F], d && (ie[pe] = d[F]);
        for (G = /* @__PURE__ */ new Map(), R = new Array(pe + 1), f = pe; f >= K; f--)
          be = u[f], x = G.get(be), R[f] = x === void 0 ? -1 : x, G.set(be, f);
        for (x = K; x <= F; x++)
          be = n[x], f = G.get(be), f !== void 0 && f !== -1 ? (ee[f] = a[x], re[f] = s[x], d && (ie[f] = d[x]), f = R[f], G.set(be, f)) : s[x]();
        for (f = K; f < y; f++)
          f in ee ? (a[f] = ee[f], s[f] = re[f], d && (d[f] = ie[f], d[f](f))) : a[f] = Zt(me);
        a = a.slice(0, g = y), n = u.slice(0);
      }
      return a;
    });
    function me(G) {
      if (s[f] = G, d) {
        const [R, ee] = A(f);
        return d[f] = ee, e(u[f], R);
      }
      return e(u[f]);
    }
  };
}
function k(t, e) {
  return bt(() => t(e || {}));
}
const wn = (t) => `Stale read from <${t}>.`;
function er(t) {
  const e = "fallback" in t && {
    fallback: () => t.fallback
  };
  return oe(xn(() => t.each, t.children, e || void 0));
}
function T(t) {
  const e = t.keyed, r = oe(() => t.when, void 0, void 0), n = e ? r : oe(r, void 0, {
    equals: (a, s) => !a == !s
  });
  return oe(
    () => {
      const a = n();
      if (a) {
        const s = t.children;
        return typeof s == "function" && s.length > 0 ? bt(
          () => s(
            e ? a : () => {
              if (!bt(n)) throw wn("Show");
              return r();
            }
          )
        ) : s;
      }
      return t.fallback;
    },
    void 0,
    void 0
  );
}
function _n(t, e, r) {
  let n = r.length, a = e.length, s = n, g = 0, d = 0, u = e[a - 1].nextSibling, y = null;
  for (; g < a || d < s; ) {
    if (e[g] === r[d]) {
      g++, d++;
      continue;
    }
    for (; e[a - 1] === r[s - 1]; )
      a--, s--;
    if (a === g) {
      const x = s < n ? d ? r[d - 1].nextSibling : r[s - d] : u;
      for (; d < s; ) t.insertBefore(r[d++], x);
    } else if (s === d)
      for (; g < a; )
        (!y || !y.has(e[g])) && e[g].remove(), g++;
    else if (e[g] === r[s - 1] && r[d] === e[a - 1]) {
      const x = e[--a].nextSibling;
      t.insertBefore(r[d++], e[g++].nextSibling), t.insertBefore(r[--s], x), e[a] = r[s];
    } else {
      if (!y) {
        y = /* @__PURE__ */ new Map();
        let f = d;
        for (; f < s; ) y.set(r[f], f++);
      }
      const x = y.get(e[g]);
      if (x != null)
        if (d < x && x < s) {
          let f = g, me = 1, G;
          for (; ++f < a && f < s && !((G = y.get(e[f])) == null || G !== x + me); )
            me++;
          if (me > x - d) {
            const R = e[g];
            for (; d < x; ) t.insertBefore(r[d++], R);
          } else t.replaceChild(r[d++], e[g++]);
        } else g++;
      else e[g++].remove();
    }
  }
}
const zr = "_$DX_DELEGATE";
function kn(t, e, r, n = {}) {
  let a;
  return Zt((s) => {
    a = s, e === document ? t() : o(e, t(), e.firstChild ? null : void 0, r);
  }, n.owner), () => {
    a(), e.textContent = "";
  };
}
function p(t, e, r, n) {
  let a;
  const s = () => {
    const d = document.createElement("template");
    return d.innerHTML = t, d.content.firstChild;
  }, g = () => (a || (a = s())).cloneNode(!0);
  return g.cloneNode = g, g;
}
function Cr(t, e = window.document) {
  const r = e[zr] || (e[zr] = /* @__PURE__ */ new Set());
  for (let n = 0, a = t.length; n < a; n++) {
    const s = t[n];
    r.has(s) || (r.add(s), e.addEventListener(s, Cn));
  }
}
function w(t, e, r) {
  r == null ? t.removeAttribute(e) : t.setAttribute(e, r);
}
function c(t, e) {
  e == null ? t.removeAttribute("class") : t.className = e;
}
function Sn(t, e, r, n) {
  Array.isArray(r) ? (t[`$$${e}`] = r[0], t[`$$${e}Data`] = r[1]) : t[`$$${e}`] = r;
}
function tr(t, e, r) {
  if (!e) return r ? w(t, "style") : e;
  const n = t.style;
  if (typeof e == "string") return n.cssText = e;
  typeof r == "string" && (n.cssText = r = void 0), r || (r = {}), e || (e = {});
  let a, s;
  for (s in r)
    e[s] == null && n.removeProperty(s), delete r[s];
  for (s in e)
    a = e[s], a !== r[s] && (n.setProperty(s, a), r[s] = a);
  return r;
}
function It(t, e, r) {
  return bt(() => t(e, r));
}
function o(t, e, r, n) {
  if (r !== void 0 && !n && (n = []), typeof e != "function") return lr(t, e, n, r);
  D((a) => lr(t, e(), a, r), n);
}
function Cn(t) {
  let e = t.target;
  const r = `$$${t.type}`, n = t.target, a = t.currentTarget, s = (u) => Object.defineProperty(t, "target", {
    configurable: !0,
    value: u
  }), g = () => {
    const u = e[r];
    if (u && !e.disabled) {
      const y = e[`${r}Data`];
      if (y !== void 0 ? u.call(e, y, t) : u.call(e, t), t.cancelBubble) return;
    }
    return e.host && typeof e.host != "string" && !e.host._$host && e.contains(t.target) && s(e.host), !0;
  }, d = () => {
    for (; g() && (e = e._$host || e.parentNode || e.host); ) ;
  };
  if (Object.defineProperty(t, "currentTarget", {
    configurable: !0,
    get() {
      return e || document;
    }
  }), t.composedPath) {
    const u = t.composedPath();
    s(u[0]);
    for (let y = 0; y < u.length - 2 && (e = u[y], !!g()); y++) {
      if (e._$host) {
        e = e._$host, d();
        break;
      }
      if (e.parentNode === a)
        break;
    }
  } else d();
  s(n);
}
function lr(t, e, r, n, a) {
  for (; typeof r == "function"; ) r = r();
  if (e === r) return r;
  const s = typeof e, g = n !== void 0;
  if (t = g && r[0] && r[0].parentNode || t, s === "string" || s === "number") {
    if (s === "number" && (e = e.toString(), e === r))
      return r;
    if (g) {
      let d = r[0];
      d && d.nodeType === 3 ? d.data !== e && (d.data = e) : d = document.createTextNode(e), r = zt(t, r, n, d);
    } else
      r !== "" && typeof r == "string" ? r = t.firstChild.data = e : r = t.textContent = e;
  } else if (e == null || s === "boolean")
    r = zt(t, r, n);
  else {
    if (s === "function")
      return D(() => {
        let d = e();
        for (; typeof d == "function"; ) d = d();
        r = lr(t, d, r, n);
      }), () => r;
    if (Array.isArray(e)) {
      const d = [], u = r && Array.isArray(r);
      if (xr(d, e, r, a))
        return D(() => r = lr(t, d, r, n, !0)), () => r;
      if (d.length === 0) {
        if (r = zt(t, r, n), g) return r;
      } else u ? r.length === 0 ? Ur(t, d, n) : _n(t, r, d) : (r && zt(t), Ur(t, d));
      r = d;
    } else if (e.nodeType) {
      if (Array.isArray(r)) {
        if (g) return r = zt(t, r, n, e);
        zt(t, r, null, e);
      } else r == null || r === "" || !t.firstChild ? t.appendChild(e) : t.replaceChild(e, t.firstChild);
      r = e;
    }
  }
  return r;
}
function xr(t, e, r, n) {
  let a = !1;
  for (let s = 0, g = e.length; s < g; s++) {
    let d = e[s], u = r && r[t.length], y;
    if (!(d == null || d === !0 || d === !1)) if ((y = typeof d) == "object" && d.nodeType)
      t.push(d);
    else if (Array.isArray(d))
      a = xr(t, d, u) || a;
    else if (y === "function")
      if (n) {
        for (; typeof d == "function"; ) d = d();
        a = xr(
          t,
          Array.isArray(d) ? d : [d],
          Array.isArray(u) ? u : [u]
        ) || a;
      } else
        t.push(d), a = !0;
    else {
      const x = String(d);
      u && u.nodeType === 3 && u.data === x ? t.push(u) : t.push(document.createTextNode(x));
    }
  }
  return a;
}
function Ur(t, e, r = null) {
  for (let n = 0, a = e.length; n < a; n++) t.insertBefore(e[n], r);
}
function zt(t, e, r, n) {
  if (r === void 0) return t.textContent = "";
  const a = n || document.createTextNode("");
  if (e.length) {
    let s = !1;
    for (let g = e.length - 1; g >= 0; g--) {
      const d = e[g];
      if (a !== d) {
        const u = d.parentNode === t;
        !s && !g ? u ? t.replaceChild(a, d) : t.insertBefore(a, r) : u && d.remove();
      } else s = !0;
    }
  } else t.insertBefore(a, r);
  return [a];
}
const Dn = () => {
  const t = {};
  return Object.keys(window).forEach((e) => {
    e.startsWith("wptbtI18n_") && Object.assign(t, window[e]);
  }), window.wptbtI18n && Object.assign(t, window.wptbtI18n), t;
}, Mn = (t, e) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(t, e || "wp-tailwind-blocks");
  const r = Dn();
  return r[t] ? r[t] : t;
}, Wr = {}, jn = () => document.readyState !== "loading";
function Jr(t, e) {
  if (typeof t != "string" || t.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof e != "function") {
    console.error(
      `El componente ${t} debe ser una función válida de Solid.js`
    );
    return;
  }
  Wr[t] = e, console.log(`Componente '${t}' registrado correctamente`);
}
function Kr(t) {
  return Wr[t] || null;
}
function Qr(t, e, r = {}) {
  const n = Kr(t);
  if (!n)
    return console.error(`El componente '${t}' no está registrado`), null;
  if (!e || !(e instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; e.firstChild; )
      e.removeChild(e.firstChild);
    const a = kn(() => n(r), e);
    return e.dataset.solidInitialized = "true", a;
  } catch (a) {
    return console.error(`Error al renderizar el componente '${t}':`, a), e.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${a.message}</p>
      </div>
    `, null;
  }
}
function wr() {
  const t = document.querySelectorAll("[data-solid-component]");
  t.length !== 0 && t.forEach((e) => {
    const r = e.dataset.solidComponent;
    if (!r || e.dataset.solidInitialized === "true") return;
    let n = {};
    try {
      e.dataset.props && (n = JSON.parse(e.dataset.props));
    } catch (a) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        a
      );
    }
    Qr(r, e, n);
  });
}
jn() ? wr() : document.addEventListener("DOMContentLoaded", wr);
const Dr = {
  registerComponent: Jr,
  getComponent: Kr,
  renderComponent: Qr,
  initComponents: wr
};
window.solidCore = Dr;
var vr = /* @__PURE__ */ p("<button type=button>"), Rr = /* @__PURE__ */ p('<div class="grid grid-cols-3 gap-2 p-3">'), En = /* @__PURE__ */ p('<div class="w-10 h-10">'), Tn = /* @__PURE__ */ p('<div><div><button type=button><svg xmlns=http://www.w3.org/2000/svg class="h-5 w-5"viewBox="0 0 20 20"fill=currentColor><path fill-rule=evenodd d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"clip-rule=evenodd></path></svg></button><div class="flex space-x-1"><span></span></div><button type=button><svg xmlns=http://www.w3.org/2000/svg class="h-5 w-5"viewBox="0 0 20 20"fill=currentColor><path fill-rule=evenodd d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"clip-rule=evenodd></path></svg></button></div><div><div></div></div><div><button type=button>Hoy</button><button type=button>Cerrar'), An = /* @__PURE__ */ p(`<div class="group datepicker-container"><style>
    .datepicker-container {
      position: relative;
      width: 100%;
    }
    
    .calendar-container {
      position: absolute;
      z-index: 9999;
      width: 300px;
      left: 0;
      top: calc(100% + 0.5rem);
      animation: fadeIn 0.2s ease-out;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .month-year-selector {
      cursor: pointer;
      user-select: none;
      padding: 0.25rem 0.5rem;
      border-radius: 0.25rem;
      transition: background-color 0.2s;
    }
    
    .month-year-selector:hover {
      background-color: rgba(0, 0, 0, 0.1);
    }
    
    .calendar-content {
      height: 300px; /* Altura fija para evitar saltos */
      position: relative;
      overflow: hidden;
      perspective: 1000px; /* Para efectos 3D más suaves */
    }
    
    /* Panel de vista actual */
    .view-panel {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      transition: transform 0.3s cubic-bezier(0.25, 0.1, 0.25, 1), opacity 0.3s ease;
      display: flex;
      flex-direction: column;
      justify-content: center;
      backface-visibility: hidden; /* Mejora rendimiento de animaciones */
      transform-style: preserve-3d;
      will-change: transform, opacity; /* Optimización de rendimiento */
    }
    
    /* Panel para la vista anterior (durante transiciones) */
    .previous-view-panel {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      z-index: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      transition: transform 0.3s cubic-bezier(0.25, 0.1, 0.25, 1), opacity 0.3s ease;
      backface-visibility: hidden;
      transform-style: preserve-3d;
      will-change: transform, opacity;
    }
    
    /* Animaciones para la vista actual durante transición */
    .transitioning.next .view-panel {
      transform: translateY(30px);
      opacity: 0;
      pointer-events: none;
    }
    
    .transitioning.prev .view-panel {
      transform: translateY(-30px);
      opacity: 0;
      pointer-events: none;
    }
    
    /* Animaciones para la vista anterior durante transición */
    .transitioning.next .previous-view-panel {
      transform: translateY(-30px);
      opacity: 0;
      pointer-events: none;
    }
    
    .transitioning.prev .previous-view-panel {
      transform: translateY(30px);
      opacity: 0;
      pointer-events: none;
    }
    
    /* Estados iniciales para animación de entrada */
    .view-enter-next {
      transform: translateY(30px);
      opacity: 0;
    }
    
    .view-enter-prev {
      transform: translateY(-30px);
      opacity: 0;
    }
    
    .view-enter-active {
      transform: translateY(0);
      opacity: 1;
      transition: transform 0.3s cubic-bezier(0.25, 0.1, 0.25, 1), opacity 0.3s ease;
    }
  </style><label></label><div class=relative><div><svg class="w-5 h-5 mr-2"fill=none stroke=currentColor viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg><path stroke-linecap=round stroke-linejoin=round stroke-width=1.5 d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg></div><input type=text readonly></div><input type=hidden>`), Bn = /* @__PURE__ */ p("<span>,"), Pn = /* @__PURE__ */ p("<span>"), Ln = /* @__PURE__ */ p("<div class=previous-view-panel>"), Nn = /* @__PURE__ */ p('<div class=p-3><div></div><div class="grid grid-cols-7 gap-1">'), zn = /* @__PURE__ */ p("<div>");
const Un = (t) => {
  const {
    name: e = "date",
    id: r = `date-${Math.random().toString(36).substring(2, 10)}`,
    value: n = "",
    onChange: a = () => {
    },
    placeholder: s = "Seleccionar fecha",
    required: g = !0,
    labelText: d = "Fecha",
    colors: u = {
      primary: "#4F8A8B",
      secondary: "#F7EDE2",
      accent: "#D4B254",
      dark: "#424242"
    },
    darkMode: y = !1
  } = t, x = /* @__PURE__ */ new Date();
  x.setHours(0, 0, 0, 0);
  const f = x.getFullYear(), [me, G] = A(!1), [R, ee] = A(x.getMonth()), [re, ie] = A(f), [K, F] = A(n ? dt(n) : null), [pe, be] = A(n || ""), [O, Ue] = A("days"), [Xe, He] = A({
    start: f - 6,
    end: f + 5
  }), [We, Y] = A(!1), [it, Ge] = A("next"), [te, q] = A(null), [ce, ve] = A(null);
  let Ze, Le;
  function dt(h) {
    try {
      if (!h) return null;
      const [_, P, S] = h.split("-").map(Number);
      return isNaN(_) || isNaN(P) || isNaN(S) ? null : new Date(_, P - 1, S);
    } catch (_) {
      return console.error("Error al parsear fecha:", _), null;
    }
  }
  const L = ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"], Je = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], Ke = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
  _r(() => {
    if (n)
      try {
        const [h, _, P] = n.split("-").map(Number);
        if (!isNaN(h) && !isNaN(_) && !isNaN(P)) {
          const S = new Date(h, _ - 1, P);
          F(S), ee(S.getMonth()), ie(S.getFullYear());
        }
      } catch (h) {
        console.error("Error parsing initial date:", h);
      }
    setTimeout(() => {
      document.addEventListener("mousedown", Me);
    }, 100);
  }), kr(() => {
    document.removeEventListener("mousedown", Me);
  });
  const se = (h) => {
    if (!h) return "";
    const _ = h.getFullYear(), P = String(h.getMonth() + 1).padStart(2, "0"), S = String(h.getDate()).padStart(2, "0");
    return `${_}-${P}-${S}`;
  }, Ye = (h) => {
    const _ = new Date(h.getFullYear(), h.getMonth(), h.getDate()), P = new Date(x.getFullYear(), x.getMonth(), x.getDate());
    return _ < P;
  }, Me = (h) => {
    me() && (Ze && Ze.contains(h.target) || Le && Le.contains(h.target) || (G(!1), setTimeout(() => {
      Ue("days");
    }, 300)));
  }, le = (h) => {
    h && (h.preventDefault(), h.stopPropagation()), G(!me());
  }, et = (h, _) => {
    const P = {
      days: 0,
      months: 1,
      years: 2
    };
    return P[_] > P[h] ? "next" : "prev";
  }, Re = (h, _) => {
    h !== O() && (q(O()), O() === "days" ? ve(Et()) : O() === "months" ? ve(Rt()) : O() === "years" && ve(jt()), Ge(et(O(), h)), Y(!0), Ue(h), setTimeout(() => {
      Y(!1), setTimeout(() => {
        q(null), ve(null);
      }, 50);
    }, 300));
  }, Dt = (h, _) => {
    _ && (_.preventDefault(), _.stopPropagation()), O() === "days" ? ve(Et()) : O() === "months" ? ve(Rt()) : O() === "years" && ve(jt()), q(O()), Ge(h > 0 ? "next" : "prev"), Y(!0);
    let P = R(), S = re();
    if (O() === "days")
      P += h, P > 11 ? (P = 0, S += 1) : P < 0 && (P = 11, S -= 1), ee(P), ie(S);
    else if (O() === "months")
      ie(S + h);
    else if (O() === "years") {
      const ye = Xe();
      He({
        start: ye.start + h * 12,
        end: ye.end + h * 12
      });
    }
    setTimeout(() => {
      Y(!1), setTimeout(() => {
        q(null), ve(null);
      }, 50);
    }, 300);
  }, I = (h, _) => {
    _ && (_.preventDefault(), _.stopPropagation()), ee(h), Ge("prev"), Re("days");
  }, lt = (h, _) => {
    _ && (_.preventDefault(), _.stopPropagation()), ie(h), Ge("prev"), Re("months");
  }, yt = (h) => {
    h && (h.preventDefault(), h.stopPropagation()), Ge("next"), Re("months");
  }, Ut = (h) => {
    h && (h.preventDefault(), h.stopPropagation());
    const _ = re();
    He({
      start: _ - 6,
      end: _ + 5
    }), Ge((O() === "months", "next")), Re("years");
  }, Mt = (h, _) => {
    _ && (_.preventDefault(), _.stopPropagation());
    try {
      const P = new Date(re(), R(), h);
      if (Ye(P))
        return;
      const S = se(P);
      F(P), be(S), typeof a == "function" && a({
        target: {
          name: e,
          value: S
        }
      }), G(!1), setTimeout(() => {
        Ue("days");
      }, 300);
    } catch (P) {
      console.error("Error al seleccionar fecha:", P);
    }
  }, Rt = () => {
    const h = [], _ = x.getMonth(), P = x.getFullYear();
    for (let S = 0; S < 12; S++) {
      const ye = S === _ && re() === P, U = K() && S === K().getMonth() && re() === K().getFullYear(), $e = re() === P && S < _;
      h.push((() => {
        var ne = vr();
        return ne.$$mousedown = (N) => N.stopPropagation(), ne.$$click = (N) => !$e && I(S, N), ne.disabled = $e, o(ne, () => Ke[S]), D((N) => {
          var W = `p-3 rounded flex items-center justify-center transition-colors duration-150 
                 ${$e ? `${y ? "text-gray-600" : "text-gray-300"} cursor-not-allowed` : y ? "hover:bg-gray-700" : "hover:bg-gray-100"} 
                 ${U ? `bg-${u.accent.replace("#", "")} text-white font-bold` : ""}
                 ${ye && !U && !$e ? "font-semibold border border-gray-300" : ""}`, Ne = U ? {
            backgroundColor: u.accent,
            color: "white"
          } : {};
          return W !== N.e && c(ne, N.e = W), N.t = tr(ne, Ne, N.t), N;
        }, {
          e: void 0,
          t: void 0
        }), ne;
      })());
    }
    return (() => {
      var S = Rr();
      return o(S, h), S;
    })();
  }, jt = () => {
    const h = [], _ = Xe(), P = x.getFullYear();
    for (let S = _.start; S <= _.end; S++) {
      const ye = S === P, U = K() && S === K().getFullYear(), $e = S < P;
      h.push((() => {
        var ne = vr();
        return ne.$$mousedown = (N) => N.stopPropagation(), ne.$$click = (N) => !$e && lt(S, N), ne.disabled = $e, o(ne, S), D((N) => {
          var W = `p-3 rounded flex items-center justify-center transition-colors duration-150
                 ${$e ? `${y ? "text-gray-600" : "text-gray-300"} cursor-not-allowed` : y ? "hover:bg-gray-700" : "hover:bg-gray-100"}
                 ${U ? `bg-${u.accent.replace("#", "")} text-white font-bold` : ""}
                 ${ye && !U && !$e ? "font-semibold border border-gray-300" : ""}`, Ne = U ? {
            backgroundColor: u.accent,
            color: "white"
          } : {};
          return W !== N.e && c(ne, N.e = W), N.t = tr(ne, Ne, N.t), N;
        }, {
          e: void 0,
          t: void 0
        }), ne;
      })());
    }
    return (() => {
      var S = Rr();
      return o(S, h), S;
    })();
  }, Et = () => {
    const h = [], _ = new Date(re(), R(), 1).getDay(), P = new Date(re(), R() + 1, 0).getDate();
    for (let S = 0; S < _; S++)
      h.push(En());
    for (let S = 1; S <= P; S++) {
      const ye = new Date(re(), R(), S), U = Ye(ye), $e = ye.toDateString() === x.toDateString(), ne = K() && ye.getDate() === K().getDate() && ye.getMonth() === K().getMonth() && ye.getFullYear() === K().getFullYear();
      h.push((() => {
        var N = vr();
        return N.$$mousedown = (W) => W.stopPropagation(), N.$$click = (W) => !U && Mt(S, W), N.disabled = U, o(N, S), D((W) => {
          var Ne = `w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-150
                  ${U ? `${y ? "text-gray-600" : "text-gray-300"} cursor-not-allowed` : "cursor-pointer"}
                  ${ne ? `bg-${u.accent.replace("#", "")} text-white font-bold` : ""}
                  ${$e && !ne ? `border-2 border-${u.primary.replace("#", "")} font-semibold` : ""}
                  ${!U && !ne ? `hover:bg-${y ? "gray-700" : "gray-100"}` : ""}`, $t = {
            ...ne ? {
              backgroundColor: u.accent,
              color: "white"
            } : {},
            ...$e && !ne ? {
              borderColor: u.primary
            } : {}
          };
          return Ne !== W.e && c(N, W.e = Ne), W.t = tr(N, $t, W.t), W;
        }, {
          e: void 0,
          t: void 0
        }), N;
      })());
    }
    return h;
  }, Tt = (h) => {
    h && (h.preventDefault(), h.stopPropagation());
    const _ = /* @__PURE__ */ new Date();
    Y(!0), setTimeout(() => {
      ee(_.getMonth()), ie(_.getFullYear()), Ue("days"), Y(!1);
    }, 200);
  };
  return (() => {
    var h = An(), _ = h.firstChild, P = _.nextSibling, S = P.nextSibling, ye = S.firstChild, U = ye.nextSibling, $e = S.nextSibling, ne = Ze;
    return typeof ne == "function" ? It(ne, h) : Ze = h, w(P, "for", r), c(P, `block text-sm font-medium mb-1.5 ml-1 ${y ? "text-white" : "text-gray-700"}`), o(P, d), c(ye, `absolute inset-y-0 left-3 flex items-center pointer-events-none ${y ? "text-gray-400" : "text-gray-500"}`), U.$$click = le, w(U, "id", r), w(U, "name", e), w(U, "placeholder", s), U.required = g, c(U, `w-full pl-12 pr-4 py-3 ${y ? "bg-gray-800/80 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"} border rounded-md focus:ring-2 focus:outline-none cursor-pointer transition-colors duration-200`), o(h, k(T, {
      get when() {
        return me();
      },
      get children() {
        var N = Tn(), W = N.firstChild, Ne = W.firstChild, $t = Ne.nextSibling, Vt = $t.firstChild, Wt = $t.nextSibling, xt = W.nextSibling, Qe = xt.firstChild, Jt = xt.nextSibling, ze = Jt.firstChild, At = ze.nextSibling;
        N.$$click = (C) => C.stopPropagation(), N.$$mousedown = (C) => C.stopPropagation();
        var Ft = Le;
        return typeof Ft == "function" ? It(Ft, N) : Le = N, c(N, `calendar-container rounded-lg overflow-hidden ${y ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-200"}`), c(W, `calendar-navigation flex justify-between items-center p-3 border-b ${y ? "border-gray-700" : "border-gray-100"}`), Ne.$$mousedown = (C) => C.stopPropagation(), Ne.$$click = (C) => Dt(-1, C), c(Ne, `p-1 rounded ${y ? "text-gray-300 hover:bg-gray-700" : "text-gray-600 hover:bg-gray-100"}`), Vt.$$mousedown = (C) => C.stopPropagation(), Sn(Vt, "click", O() === "years" ? null : O() === "months" ? Ut : yt), c(Vt, `month-year-selector font-medium ${y ? "text-white hover:bg-gray-700" : "text-gray-700 hover:bg-gray-100"}`), o(Vt, (() => {
          var C = oe(() => O() === "years");
          return () => C() ? `${Xe().start} - ${Xe().end}` : oe(() => O() === "months")() ? re() : Je[R()];
        })()), o($t, (() => {
          var C = oe(() => O() === "days");
          return () => C() && [(() => {
            var xe = Bn();
            return c(xe, y ? "text-white" : "text-gray-700"), xe;
          })(), (() => {
            var xe = Pn();
            return xe.$$mousedown = (qe) => qe.stopPropagation(), xe.$$click = Ut, c(xe, `month-year-selector font-medium ${y ? "text-white hover:bg-gray-700" : "text-gray-700 hover:bg-gray-100"}`), o(xe, re), xe;
          })()];
        })(), null), Wt.$$mousedown = (C) => C.stopPropagation(), Wt.$$click = (C) => Dt(1, C), c(Wt, `p-1 rounded ${y ? "text-gray-300 hover:bg-gray-700" : "text-gray-600 hover:bg-gray-100"}`), xt.$$mousedown = (C) => C.stopPropagation(), o(xt, (() => {
          var C = oe(() => !!(te() && We()));
          return () => C() && (() => {
            var xe = Ln();
            return o(xe, ce), xe;
          })();
        })(), Qe), o(Qe, (() => {
          var C = oe(() => O() === "days");
          return () => C() && (() => {
            var xe = Nn(), qe = xe.firstChild, sr = qe.nextSibling;
            return c(qe, `grid grid-cols-7 mb-2 text-center text-xs ${y ? "text-gray-400" : "text-gray-500"}`), o(qe, () => L.map((dr) => (() => {
              var wt = zn();
              return o(wt, dr), wt;
            })())), o(sr, Et), xe;
          })();
        })(), null), o(Qe, (() => {
          var C = oe(() => O() === "months");
          return () => C() && Rt();
        })(), null), o(Qe, (() => {
          var C = oe(() => O() === "years");
          return () => C() && jt();
        })(), null), c(Jt, `p-2 border-t ${y ? "border-gray-700" : "border-gray-100"} flex justify-between`), ze.$$mousedown = (C) => C.stopPropagation(), ze.$$click = Tt, c(ze, `text-sm px-3 py-1 rounded ${y ? "text-gray-300 hover:bg-gray-700" : "text-gray-600 hover:bg-gray-100"}`), At.$$mousedown = (C) => C.stopPropagation(), At.$$click = (C) => {
          C.preventDefault(), C.stopPropagation(), G(!1), setTimeout(() => Ue("days"), 300);
        }, c(At, `text-sm px-3 py-1 rounded ${y ? "text-gray-300 hover:bg-gray-700 bg-gray-700/50" : "text-gray-600 hover:bg-gray-100 bg-gray-100/50"}`), D((C) => {
          var xe = `calendar-content ${We() ? `transitioning ${it()}` : ""}`, qe = `view-panel ${We() ? "" : "view-enter-" + it() + " view-enter-active"}`;
          return xe !== C.e && c(xt, C.e = xe), qe !== C.t && c(Qe, C.t = qe), C;
        }, {
          e: void 0,
          t: void 0
        }), N;
      }
    }), $e), w($e, "name", e), D((N) => (N = u.accent) != null ? U.style.setProperty("border-color", N) : U.style.removeProperty("border-color")), D(() => U.value = pe()), D(() => $e.value = pe()), h;
  })();
};
Cr(["click", "mousedown"]);
var Rn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2>'), Vn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M5 13l4 4L19 7">'), Fn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z">'), On = /* @__PURE__ */ p('<span class="text-red-500 ml-1">*'), qn = /* @__PURE__ */ p("<label>"), In = /* @__PURE__ */ p('<span class="block truncate font-medium">'), yr = /* @__PURE__ */ p("<span>"), Hn = /* @__PURE__ */ p('<div class="p-3 border-b border-gray-200"><div class=relative><div></div><input type=text placeholder=Search...>'), Gn = /* @__PURE__ */ p("<div><div>"), Yn = /* @__PURE__ */ p('<div class=relative><button type=button aria-haspopup=listbox><div class="flex items-center justify-between"><div class="flex-1 min-w-0"></div><div></div></div></button><input type=hidden>'), Wn = /* @__PURE__ */ p("<div>No options found"), Jn = /* @__PURE__ */ p('<div class="ml-2 text-current">'), Kn = /* @__PURE__ */ p('<button type=button><div class="flex items-center justify-between"><div class="flex-1 min-w-0"><div class="flex items-center"><span class="block truncate font-medium">');
const $r = (t) => {
  const {
    id: e = "custom-select",
    name: r = "select",
    options: n = () => [],
    value: a = "",
    onChange: s = () => {
    },
    placeholder: g = "Select an option",
    labelText: d = "",
    required: u = !1,
    disabled: y = !1,
    darkMode: x = !1,
    colors: f = {
      accent: "#D4B254"
    },
    icon: me = "chevron",
    searchable: G = !1
  } = t;
  console.log("CustomSelect props:", n());
  const [R, ee] = A(!1), [re, ie] = A(""), [K, F] = A(-1);
  let pe, be, O;
  const Ue = () => n().find((te) => te.value === a()) || null, Xe = () => !G || !re() ? n() : n().filter((te) => te.label.toLowerCase().includes(re().toLowerCase()) || te.subtitle && te.subtitle.toLowerCase().includes(re().toLowerCase())), He = () => {
    y || (ee(!R()), R() || (ie(""), F(-1)));
  }, We = (te) => {
    te.disabled || (s(te.value), ee(!1), ie(""), F(-1));
  }, Y = (te) => {
    pe && !pe.contains(te.target) && (ee(!1), ie(""), F(-1));
  }, it = (te) => {
    const q = Xe();
    switch (te.key) {
      case "Enter":
        te.preventDefault(), R() && K() >= 0 ? We(q[K()]) : He();
        break;
      case "Escape":
        ee(!1), ie(""), F(-1);
        break;
      case "ArrowDown":
        te.preventDefault(), R() ? F((ce) => ce < filteredoptions().length - 1 ? ce + 1 : 0) : ee(!0);
        break;
      case "ArrowUp":
        te.preventDefault(), R() && F((ce) => ce > 0 ? ce - 1 : filteredoptions().length - 1);
        break;
      case "Tab":
        ee(!1), ie(""), F(-1);
        break;
    }
  };
  _r(() => {
    document.addEventListener("click", Y), document.addEventListener("keydown", it);
  }), kr(() => {
    document.removeEventListener("click", Y), document.removeEventListener("keydown", it);
  }), mt(() => {
    R() && G && O && setTimeout(() => O.focus(), 50);
  });
  const Ge = (te, q = "w-5 h-5") => {
    switch (te) {
      case "chevron":
        return (() => {
          var ce = Rn(), ve = ce.firstChild;
          return w(ce, "class", q), D(() => w(ve, "d", R() ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7")), ce;
        })();
      case "check":
        return (() => {
          var ce = Vn();
          return w(ce, "class", q), ce;
        })();
      case "search":
        return (() => {
          var ce = Fn();
          return w(ce, "class", q), ce;
        })();
      default:
        return null;
    }
  };
  return (() => {
    var te = Yn(), q = te.firstChild, ce = q.firstChild, ve = ce.firstChild, Ze = ve.nextSibling, Le = q.nextSibling, dt = pe;
    return typeof dt == "function" ? It(dt, te) : pe = te, o(te, k(T, {
      when: d,
      get children() {
        var L = qn();
        return w(L, "for", e), c(L, `block text-sm font-medium mb-2 ${x ? "text-white" : "text-gray-700"}`), o(L, d, null), o(L, k(T, {
          when: u,
          get children() {
            return On();
          }
        }), null), L;
      }
    }), q), q.$$click = He, w(q, "id", e), w(q, "name", r), q.disabled = y, w(q, "aria-required", u), o(ve, k(T, {
      get when() {
        return Ue();
      },
      get fallback() {
        return (() => {
          var L = yr();
          return c(L, `block truncate ${x ? "text-gray-400" : "text-gray-500"}`), o(L, g), L;
        })();
      },
      get children() {
        return [(() => {
          var L = In();
          return o(L, () => Ue().label), L;
        })(), k(T, {
          get when() {
            return Ue().subtitle;
          },
          get children() {
            var L = yr();
            return c(L, `block text-sm truncate ${x ? "text-gray-400" : "text-gray-500"}`), o(L, () => Ue().subtitle), L;
          }
        })];
      }
    })), o(Ze, () => Ge(me)), o(te, k(T, {
      get when() {
        return R();
      },
      get children() {
        var L = Gn(), Je = L.firstChild, Ke = be;
        return typeof Ke == "function" ? It(Ke, L) : be = L, c(L, `
            absolute z-50 w-full mt-2 bg-white border border-gray-200 rounded-lg shadow-xl
            ${x ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"}
          `), L.style.setProperty("max-height", "300px"), o(L, k(T, {
          when: G,
          get children() {
            var se = Hn(), Ye = se.firstChild, Me = Ye.firstChild, le = Me.nextSibling;
            c(Me, `absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none ${x ? "text-gray-400" : "text-gray-500"}`), o(Me, () => Ge("search", "w-4 h-4")), le.$$input = (Re) => ie(Re.target.value);
            var et = O;
            return typeof et == "function" ? It(et, le) : O = le, c(le, `
                    w-full pl-10 pr-3 py-2 text-sm border rounded-md focus:ring-2 focus:outline-none
                    ${x ? "bg-gray-700 border-gray-600 text-white placeholder-gray-400" : "bg-gray-50 border-gray-300 text-gray-900 placeholder-gray-500"}
                  `), D((Re) => (Re = f.accent) != null ? le.style.setProperty("ring-color", Re) : le.style.removeProperty("ring-color")), D(() => le.value = re()), se;
          }
        }), Je), c(Je, `max-h-60 overflow-y-auto ${x ? "bg-gray-800" : "bg-white"}`), o(Je, k(T, {
          get when() {
            return Xe().length > 0;
          },
          get fallback() {
            return (() => {
              var se = Wn();
              return c(se, `p-4 text-center text-sm ${x ? "text-gray-400" : "text-gray-500"}`), se;
            })();
          },
          get children() {
            return k(er, {
              get each() {
                return Xe();
              },
              children: (se, Ye) => (() => {
                var Me = Kn(), le = Me.firstChild, et = le.firstChild, Re = et.firstChild, Dt = Re.firstChild;
                return Me.$$click = () => We(se), o(Dt, () => se.label), o(Re, k(T, {
                  get when() {
                    return a() === se.value;
                  },
                  get children() {
                    var I = Jn();
                    return o(I, () => Ge("check", "w-4 h-4")), I;
                  }
                }), null), o(et, k(T, {
                  get when() {
                    return se.subtitle;
                  },
                  get children() {
                    var I = yr();
                    return c(I, `block text-sm truncate ${x ? "text-gray-400" : "text-gray-500"}`), o(I, () => se.subtitle), I;
                  }
                }), null), D((I) => {
                  var lt = se.disabled, yt = `
                      w-full px-4 py-3 text-left transition-colors duration-150
                      ${se.disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
                      ${a() === se.value ? x ? "bg-gray-700 text-white" : "bg-gray-100 text-gray-900" : x ? "text-gray-200 hover:bg-gray-700" : "text-gray-900 hover:bg-gray-50"}
                      ${K() === Ye() ? x ? "bg-gray-600" : "bg-gray-100" : ""}
                    `;
                  return lt !== I.e && (Me.disabled = I.e = lt), yt !== I.t && c(Me, I.t = yt), I;
                }, {
                  e: void 0,
                  t: void 0
                }), Me;
              })()
            });
          }
        })), L;
      }
    }), Le), w(Le, "name", r), D((L) => {
      var Je = `
          relative w-full max-w-80 sm:max-w-full px-4 py-3 text-left border rounded-lg 
          focus:ring-2 focus:outline-none transition-all duration-200
          ${y ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:shadow-md"}
          ${x ? "bg-gray-800/80 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"}
          ${R() ? "ring-2 shadow-lg" : ""}
        `, Ke = R() ? f.accent : void 0, se = f.accent, Ye = R(), Me = `ml-3 transition-transform duration-200 ${R() ? "transform rotate-180" : ""} ${x ? "text-gray-400" : "text-gray-500"}`;
      return Je !== L.e && c(q, L.e = Je), Ke !== L.t && ((L.t = Ke) != null ? q.style.setProperty("border-color", Ke) : q.style.removeProperty("border-color")), se !== L.a && ((L.a = se) != null ? q.style.setProperty("ring-color", se) : q.style.removeProperty("ring-color")), Ye !== L.o && w(q, "aria-expanded", L.o = Ye), Me !== L.i && c(Ze, L.i = Me), L;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0
    }), D(() => Le.value = a()), te;
  })();
};
Cr(["click", "input"]);
var Qn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"role=img aria-label="Tour selection"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7">'), Xn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"role=img aria-label="Fecha de partida"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">'), Zn = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"role=img aria-label="Información de viajeros"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z">'), eo = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"role=img aria-label="Confirmación de viaje"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">'), to = /* @__PURE__ */ p('<svg fill=none stroke=currentColor viewBox="0 0 24 24"role=img aria-label=Step><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z">'), ro = /* @__PURE__ */ p('<svg xmlns=http://www.w3.org/2000/svg stroke=currentColor fill=none viewBox="0 0 24 24"role=img aria-label="Completed step"><path d="M4 12.6111L8.92308 17.5L20 6.5"stroke-width=2 stroke-linecap=round stroke-linejoin=round>'), no = /* @__PURE__ */ p("<script type=application/ld+json>"), oo = /* @__PURE__ */ p("<div class=mb-8><div id=service-help class=sr-only>Choose the service you want to book from the available options"), io = /* @__PURE__ */ p('<p class="text-sm text-blue-700">'), lo = /* @__PURE__ */ p('<div class="mb-8 p-4 bg-blue-50 border border-blue-200 rounded-lg"><div class="flex items-center space-x-3"><div class=flex-shrink-0><svg class="w-6 h-6 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg></div><div><h3 class="text-lg font-medium text-blue-900">'), ao = /* @__PURE__ */ p("<div class=mb-6><div id=duration-help class=sr-only>Selecciona el paquete de tour que prefieras. El precio varía según la duración del viaje."), so = /* @__PURE__ */ p('<aside class="bg-green-50 border-l-4 border-green-500 rounded-lg shadow-md p-4 flex items-center justify-between"role=alert aria-live=assertive><div class="flex items-center"><svg class="w-10 h-10 text-green-500 mr-3 flex-shrink-0"fill=currentColor viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"></path></svg><div><p class="text-sm text-green-700"><strong class=block>¡Tour para HOY (<!>)!</strong>Las salidas del mismo día solo se confirman por WhatsApp.</p><a href="https://api.whatsapp.com/send/?phone=51906597850&amp;text&amp;type=phone_number&amp;app_absent=0"target=_blank rel="noopener noreferrer"class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-300 block mt-2 inline-flex items-center"aria-label="Contactarnos vía WhatsApp para tour del mismo día">Contactar por WhatsApp'), co = /* @__PURE__ */ p('<div role=status aria-live=polite><p>No departure times available</p><div class="text-xs mt-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">'), uo = /* @__PURE__ */ p("<div><div id=time-help class=sr-only>Selecciona tu hora de salida preferida para el tour"), go = /* @__PURE__ */ p('<div class="bg-gray-50 border border-gray-200 rounded-lg p-4"><div class="flex items-center space-x-3"><div class=flex-shrink-0><svg class="w-6 h-6 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div><div><h3 class="text-sm font-medium text-gray-700">Hora de Salida</h3><p class="text-sm text-gray-600">Este tour sale a las <strong>'), po = /* @__PURE__ */ p('<article class=space-y-6 role=tabpanel aria-labelledby=step1-heading><header class="text-center mb-8"><h1 id=step1-heading></h1><p></p></header><div class=mb-6><div id=date-help class=sr-only>Elige tu fecha de partida preferida para el tour. Las salidas del mismo día requieren contacto por WhatsApp.'), fo = /* @__PURE__ */ p('<div class="bg-gray-50 p-4 rounded-lg border border-gray-200"><div class="flex items-center mb-3"><svg class="w-5 h-5 mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg><label class="text-sm font-semibold text-gray-700">Tipo de Alojamiento </label></div><select class="w-full px-4 py-3 bg-white border-amber-300 text-gray-900 border rounded-lg focus:ring-2 focus:ring-amber-300 focus:outline-none transition-colors duration-200"><option value>Select accommodation type...</option><option value=hotel-3star>3-Star Hotel</option><option value=hotel-4star>4-Star Hotel</option><option value=hotel-5star>5-Star Hotel (Luxury)</option><option value=hostel>Hostel/Backpacker</option><option value=airbnb>Airbnb/Apartment</option><option value=camping>Camping</option><option value=lodge>Lodge/Refuge</option></select><div class=sr-only>Selecciona el tipo de alojamiento incluido en tu tour de <!> días</div><p class="text-xs text-amber-700 mt-2 flex items-center"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>Alojamiento incluido para tour de <!> '), ho = /* @__PURE__ */ p('<div class="bg-gray-50 p-4 rounded-lg border border-gray-200"><div class="flex items-center mb-3"><svg class="w-5 h-5 mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg><label class="text-sm font-semibold text-gray-700">Room Configuration *</label></div><select class="w-full px-4 py-3 bg-white border-gray-300 text-gray-900 border rounded-lg focus:ring-2 focus:ring-gray-300 focus:outline-none transition-colors duration-200"><option value>Select room configuration...</option><option value=single>Single Room</option><option value=double>Double Room (2 beds)</option><option value=matrimonial>Double Room (1 bed)</option><option value=triple>Triple Room</option><option value=family>Family Room</option><option value=shared>Shared Room</option></select><div class=sr-only>Selecciona la configuración de habitación que necesitas para <!> viajero</div><p class="text-xs text-blue-700 mt-2">Para <!> viajero<!> - elige la opción que mejor se adapte a tu grupo'), mo = /* @__PURE__ */ p('<div class=md:col-span-2><div class="bg-gray-50 p-4 rounded-lg border border-gray-200"><div class="flex items-center mb-3"><svg class="w-5 h-5 mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg><label class="text-sm font-semibold text-gray-700">Lugar de Recojo </label></div><input type=text class="w-full px-4 py-3 bg-white border-gray-300 text-gray-900 border rounded-lg focus:ring-2 focus:ring-gray-300 focus:outline-none transition-colors duration-200"placeholder="Hotel, dirección o punto de referencia donde te recogeremos"><div class=sr-only>Indica dónde prefieres que te recojamos para el inicio del tour</div><p class="text-xs text-green-700 mt-2 flex items-center"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>Te contactaremos 1 hora antes para confirmar la ubicación exacta'), bo = /* @__PURE__ */ p('<div class="p-6 rounded-lg bg-gray-50 border border-gray-200"><div class="flex items-center mb-4"><svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg><label class="text-lg font-semibold text-green-900">Lugar de Recojo</label></div><input type=text class="w-full px-4 py-3 bg-white border-green-300 text-green-900 placeholder-green-600 border rounded-lg focus:ring-2 focus:ring-green-300 focus:border-green-400 focus:outline-none transition-all duration-200"placeholder="Hotel, aeropuerto, dirección específica..."><p class="text-sm text-green-700 mt-2">Indica dónde te gustaría que te recojan para iniciar el tour'), vo = /* @__PURE__ */ p('<div class="p-6 rounded-lg bg-gray-50 border border-gray-200"><div class="flex items-center mb-4"><svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path></svg><label class="text-lg font-semibold text-indigo-900">Idioma del Guía Preferido</label></div><select class="w-full px-4 py-3 bg-white border-indigo-300 text-indigo-900 border rounded-lg focus:ring-2 focus:ring-indigo-300 focus:border-indigo-400 focus:outline-none transition-all duration-200"><option value>Selecciona idioma preferido</option><option value=spanish>Español</option><option value=english>Inglés</option><option value=portuguese>Portugués</option><option value=french>Francés</option><option value=german>Alemán</option><option value=italian>Italiano</option></select><p class="text-sm text-indigo-700 mt-2">Indicamos tu preferencia al asignar el guía turístico'), yo = /* @__PURE__ */ p('<article class=space-y-6 role=tabpanel aria-labelledby=step2-heading><header class="text-center mb-8"><h1 id=step2-heading>Detalles del Viajero</h1><p>Información necesaria para confirmar tu reserva de tour</p></header><div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div><label>Nombre Completo *</label><input type=text required autocomplete=name placeholder="Nombre completo del viajero principal"><div class=sr-only>Ingrese el nombre completo tal como aparecerá en la reserva del tour</div></div><div><label>Email de Contacto *</label><input type=email required autocomplete=email placeholder=tu@email.com><div class=sr-only>Ingresa una dirección de email válida para recibir la confirmación del tour</div></div><div class=md:col-span-2><label>Teléfono / WhatsApp *</label><input type=tel required autocomplete=tel placeholder="+51 999 888 777"><div class=sr-only>Número de teléfono para contactarte sobre el tour y en caso de emergencias</div><p class="text-xs text-gray-500 mt-1"><svg class="w-4 h-4 inline mr-1 text-gray-500"fill=currentColor viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"></path></svg>Preferimos WhatsApp para comunicación durante el tour y actualizaciones</p></div></div><div role=group class="bg-gray-50 p-6 rounded-lg border border-gray-200"><div class="flex items-center mb-4"><svg class="w-5 h-5 mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg><h3>Número de Viajeros *</h3></div><div class="flex items-center justify-center space-x-8"><button type=button aria-label="Disminuir número de viajeros"><svg class="w-6 h-6 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=3 d="M20 12H4"></path></svg></button><div aria-live=polite><div class="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-2 shadow-lg border-4 border-teal-100"><span class="text-3xl font-bold text-gray-500"></span></div><p class="text-sm font-medium text-teal-700"aria-hidden=true></p></div><button type=button aria-label="Aumentar número de viajeros"><svg class="w-6 h-6 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=3 d="M12 4v16m8-8H4"></path></svg></button></div><div class=sr-only>Usa los botones para ajustar el número de viajeros (1-20 personas)</div><div class="flex items-center justify-center text-xs text-gray-500 mt-3 font-medium"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>Máximo 20 viajeros por reserva</div></div><div class=space-y-6></div><div class="p-6 rounded-lg bg-gray-50 border border-gray-200"><div class="flex items-center mb-4"><svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2zM12 6v6"></path></svg><label class="text-lg font-semibold text-red-900">Contacto de Emergencia (Opcional)</label></div><input type=text class="w-full px-4 py-3 bg-white border-red-300 text-red-900 placeholder-red-600 border rounded-lg focus:ring-2 focus:ring-red-300 focus:border-red-400 focus:outline-none transition-all duration-200"placeholder="Nombre y teléfono de familiar/amigo"><p class="text-sm text-red-700 mt-2">Persona a contactar en caso de emergencia durante el tour</p></div><div class="p-6 rounded-lg bg-gray-50 border border-gray-200"><div class="flex items-center mb-4"><svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg><label class="text-lg font-semibold text-orange-900">Solicitudes Especiales (Opcional)</label></div><textarea rows=4 class="w-full px-4 py-3 bg-white border-orange-300 text-orange-900 placeholder-orange-600 border rounded-lg focus:ring-2 focus:ring-orange-300 focus:border-orange-400 focus:outline-none transition-all duration-200 resize-none"placeholder="Menciona cualquier solicitud especial para tu viaje: celebraciones, actividades específicas, necesidades especiales..."></textarea><div class="flex flex-wrap gap-2 mt-3"><div class="flex items-center text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full"><svg class="w-3 h-3 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>Celebración especial</div><div class="flex items-center text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full"><svg class="w-3 h-3 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>Sesión fotográfica</div><div class="flex items-center text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full"><svg class="w-3 h-3 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>Actividad especial'), $o = /* @__PURE__ */ p("<p>"), xo = /* @__PURE__ */ p('<div class="mb-4 pb-4 border-b border-gray-300"><h3><svg class="w-5 h-5 inline mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path></svg>Detalles del Tour</h3><p>'), wo = /* @__PURE__ */ p('<span class="bg-amber-100 text-amber-800 px-2 py-1 rounded-full text-xs font-medium">TODAY'), _o = /* @__PURE__ */ p('<div><dt class="inline font-medium">Alojamiento:</dt><dd class="inline ml-1 capitalize">'), ko = /* @__PURE__ */ p('<div><dt class="inline font-medium">Habitación:</dt><dd class="inline ml-1 capitalize">'), So = /* @__PURE__ */ p('<div><dt class="inline font-medium">Lugar de recojo:</dt><dd class="inline ml-1">'), Co = /* @__PURE__ */ p('<div><h3><svg class="w-5 h-5 inline mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M7 8h10m0 0V6a2 2 0 00-2-2H9a2 2 0 00-2 2v2m0 0v10a2 2 0 002 2h8a2 2 0 002-2V8M9 12h6m-6 4h6"></path></svg>Preferencias Especiales</h3><p>'), Do = /* @__PURE__ */ p('<article class=space-y-6 role=tabpanel aria-labelledby=step3-heading><header class="text-center mb-8"><h1 id=step3-heading>Confirmar Reserva de Tour</h1><p>Revisa todos los detalles de tu viaje antes de confirmar</p></header><section aria-labelledby=booking-summary-heading><h2 id=booking-summary-heading class=sr-only>Booking Summary</h2><div class="mb-4 pb-4 border-b border-gray-300"><h3><svg class="w-5 h-5 inline mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>Fecha y Hora de Partida</h3><div class="flex items-center space-x-2"><p></p></div><p><svg class="w-4 h-4 inline mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></p></div><div class="mb-4 pb-4 border-b border-gray-300"><h3><svg class="w-5 h-5 inline mr-2 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>Información del Viajero</h3><dl><div><dt class="inline font-medium">Nombre:</dt><dd class="inline ml-1"></dd></div><div><dt class="inline font-medium">Email:</dt><dd class="inline ml-1"></dd></div><div><dt class="inline font-medium">Teléfono:</dt><dd class="inline ml-1"></dd></div><div><dt class="inline font-medium">Viajeros:</dt><dd class="inline ml-1"> </dd></div></dl></div></section><button type=submit aria-describedby=submit-help class="w-full py-4 font-semibold text-lg rounded-lg transition-all duration-200 flex items-center justify-center hover:opacity-90"></button><div id=submit-help class=sr-only>Haz clic para enviar tu solicitud de reserva. Recibirás un email de confirmación del tour.'), Mo = /* @__PURE__ */ p('<button type=button aria-label="Continuar al siguiente paso">Continuar<svg class="w-5 h-5 ml-2"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), jo = /* @__PURE__ */ p("<aside role=alert aria-live=assertive>"), Eo = /* @__PURE__ */ p("<input type=hidden name=service>"), To = /* @__PURE__ */ p("<input type=hidden name=service_title>"), Ao = /* @__PURE__ */ p('<main class=space-y-6 data-booking-form=true role=main aria-label="Booking appointment form"><nav aria-label="Booking form progress"class=mb-8><h2 class=sr-only>Booking Steps Progress</h2><div></div><div role=progressbar aria-valuemin=1 aria-valuemax=3><div class="h-2 rounded-full transition-all duration-500 ease-out bg-teal-500"></div></div></nav><section data-step-content=true aria-live=polite aria-atomic=true></section><nav class="flex justify-between items-center pt-8"aria-label="Navegación del formulario"><button type=button aria-label="Volver al paso anterior"><svg class="w-5 h-5 mr-2"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7"></path></svg>Anterior</button><div class="flex items-center space-x-2"><span>Paso <!> de 3</span><div class="flex space-x-1"></div></div></nav><div class=sr-only aria-hidden=true><input type=hidden name=date><input type=hidden name=recipient_email>'), Bo = /* @__PURE__ */ p("<div role=button><div aria-hidden=true></div><span>"), Po = /* @__PURE__ */ p('<div><p><strong>Tour:</strong> </p><p><strong>Tour ID:</strong> </p><p><strong>Hours configured:</strong> </p><p><strong>Hours from service:</strong> </p><p><strong>useSingleService:</strong> </p><p class="mt-2 text-yellow-700"><strong>⚠️ To configure departure times:</strong><br>1. Go to WordPress Admin → Tours → Edit this tour<br>2. Click on <strong>"Availability"</strong> tab<br>3. In <strong>"Departure Times"</strong> section, add times (e.g., 09:00, 14:00)<br>4. Click <strong>"Update"</strong> to save'), Lo = /* @__PURE__ */ p("<div><label>Email de Contacto *</label><input type=email required placeholder=ejemplo@email.com>"), No = /* @__PURE__ */ p('<div><label>Teléfono/WhatsApp *</label><input type=tel required placeholder="+51 999 999 999">'), zo = /* @__PURE__ */ p("<div><label>Birth Date *</label><input type=date>"), Uo = /* @__PURE__ */ p("<div><label>Tipo de Documento *</label><select><option value>Seleccionar tipo</option><option value=dni>DNI</option><option value=passport>Pasaporte</option><option value=ce>Carnet de Extranjería"), Ro = /* @__PURE__ */ p('<div><label>Número de Documento *</label><input type=text placeholder="Número del documento">'), Vo = /* @__PURE__ */ p("<div><label>Nationality *</label><select><option value>Select nationality"), Fo = /* @__PURE__ */ p("<div><label>Gender *</label><select><option value>Select gender</option><option value=male>Male</option><option value=female>Female</option><option value=other>Other</option><option value=prefer-not-to-say>Prefer not to say"), Oo = /* @__PURE__ */ p('<div><label>Student Status</label><div class="flex items-center space-x-3"><label class="flex items-center"><input type=checkbox class="w-4 h-4 text-gray-500 bg-gray-100 border-gray-300 rounded focus:ring-teal-500 focus:ring-2"><span>I am a student (discount may apply)'), qo = /* @__PURE__ */ p('<div><label>Restricciones Alimentarias</label><textarea rows=2 placeholder="Vegetariano, vegano, alergias, etc...">'), Io = /* @__PURE__ */ p('<div><label>Condiciones Médicas Relevantes</label><textarea rows=2 placeholder="Diabetes, hipertensión, movilidad reducida, etc...">'), Ho = /* @__PURE__ */ p('<div><div class="flex items-center mb-4"></div><div class="grid grid-cols-1 md:grid-cols-2 gap-4"><div><label>Nombre Completo *</label><input type=text required placeholder="Ingresa el nombre completo"></div></div><div class="mt-4 space-y-4">'), Go = /* @__PURE__ */ p('<svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z">'), Yo = /* @__PURE__ */ p("<h3>Viajero Principal (Contacto)"), Wo = /* @__PURE__ */ p('<svg class="w-6 h-6 mr-3 text-gray-500"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m3 5.197H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z">'), Jo = /* @__PURE__ */ p("<h3>Viajero "), Ko = /* @__PURE__ */ p("<option>"), Qo = /* @__PURE__ */ p('<svg class="w-6 h-6 mr-3 animate-spin"fill=none stroke=currentColor viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15">'), Xo = /* @__PURE__ */ p("<span>Procesando Reserva..."), Zo = /* @__PURE__ */ p('<svg class="w-6 h-6 mr-3"fill=none stroke=currentColor viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z">'), ei = /* @__PURE__ */ p("<span>CONFIRMAR RESERVA DE VIAJE"), ti = /* @__PURE__ */ p("<div>");
const ri = (t) => {
  const {
    formId: e = "booking-form",
    services: r = [],
    isDarkMode: n = !1,
    accentColor: a = "#D4B254",
    ajaxUrl: s = "",
    useSingleService: g = !1,
    emailRecipient: d = "",
    businessName: u = "Business Name",
    // SEO: Para schema markup
    businessUrl: y = "",
    // SEO: Para schema markup
    serviceType: x = "Service"
    // SEO: Para schema markup
  } = t, [f, me] = A(""), [G, R] = A(""), [ee, re] = A(""), [ie, K] = A(""), [F, pe] = A(""), [be, O] = A(""), [Ue, Xe] = A(""), [He, We] = A(""), [Y, it] = A(1), [Ge, te] = A(d), [q, ce] = A(""), [ve, Ze] = A(""), [Le, dt] = A(""), [L, Je] = A("");
  A([]);
  const [Ke, se] = A(""), [Ye, Me] = A(""), [le, et] = A([]), [Re, Dt] = A([]), [I, lt] = A(1), [yt, Ut] = A(/* @__PURE__ */ new Set()), [Mt, Rt] = A(!1), [jt, Et] = A(!1), [Tt, h] = A({
    type: "",
    message: ""
  }), [_, P] = A([]), [S, ye] = A([]), [U, $e] = A(null), [ne, N] = A(""), [W, Ne] = A(null), [$t, Vt] = A(!g), [Wt, xt] = A(!1), Qe = 3, Jt = () => g || !Bt() ? [{
    step: 1,
    title: "Fecha y Salida",
    icon: "calendar",
    description: "Selecciona fecha y hora de partida"
  }, {
    step: 2,
    title: "Detalles de Viajeros",
    icon: "travelers",
    description: "Información personal y preferencias"
  }, {
    step: 3,
    title: "Confirmación de Tour",
    icon: "luggage",
    description: "Revisa tu reserva de viaje"
  }] : [{
    step: 1,
    title: "Selección de Tour",
    icon: "map",
    description: "Elige tu aventura perfecta"
  }, {
    step: 2,
    title: "Detalles de Viajeros",
    icon: "travelers",
    description: "Información personal y preferencias"
  }, {
    step: 3,
    title: "Confirmación de Tour",
    icon: "luggage",
    description: "Revisa tu reserva de viaje"
  }], ze = {
    primary: "#6B7280",
    // Gray-500 - neutral and clean
    secondary: "#F9FAFB",
    // Gray-50 - very light background
    accent: a,
    // Keep user's accent color
    light: "#F3F4F6",
    // Gray-100 - subtle backgrounds
    border: "#E5E7EB",
    // Gray-200 - clean borders
    text: "#374151",
    // Gray-700 - readable text
    dark: "#1F2937"
    // Gray-800 - strong contrast
  }, At = () => {
    if (!U() || !F() || !be()) return null;
    const i = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: U().title,
      provider: {
        "@type": "Organization",
        name: u,
        url: y
      },
      serviceType: x,
      availableChannel: {
        "@type": "ServiceChannel",
        serviceUrl: y,
        availableLanguage: "es"
      }
    };
    return JSON.stringify(i);
  }, Ft = async () => {
    var l;
    try {
      const i = s || ((l = window.wptbtBooking) == null ? void 0 : l.ajaxurl) || "/wp-admin/admin-ajax.php", m = await fetch(i, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "action=wptbt_get_fresh_nonce"
      });
      if (!m.ok) throw new Error(`HTTP error! status: ${m.status}`);
      const v = await m.json();
      if (v.success && v.data.nonce)
        return N(v.data.nonce), v.data.nonce;
      throw new Error("Invalid nonce response");
    } catch (i) {
      throw console.error("[DEBUG] Error getting fresh nonce:", i), i;
    }
  }, C = (l, i = "wptbt-booking-form-block") => {
    const m = window.wptbtI18n_booking_form || {};
    return m[l] ? m[l] : Mn(l, i);
  };
  function xe() {
    const l = (/* @__PURE__ */ new Date()).toLocaleDateString("es-PE", {
      timeZone: "America/Lima",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }), [i, m, v] = l.split("/");
    return `${v}-${m}-${i}`;
  }
  const qe = (l) => {
    if (!l) return !1;
    const i = xe();
    return l === i;
  }, sr = (l) => {
    switch (l) {
      case 1:
        if (qe(F()))
          return !1;
        const i = ur();
        return !i && _().length > 0 && !be() && O(_()[0]), g || !Bt() ? F() && (i ? be() : !0) : ie() && F() && (i ? be() : !0);
      case 2:
        const m = W();
        let v = f() && G() && ee() && Y() > 0;
        m && m.pickup_required && !Le() && (v = !1), m && m.includes_accommodation && (!q() || !ve()) && (v = !1);
        const M = le(), tt = Y();
        if (m && (m.require_traveler_details || m.require_documents)) {
          M.length !== tt && (v = !1);
          for (const Ve of M) {
            if (m.require_traveler_details && (!Ve.name || !Ve.age)) {
              v = !1;
              break;
            }
            if (m.require_documents && (!Ve.documentType || !Ve.documentNumber)) {
              v = !1;
              break;
            }
            if (m.required_traveler_fields && m.required_traveler_fields.includes("nationality") && !Ve.nationality) {
              v = !1;
              break;
            }
            if (m.required_traveler_fields && m.required_traveler_fields.includes("gender") && !Ve.gender) {
              v = !1;
              break;
            }
          }
        }
        return v;
      case 3:
        return !0;
      default:
        return !1;
    }
  };
  mt(() => {
    const l = I(), i = sr(l);
    Rt(i);
  }), mt(() => {
    const l = F();
    xt(qe(l));
  }), mt(() => {
    I() > 1 && setTimeout(() => {
      const i = document.querySelector(`#${e}`) || document.querySelector("[data-booking-form]") || document.querySelector(".space-y-6");
      i ? i.scrollIntoView({
        behavior: "smooth",
        block: "start",
        inline: "nearest"
      }) : window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    }, 100);
  });
  const dr = async () => {
    try {
      const l = await fetch("/wp-content/themes/wp-tailwind-theme-travel/src/public/js/json/paises-del-mundo.json");
      if (l.ok) {
        const i = await l.json();
        Dt(i), console.log("[DEBUG] Loaded countries:", i.length);
      } else
        console.warn("[DEBUG] Failed to load countries data");
    } catch (l) {
      console.error("[DEBUG] Error loading countries:", l);
    }
  };
  _r(async () => {
    try {
      await Ft(), await dr();
    } catch (l) {
      console.error("[DEBUG] Failed to load initial nonce:", l), h({
        type: "error",
        message: C("Error loading form. Please refresh the page.")
      });
    }
    if (console.log("[DEBUG] Services data:", r), console.log("[DEBUG] useSingleService:", g), Array.isArray(r) && r.length > 0) {
      const l = r[0].id;
      console.log("[DEBUG] Setting initial service:", l);
      const i = String(l);
      if (K(i), g) {
        const m = r[0];
        console.log("[DEBUG] Single service - serviceObj:", m), m && m.booking_config ? (console.log("[DEBUG] Single service - setting tour configuration immediately:", m.booking_config), Ne(m.booking_config), console.log("[DEBUG] Single service - current config after set:", W())) : console.log("[DEBUG] Single service - no booking_config found in serviceObj");
      }
      setTimeout(() => {
        wt(i);
      }, 0);
    } else
      console.warn("[DEBUG] No valid services found:", r);
  }), mt(() => {
    const l = cr();
    if (l.length === 1 && !ie()) {
      const i = l[0].value;
      console.log("[DEBUG] Auto-selecting single available service:", i), K(String(i)), wt(String(i));
    }
  });
  const wt = (l) => {
    if (!l) return;
    console.log("[DEBUG] Updating service details for:", l);
    const i = r.find((m) => m.id === l);
    if (i) {
      if (console.log("[DEBUG] Found service object:", i), $e(i), i.booking_config ? (console.log("[DEBUG] updateServiceDetails - Setting tour configuration:", i.booking_config), Ne(i.booking_config), console.log("[DEBUG] updateServiceDetails - current config after set:", W())) : (console.log("[DEBUG] updateServiceDetails - no booking_config, using fallback"), Ne({
        duration_days: 1,
        includes_accommodation: !1,
        requires_documents: !1,
        has_flexible_schedule: !0,
        pickup_required: !1,
        emergency_contact_required: !1,
        languages_available: ["es"],
        required_traveler_fields: []
      })), Array.isArray(i.hours) && i.hours.length > 0 ? (console.log("[DEBUG] Setting available times:", i.hours), console.log("[DEBUG] Tour ID:", i.id, "- Available Times:", i.hours, "- Hours from Service:", i.hours), P([...i.hours])) : (console.log("[DEBUG] No hours found for service - serviceObj.hours:", i.hours), console.log("[DEBUG] Tour ID:", i.id, "- Full service object:", i), P([])), Array.isArray(i.durations) && i.durations.length > 0) {
        console.log("[DEBUG] Setting available durations:", i.durations), ye([...i.durations]);
        const m = i.durations[0];
        m && m.value && We(m.value);
      } else {
        const m = [];
        if (i.duration1 && i.price1) {
          const v = parseInt(i.duration1.replace(/[^0-9]/g, "")) || 0;
          m.push({
            minutes: v * 24 * 60,
            // Convert days to minutes for compatibility
            price: i.price1,
            text: `${i.duration1} días - $${i.price1.replace("$", "")}`,
            duration: i.duration1,
            value: `${v}days-${i.price1}`
          });
        }
        if (i.duration2 && i.price2) {
          const v = parseInt(i.duration2.replace(/[^0-9]/g, "")) || 0;
          m.push({
            minutes: v * 24 * 60,
            // Convert days to minutes for compatibility
            price: i.price2,
            text: `${i.duration2} días - $${i.price2.replace("$", "")}`,
            duration: i.duration2,
            value: `${v}days-${i.price2}`
          });
        }
        console.log("[DEBUG] Setting fallback durations:", m), ye(m), m.length > 0 && m[0].value && We(m[0].value);
      }
      O("");
    } else
      console.log("[DEBUG] Service not found for ID:", l), P([]), ye([]), $e(null);
  }, Xr = () => {
    Mt() && I() < Qe && (Ut((l) => /* @__PURE__ */ new Set([...l, I()])), lt((l) => l + 1));
  }, Zr = () => {
    I() > 1 && lt((l) => l - 1);
  }, Mr = (l) => {
    (l <= I() || yt().has(l - 1)) && lt(l);
  }, en = (l) => {
    console.log("[DEBUG] Service changed to:", l);
    const i = String(l);
    K(i), setTimeout(() => {
      wt(i);
    }, 0);
  }, jr = (l) => {
    if (!l) return "";
    try {
      const [i, m] = l.split(":"), v = parseInt(i, 10), M = v >= 12 ? "PM" : "AM";
      return `${v % 12 === 0 ? 12 : v % 12}:${m} ${M}`;
    } catch {
      return l;
    }
  }, tn = (l) => {
    const i = l.target.value;
    pe(i);
  }, Er = (l) => {
    if (!l) return "";
    try {
      return new Date(Date.parse(`${l}T00:00:00`)).toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
      });
    } catch {
      return l;
    }
  }, cr = oe(() => (console.log("[DEBUG] Creating service options from:", r), r.map((l) => {
    var i;
    return {
      value: l.id,
      label: l.title,
      subtitle: l.subtitle || `${((i = l.durations) == null ? void 0 : i.length) || 0} duration options`,
      disabled: !1
    };
  }))), Bt = oe(() => g ? !1 : cr().length > 1);
  oe(() => (W(), !0));
  const rn = oe(() => (W(), !0)), ur = oe(() => {
    const l = _();
    return Array.isArray(l) && l.length > 1;
  }), nn = oe(() => {
    const l = W();
    console.log("[DEBUG] shouldShowDocumentFields - config:", l);
    const i = l && l.requires_documents;
    return console.log("[DEBUG] shouldShowDocumentFields - result:", i), i;
  }), _t = (l) => {
    const i = W();
    if (console.log(`[DEBUG] isFieldRequired('${l}') - config:`, i), !i)
      return console.log(`[DEBUG] isFieldRequired('${l}') - no config, returning false`), !1;
    const m = i.required_traveler_fields && i.required_traveler_fields.includes(l);
    return console.log(`[DEBUG] isFieldRequired('${l}') - result:`, m), m;
  }, gr = oe(() => {
    const l = W();
    return l ? l.duration_days : 1;
  });
  mt(() => {
    const l = Y(), i = le();
    if (i.length !== l) {
      const m = [];
      for (let v = 0; v < l; v++) {
        const M = i[v] || {};
        m.push({
          id: v,
          name: v === 0 ? f() : M.name || "",
          email: v === 0 ? G() : M.email || "",
          phone: v === 0 ? ee() : M.phone || "",
          birthDate: M.birthDate || "",
          documentType: M.documentType || "",
          documentNumber: M.documentNumber || "",
          nationality: M.nationality || "",
          gender: M.gender || "",
          isStudent: M.isStudent || !1,
          dietaryRestrictions: M.dietaryRestrictions || "",
          medicalConditions: M.medicalConditions || ""
        });
      }
      et(m);
    }
  }), mt(() => {
    const l = pr();
    l.length === 1 && !He() && We(l[0].value);
  });
  const at = (l, i, m) => {
    const M = [...le()];
    M[l] && M[l][i] !== m && (M[l] = {
      ...M[l],
      [i]: m
    }, l === 0 && (i === "name" && f() !== m && me(m), i === "email" && G() !== m && R(m), i === "phone" && ee() !== m && re(m)), et(M));
  }, pr = oe(() => {
    const l = S();
    return console.log("[DEBUG] Creating duration options from:", l), Array.isArray(l) ? l.map((i) => ({
      value: i.value || `${i.minutes}days-${i.price}`,
      label: `${i.duration || i.minutes} días`,
      subtitle: `$${i.price.replace("$", "")}`,
      disabled: !1
    })) : (console.warn("[DEBUG] Durations is not an array:", l), []);
  }), Tr = oe(() => {
    const l = _();
    return console.log("[DEBUG] Creating time options from:", l), Array.isArray(l) ? l.map((i) => ({
      value: i,
      label: jr(i),
      disabled: !1
    })) : (console.warn("[DEBUG] Times is not an array:", l), []);
  }), on = async (l) => {
    var i;
    l.preventDefault(), Et(!0), h({
      type: "info",
      message: C("Processing your booking...")
    });
    try {
      let m = ne();
      m || (m = await Ft());
      const v = new FormData();
      v.append("action", "wptbt_submit_booking"), v.append("booking_nonce", m), v.append("recipient_email", Ge()), v.append("name", f()), v.append("email", G()), v.append("service", ie()), v.append("date", F()), v.append("time", be()), v.append("message", Ue()), v.append("visitors", Y()), v.append("phone", ee()), v.append("accommodation", q()), v.append("room_config", ve()), v.append("pickup_location", Le()), v.append("emergency_contact", L()), v.append("special_requests", Ke()), v.append("guide_language", Ye());
      const M = le();
      v.append("travelers_data", JSON.stringify(M)), He() && v.append("duration", He());
      const tt = r.find((fr) => fr.id === ie());
      tt && v.append("service_title", tt.title);
      const Ve = s || ((i = window.wptbtBooking) == null ? void 0 : i.ajaxurl) || "/wp-admin/admin-ajax.php", ct = await fetch(Ve, {
        method: "POST",
        credentials: "same-origin",
        body: v
      });
      if (!ct.ok)
        throw new Error(`Network response error: ${ct.status} ${ct.statusText}`);
      const ut = await ct.json();
      ut.success ? (h({
        type: "success",
        message: ut.data || C("Booking successfully made")
      }), setTimeout(() => {
        lt(1), Ut(/* @__PURE__ */ new Set()), me(""), R(""), Xe(""), pe(""), O(""), it(1), re(""), ce(""), Ze(""), dt(""), Je(""), se(""), r.length > 0 && (K(r[0].id), wt(r[0].id));
      }, 3e3)) : h({
        type: "error",
        message: ut.data || C("An error occurred. Please try again.")
      });
    } catch (m) {
      console.error("[DEBUG] Error submitting form:", m), h({
        type: "error",
        message: C("Connection error. Please try again later.")
      });
    } finally {
      Et(!1);
    }
  }, ln = (l, i, m) => {
    const v = `w-6 h-6 ${i || m ? "text-white" : n ? "text-gray-400" : "text-gray-500"}`;
    if (m)
      return (() => {
        var M = ro();
        return w(M, "class", v), M;
      })();
    switch (l) {
      case "map":
        return (() => {
          var M = Qn();
          return w(M, "class", v), M;
        })();
      case "calendar":
        return (() => {
          var M = Xn();
          return w(M, "class", v), M;
        })();
      case "travelers":
        return (() => {
          var M = Zn();
          return w(M, "class", v), M;
        })();
      case "luggage":
        return (() => {
          var M = eo();
          return w(M, "class", v), M;
        })();
      default:
        return (() => {
          var M = to();
          return w(M, "class", v), M;
        })();
    }
  };
  return [k(T, {
    get when() {
      return At();
    },
    get children() {
      var l = no();
      return o(l, At), l;
    }
  }), (() => {
    var l = Ao(), i = l.firstChild, m = i.firstChild, v = m.nextSibling, M = v.nextSibling, tt = M.firstChild, Ve = i.nextSibling, ct = Ve.nextSibling, ut = ct.firstChild, fr = ut.nextSibling, Kt = fr.firstChild, an = Kt.firstChild, Ar = an.nextSibling;
    Ar.nextSibling;
    var sn = Kt.nextSibling, hr = ct.nextSibling, Br = hr.firstChild, dn = Br.nextSibling;
    return w(l, "id", e), c(v, `flex justify-between items-center mb-4 ${n ? "text-white" : "text-gray-700"}`), o(v, k(er, {
      get each() {
        return Jt();
      },
      children: ($) => {
        const Q = () => I() === $.step, de = () => yt().has($.step), Se = () => $.step <= I() || de;
        return (() => {
          var J = Bo(), Ie = J.firstChild, V = Ie.nextSibling;
          return J.$$keydown = (z) => {
            (z.key === "Enter" || z.key === " ") && Se() && (z.preventDefault(), Mr($.step));
          }, J.$$click = () => Se() && Mr($.step), o(Ie, () => ln($.icon, Q(), de())), o(V, () => $.title), D((z) => {
            var Ce = `flex flex-col items-center cursor-pointer transition-all duration-300 ${Se() ? "hover:scale-105" : "cursor-not-allowed"}`, je = Se() ? 0 : -1, De = `Step ${$.step}: ${$.title}. ${$.description}. ${de() ? "Completed" : Q() ? "Current step" : "Not completed"}`, X = `
                      w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all duration-300
                      ${Q() ? "bg-opacity-100 shadow-lg transform scale-110  bg-teal-500" : de() ? "bg-opacity-80 shadow-md bg-teal-500" : n ? "bg-gray-700 border-2 border-gray-600" : "bg-gray-200 border-2 border-gray-300"}
                    `, Ee = `text-xs text-center font-medium transition-colors duration-300 ${Q() ? "text-current" : n ? "text-gray-400" : "text-gray-500"}`;
            return Ce !== z.e && c(J, z.e = Ce), je !== z.t && w(J, "tabindex", z.t = je), De !== z.a && w(J, "aria-label", z.a = De), X !== z.o && c(Ie, z.o = X), Ee !== z.i && c(V, z.i = Ee), z;
          }, {
            e: void 0,
            t: void 0,
            a: void 0,
            o: void 0,
            i: void 0
          }), J;
        })();
      }
    })), c(M, `w-full h-2 rounded-full ${n ? "bg-gray-700" : "bg-gray-200"}`), c(Ve, `min-h-96 p-6 rounded-lg transition-all z-10 relative duration-300 ${n ? "bg-gray-800/50" : "bg-white/50"} backdrop-blur-sm border ${n ? "border-gray-700" : "border-gray-200"}`), o(Ve, k(T, {
      get when() {
        return I() === 1;
      },
      get children() {
        var $ = po(), Q = $.firstChild, de = Q.firstChild, Se = de.nextSibling, J = Q.nextSibling, Ie = J.firstChild;
        return c(de, `text-2xl font-bold mb-2 ${n ? "text-white" : "text-gray-800"}`), o(de, () => g || !Bt() ? "Date & Time Selection" : "Service & Schedule Selection"), c(Se, `${n ? "text-gray-300" : "text-gray-600"}`), o(Se, () => g || !Bt() ? "Select when you'd like your appointment" : "Choose your preferred service and schedule"), o($, k(T, {
          get when() {
            return Bt();
          },
          get children() {
            var V = oo(), z = V.firstChild;
            return o(V, k($r, {
              id: `${e}-service`,
              name: "service",
              options: cr,
              value: ie,
              onChange: en,
              get placeholder() {
                return C("Select a service");
              },
              get labelText() {
                return C("Select Service");
              },
              required: !0,
              darkMode: n,
              colors: ze,
              "aria-describedby": "service-help"
            }), z), V;
          }
        }), J), o($, k(T, {
          get when() {
            return oe(() => !Bt())() && U();
          },
          get children() {
            var V = lo(), z = V.firstChild, Ce = z.firstChild, je = Ce.nextSibling, De = je.firstChild;
            return o(De, () => {
              var X;
              return (X = U()) == null ? void 0 : X.title;
            }), o(je, k(T, {
              get when() {
                var X;
                return (X = U()) == null ? void 0 : X.subtitle;
              },
              get children() {
                var X = io();
                return o(X, () => {
                  var Ee;
                  return (Ee = U()) == null ? void 0 : Ee.subtitle;
                }), X;
              }
            }), null), V;
          }
        }), J), o($, k(T, {
          get when() {
            return pr().length > 1;
          },
          get children() {
            var V = ao(), z = V.firstChild;
            return o(V, k($r, {
              id: `${e}-duration`,
              name: "duration",
              options: pr,
              value: He,
              onChange: We,
              placeholder: "Select tour package",
              labelText: "Tour Package",
              required: !0,
              darkMode: n,
              colors: ze,
              "aria-describedby": "duration-help"
            }), z), V;
          }
        }), J), o(J, k(Un, {
          id: `${e}-date`,
          name: "date",
          get value() {
            return F();
          },
          onChange: tn,
          required: !0,
          labelText: "Departure Date",
          placeholder: "Select your departure date",
          darkMode: n,
          colors: ze,
          "aria-describedby": "date-help"
        }), Ie), o($, k(T, {
          get when() {
            return qe(F());
          },
          get children() {
            var V = so(), z = V.firstChild, Ce = z.firstChild, je = Ce.nextSibling, De = je.firstChild, X = De.firstChild, Ee = X.firstChild, Ae = Ee.nextSibling;
            return Ae.nextSibling, o(X, () => Er(F()), Ae), V;
          }
        }), null), o($, k(T, {
          get when() {
            return ur();
          },
          get children() {
            var V = uo(), z = V.firstChild;
            return o(V, k($r, {
              id: `${e}-time`,
              name: "time",
              options: Tr,
              value: be,
              onChange: O,
              placeholder: "Select departure time",
              labelText: "Departure Time",
              required: !0,
              darkMode: n,
              colors: ze,
              "aria-describedby": "time-help"
            }), z), o(V, k(T, {
              get when() {
                return Tr().length === 0;
              },
              get children() {
                var Ce = co(), je = Ce.firstChild, De = je.nextSibling;
                return c(Ce, `text-center py-4 text-sm ${n ? "text-gray-400" : "text-gray-500"}`), o(De, (() => {
                  var X = oe(() => !!U());
                  return () => X() ? (() => {
                    var Ee = Po(), Ae = Ee.firstChild, gt = Ae.firstChild;
                    gt.nextSibling;
                    var Fe = Ae.nextSibling, Ot = Fe.firstChild;
                    Ot.nextSibling;
                    var rt = Fe.nextSibling, Pt = rt.firstChild;
                    Pt.nextSibling;
                    var kt = rt.nextSibling, St = kt.firstChild;
                    St.nextSibling;
                    var pt = kt.nextSibling, ft = pt.firstChild;
                    return ft.nextSibling, o(Ae, () => U().title, null), o(Fe, () => U().id, null), o(rt, () => _().length, null), o(kt, () => JSON.stringify(U().hours || []), null), o(pt, () => t.useSingleService ? "true" : "false", null), Ee;
                  })() : "Please select a tour first";
                })()), Ce;
              }
            }), null), V;
          }
        }), null), o($, k(T, {
          get when() {
            return oe(() => !!(!ur() && U()))() && _().length > 0;
          },
          get children() {
            var V = go(), z = V.firstChild, Ce = z.firstChild, je = Ce.nextSibling, De = je.firstChild, X = De.nextSibling, Ee = X.firstChild, Ae = Ee.nextSibling;
            return o(Ae, () => _()[0]), V;
          }
        }), null), $;
      }
    }), null), o(Ve, k(T, {
      get when() {
        return I() === 2;
      },
      get children() {
        var $ = yo(), Q = $.firstChild, de = Q.firstChild, Se = de.nextSibling, J = Q.nextSibling, Ie = J.firstChild, V = Ie.firstChild, z = V.nextSibling, Ce = z.nextSibling, je = Ie.nextSibling, De = je.firstChild, X = De.nextSibling, Ee = X.nextSibling, Ae = je.nextSibling, gt = Ae.firstChild, Fe = gt.nextSibling, Ot = Fe.nextSibling, rt = J.nextSibling, Pt = rt.firstChild, kt = Pt.firstChild, St = kt.nextSibling, pt = Pt.nextSibling, ft = pt.firstChild, qt = ft.nextSibling, Qt = qt.firstChild, Lt = Qt.firstChild, mr = Qt.nextSibling, nt = qt.nextSibling, ae = pt.nextSibling, Te = rt.nextSibling, fe = Te.nextSibling, ht = fe.firstChild, Pr = ht.nextSibling, cn = fe.nextSibling, un = cn.firstChild, Lr = un.nextSibling;
        return c(de, `text-2xl font-bold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(Se, `${n ? "text-gray-300" : "text-gray-600"}`), w(V, "for", `${e}-name`), c(V, `block text-sm font-medium mb-2 ${n ? "text-white" : "text-gray-700"}`), z.$$input = (b) => me(b.target.value), w(z, "id", `${e}-name`), w(z, "aria-describedby", `${e}-name-help`), c(z, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:outline-none transition-colors duration-200`), w(Ce, "id", `${e}-name-help`), w(De, "for", `${e}-email`), c(De, `block text-sm font-medium mb-2 ${n ? "text-white" : "text-gray-700"}`), X.$$input = (b) => R(b.target.value), w(X, "id", `${e}-email`), w(X, "aria-describedby", `${e}-email-help`), c(X, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:outline-none transition-colors duration-200`), w(Ee, "id", `${e}-email-help`), w(gt, "for", `${e}-phone`), c(gt, `block text-sm font-medium mb-2 ${n ? "text-white" : "text-gray-700"}`), Fe.$$input = (b) => re(b.target.value), w(Fe, "id", `${e}-phone`), w(Fe, "aria-describedby", `${e}-phone-help`), c(Fe, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:outline-none transition-colors duration-200`), w(Ot, "id", `${e}-phone-help`), o(J, k(T, {
          when: !0,
          get children() {
            return [(() => {
              var b = fo(), we = b.firstChild, ue = we.firstChild, _e = ue.nextSibling;
              _e.firstChild;
              var ge = we.nextSibling, Z = ge.nextSibling, ot = Z.firstChild, Be = ot.nextSibling;
              Be.nextSibling;
              var Oe = Z.nextSibling, Nt = Oe.firstChild, j = Nt.nextSibling, H = j.nextSibling;
              return H.nextSibling, w(_e, "for", `${e}-accommodation`), o(_e, () => {
                const E = W();
                return E && E.includes_accommodation ? "*" : "(opcional)";
              }, null), ge.$$input = (E) => ce(E.target.value), w(ge, "id", `${e}-accommodation`), w(ge, "aria-describedby", `${e}-accommodation-help`), w(Z, "id", `${e}-accommodation-help`), o(Z, gr, Be), o(Oe, gr, H), o(Oe, () => gr() === 1 ? "día" : "días", null), D(() => ge.value = q()), b;
            })(), k(T, {
              get when() {
                return oe(() => !!(q() && q() !== "camping"))() && q() !== "none";
              },
              get children() {
                var b = ho(), we = b.firstChild, ue = we.firstChild, _e = ue.nextSibling, ge = we.nextSibling, Z = ge.nextSibling, ot = Z.firstChild, Be = ot.nextSibling;
                Be.nextSibling;
                var Oe = Z.nextSibling, Nt = Oe.firstChild, j = Nt.nextSibling, H = j.nextSibling, E = H.nextSibling;
                return E.nextSibling, w(_e, "for", `${e}-room-config`), ge.$$input = (B) => Ze(B.target.value), w(ge, "id", `${e}-room-config`), w(ge, "aria-describedby", `${e}-room-config-help`), w(Z, "id", `${e}-room-config-help`), o(Z, Y, Be), o(Z, () => Y() > 1 ? "s" : "", null), o(Oe, Y, j), o(Oe, () => Y() > 1 ? "s" : "", E), D(() => ge.value = ve()), b;
              }
            })];
          }
        }), null), o(J, k(T, {
          when: !0,
          get children() {
            var b = mo(), we = b.firstChild, ue = we.firstChild, _e = ue.firstChild, ge = _e.nextSibling;
            ge.firstChild;
            var Z = ue.nextSibling, ot = Z.nextSibling;
            return w(ge, "for", `${e}-pickup`), o(ge, () => {
              const Be = W();
              return Be && Be.pickup_required ? "*" : "(opcional)";
            }, null), Z.$$input = (Be) => dt(Be.target.value), w(Z, "id", `${e}-pickup`), w(Z, "aria-describedby", `${e}-pickup-help`), w(ot, "id", `${e}-pickup-help`), D(() => Z.value = Le()), b;
          }
        }), null), w(rt, "aria-labelledby", `${e}-travelers-label`), w(St, "id", `${e}-travelers-label`), c(St, `text-lg font-semibold ${n ? "text-white" : "text-gray-800"}`), w(pt, "aria-describedby", `${e}-travelers-help`), ft.$$click = () => Y() > 1 && it((b) => b - 1), c(qt, `text-center min-w-32 ${n ? "text-white" : "text-gray-800"}`), o(Lt, Y), o(mr, () => Y() === 1 ? "Viajero" : "Viajeros"), nt.$$click = () => Y() < 20 && it((b) => b + 1), w(ae, "id", `${e}-travelers-help`), o(Te, k(er, {
          get each() {
            return Array.from({
              length: Y()
            }, (b, we) => we);
          },
          children: (b) => {
            const we = b + 1, ue = b === 0;
            return (() => {
              var _e = Ho(), ge = _e.firstChild, Z = ge.nextSibling, ot = Z.firstChild, Be = ot.firstChild, Oe = Be.nextSibling, Nt = Z.nextSibling;
              return c(_e, `p-6 rounded-xl border-2 transition-all duration-300 ${ue ? n ? "border-teal-500 bg-gray-800/70" : "border-teal-400 bg-teal-50/50" : n ? "border-gray-600 bg-gray-800/40" : "border-gray-200 bg-gray-50/50"}`), o(ge, ue ? [Go(), (() => {
                var j = Yo();
                return c(j, `text-lg font-semibold ${n ? "text-white" : "text-gray-800"}`), j;
              })()] : [Wo(), (() => {
                var j = Jo();
                return j.firstChild, c(j, `text-lg font-semibold ${n ? "text-white" : "text-gray-800"}`), o(j, we, null), j;
              })()]), c(Be, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), Oe.$$input = (j) => {
                at(b, "name", j.target.value);
              }, c(Oe, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), o(Z, k(T, {
                when: ue,
                get children() {
                  var j = Lo(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => R(B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => E.value = G()), j;
                }
              }), null), o(Z, k(T, {
                when: ue,
                get children() {
                  var j = No(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => re(B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => E.value = ee()), j;
                }
              }), null), o(Z, k(T, {
                get when() {
                  return _t("birth_date");
                },
                get children() {
                  var j = zo(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "birthDate", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => {
                    var B;
                    return E.value = ((B = le()[b]) == null ? void 0 : B.birthDate) || "";
                  }), j;
                }
              }), null), o(Z, k(T, {
                get when() {
                  return nn();
                },
                get children() {
                  return [(() => {
                    var j = Uo(), H = j.firstChild, E = H.nextSibling;
                    return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "documentType", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => {
                      var B;
                      return E.value = ((B = le()[b]) == null ? void 0 : B.documentType) || "";
                    }), j;
                  })(), (() => {
                    var j = Ro(), H = j.firstChild, E = H.nextSibling;
                    return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "documentNumber", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => {
                      var B;
                      return E.value = ((B = le()[b]) == null ? void 0 : B.documentNumber) || "";
                    }), j;
                  })()];
                }
              }), null), o(Z, k(T, {
                get when() {
                  return _t("nationality");
                },
                get children() {
                  var j = Vo(), H = j.firstChild, E = H.nextSibling;
                  return E.firstChild, c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "nationality", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), o(E, k(er, {
                    get each() {
                      return Re();
                    },
                    children: (B) => (() => {
                      var Ct = Ko();
                      return o(Ct, () => B.shortName), D(() => Ct.value = B.shortName), Ct;
                    })()
                  }), null), D(() => {
                    var B;
                    return E.value = ((B = le()[b]) == null ? void 0 : B.nationality) || "";
                  }), j;
                }
              }), null), o(Z, k(T, {
                get when() {
                  return _t("gender");
                },
                get children() {
                  var j = Fo(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "gender", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-900"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200`), D(() => {
                    var B;
                    return E.value = ((B = le()[b]) == null ? void 0 : B.gender) || "";
                  }), j;
                }
              }), null), o(Z, k(T, {
                get when() {
                  return _t("is_student");
                },
                get children() {
                  var j = Oo(), H = j.firstChild, E = H.nextSibling, B = E.firstChild, Ct = B.firstChild, gn = Ct.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), Ct.$$input = (Xt) => at(b, "isStudent", Xt.target.checked), c(gn, `ml-2 text-sm ${n ? "text-gray-300" : "text-gray-700"}`), D(() => {
                    var Xt;
                    return Ct.checked = ((Xt = le()[b]) == null ? void 0 : Xt.isStudent) || !1;
                  }), j;
                }
              }), null), o(Nt, k(T, {
                get when() {
                  return _t("dietary_restrictions");
                },
                get children() {
                  var j = qo(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "dietaryRestrictions", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200 resize-none`), D(() => {
                    var B;
                    return E.value = ((B = le()[b]) == null ? void 0 : B.dietaryRestrictions) || "";
                  }), j;
                }
              }), null), o(Nt, k(T, {
                get when() {
                  return _t("medical_conditions");
                },
                get children() {
                  var j = Io(), H = j.firstChild, E = H.nextSibling;
                  return c(H, `block text-sm font-medium mb-2 ${n ? "text-gray-300" : "text-gray-700"}`), E.$$input = (B) => at(b, "medicalConditions", B.target.value), c(E, `w-full px-4 py-3 ${n ? "bg-gray-800/80 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-900 placeholder-gray-500"} border rounded-lg focus:ring-2 focus:ring-teal-300 focus:border-teal-400 focus:outline-none transition-all duration-200 resize-none`), D(() => {
                    var B;
                    return E.value = ((B = le()[b]) == null ? void 0 : B.medicalConditions) || "";
                  }), j;
                }
              }), null), D(() => {
                var j;
                return Oe.value = ((j = le()[b]) == null ? void 0 : j.name) || "";
              }), _e;
            })();
          }
        })), o($, k(T, {
          get when() {
            return rn();
          },
          get children() {
            var b = bo(), we = b.firstChild, ue = we.nextSibling;
            return ue.$$input = (_e) => dt(_e.target.value), D(() => ue.value = Le()), b;
          }
        }), fe), o($, k(T, {
          get when() {
            return _t("guide_language");
          },
          get children() {
            var b = vo(), we = b.firstChild, ue = we.nextSibling;
            return ue.$$input = (_e) => Me(_e.target.value), D(() => ue.value = Ye()), b;
          }
        }), fe), Pr.$$input = (b) => Je(b.target.value), Lr.$$input = (b) => se(b.target.value), D((b) => {
          var we = ze.accent, ue = ze.accent, _e = ze.accent, ge = Y() <= 1, Z = `p-4 rounded-full transition-all duration-300 shadow-md ${Y() <= 1 ? "opacity-50 cursor-not-allowed bg-gray-200" : "bg-white hover:bg-teal-50 transform hover:scale-110 hover:shadow-lg border-2 border-teal-200"}`, ot = `${Y()} ${Y() === 1 ? "viajero" : "viajeros"}`, Be = Y() >= 20, Oe = `p-4 rounded-full transition-all duration-300 shadow-md ${Y() >= 20 ? "opacity-50 cursor-not-allowed bg-gray-200" : "bg-white hover:bg-teal-50 transform hover:scale-110 hover:shadow-lg border-2 border-teal-200"}`;
          return we !== b.e && ((b.e = we) != null ? z.style.setProperty("border-color", we) : z.style.removeProperty("border-color")), ue !== b.t && ((b.t = ue) != null ? X.style.setProperty("border-color", ue) : X.style.removeProperty("border-color")), _e !== b.a && ((b.a = _e) != null ? Fe.style.setProperty("border-color", _e) : Fe.style.removeProperty("border-color")), ge !== b.o && (ft.disabled = b.o = ge), Z !== b.i && c(ft, b.i = Z), ot !== b.n && w(Lt, "aria-label", b.n = ot), Be !== b.s && (nt.disabled = b.s = Be), Oe !== b.h && c(nt, b.h = Oe), b;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0,
          s: void 0,
          h: void 0
        }), D(() => z.value = f()), D(() => X.value = G()), D(() => Fe.value = ee()), D(() => Pr.value = L()), D(() => Lr.value = Ke()), $;
      }
    }), null), o(Ve, k(T, {
      get when() {
        return I() === 3;
      },
      get children() {
        var $ = Do(), Q = $.firstChild, de = Q.firstChild, Se = de.nextSibling, J = Q.nextSibling, Ie = J.firstChild, V = Ie.nextSibling, z = V.firstChild, Ce = z.nextSibling, je = Ce.firstChild, De = Ce.nextSibling;
        De.firstChild;
        var X = V.nextSibling, Ee = X.firstChild, Ae = Ee.nextSibling, gt = Ae.firstChild, Fe = gt.firstChild, Ot = Fe.nextSibling, rt = gt.nextSibling, Pt = rt.firstChild, kt = Pt.nextSibling, St = rt.nextSibling, pt = St.firstChild, ft = pt.nextSibling, qt = St.nextSibling, Qt = qt.firstChild, Lt = Qt.nextSibling, mr = Lt.firstChild, nt = J.nextSibling;
        return c(de, `text-2xl font-bold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(Se, `${n ? "text-gray-300" : "text-gray-600"}`), c(J, `p-6 rounded-lg ${n ? "bg-gray-700/50" : "bg-gray-50"} border ${n ? "border-gray-600" : "border-gray-200"}`), o(J, k(T, {
          get when() {
            return U();
          },
          get children() {
            var ae = xo(), Te = ae.firstChild, fe = Te.nextSibling;
            return c(Te, `font-semibold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(fe, `${n ? "text-gray-300" : "text-gray-600"}`), o(fe, () => {
              var ht;
              return (ht = U()) == null ? void 0 : ht.title;
            }), o(ae, k(T, {
              get when() {
                return He();
              },
              get children() {
                var ht = $o();
                return c(ht, `text-sm ${n ? "text-gray-400" : "text-gray-500"}`), o(ht, () => He().replace("days-", " días - $").replace("min-", " días - $")), ht;
              }
            }), null), ae;
          }
        }), V), c(z, `font-semibold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(je, `font-medium ${n ? "text-gray-200" : "text-gray-700"}`), o(je, () => Er(F())), o(Ce, k(T, {
          get when() {
            return qe(F());
          },
          get children() {
            return wo();
          }
        }), null), c(De, `text-lg font-semibold ${n ? "text-gray-200" : "text-gray-700"}`), o(De, () => jr(be()), null), c(Ee, `font-semibold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(Ae, `space-y-2 ${n ? "text-gray-300" : "text-gray-600"}`), o(Ot, f), o(kt, G), o(ft, ee), o(Lt, Y, mr), o(Lt, () => Y() === 1 ? "viajero" : "viajeros", null), o(Ae, k(T, {
          get when() {
            return q();
          },
          get children() {
            var ae = _o(), Te = ae.firstChild, fe = Te.nextSibling;
            return o(fe, () => q().replace("-", " ")), ae;
          }
        }), null), o(Ae, k(T, {
          get when() {
            return ve();
          },
          get children() {
            var ae = ko(), Te = ae.firstChild, fe = Te.nextSibling;
            return o(fe, ve), ae;
          }
        }), null), o(Ae, k(T, {
          get when() {
            return Le();
          },
          get children() {
            var ae = So(), Te = ae.firstChild, fe = Te.nextSibling;
            return o(fe, Le), ae;
          }
        }), null), o(J, k(T, {
          get when() {
            return Ue();
          },
          get children() {
            var ae = Co(), Te = ae.firstChild, fe = Te.nextSibling;
            return c(Te, `font-semibold mb-2 ${n ? "text-white" : "text-gray-800"}`), c(fe, `${n ? "text-gray-300" : "text-gray-600"}`), o(fe, Ue), ae;
          }
        }), null), nt.$$click = on, nt.style.setProperty("color", "white"), o(nt, (() => {
          var ae = oe(() => !!jt());
          return () => ae() ? [Qo(), Xo()] : [Zo(), ei()];
        })()), D((ae) => {
          var Te = jt(), fe = ze.accent;
          return Te !== ae.e && (nt.disabled = ae.e = Te), fe !== ae.t && ((ae.t = fe) != null ? nt.style.setProperty("background", fe) : nt.style.removeProperty("background")), ae;
        }, {
          e: void 0,
          t: void 0
        }), $;
      }
    }), null), ut.$$click = Zr, c(Kt, `text-sm font-medium ${n ? "text-gray-300" : "text-gray-600"}`), o(Kt, I, Ar), o(sn, () => Array.from({
      length: Qe
    }, ($, Q) => (() => {
      var de = ti();
      return D(() => c(de, `w-2 h-2 rounded-full transition-all duration-200 ${Q + 1 <= I() ? "bg-gray-600" : "bg-gray-300"}`)), de;
    })())), o(ct, k(T, {
      get when() {
        return I() < Qe;
      },
      get children() {
        var $ = Mo();
        return $.$$click = Xr, D((Q) => {
          var de = !Mt(), Se = `flex items-center px-4 py-2 rounded-lg font-medium transition-all duration-200 ${Mt() ? "text-white hover:opacity-90" : "opacity-50 cursor-not-allowed bg-gray-200 text-gray-400"}`, J = Mt() ? {
            background: ze.accent
          } : {};
          return de !== Q.e && ($.disabled = Q.e = de), Se !== Q.t && c($, Q.t = Se), Q.a = tr($, J, Q.a), Q;
        }, {
          e: void 0,
          t: void 0,
          a: void 0
        }), $;
      }
    }), null), o(l, k(T, {
      get when() {
        return Tt().message;
      },
      get children() {
        var $ = jo();
        return o($, () => Tt().message), D(() => c($, `p-4 rounded-lg text-center transition-all duration-300 ${Tt().type === "success" ? "bg-green-500 text-white" : Tt().type === "error" ? "bg-red-500 text-white" : "bg-blue-500 text-white"}`)), $;
      }
    }), hr), dn.value = d, o(hr, k(T, {
      get when() {
        return oe(() => !$t())() && ie();
      },
      get children() {
        return [(() => {
          var $ = Eo();
          return D(() => $.value = ie()), $;
        })(), (() => {
          var $ = To();
          return D(() => {
            var Q;
            return $.value = ((Q = U()) == null ? void 0 : Q.title) || "";
          }), $;
        })()];
      }
    }), null), D(($) => {
      var Q = I(), de = `Step ${I()} of ${Qe}`, Se = ze.accent, J = `${I() / Qe * 100}%`, Ie = I() === 1, V = `flex items-center px-4 py-2 rounded-lg font-medium transition-all duration-200 ${I() === 1 ? "opacity-50 cursor-not-allowed text-gray-400" : "bg-gray-100 hover:bg-gray-200 text-gray-700"}`;
      return Q !== $.e && w(M, "aria-valuenow", $.e = Q), de !== $.t && w(M, "aria-label", $.t = de), Se !== $.a && (($.a = Se) != null ? tt.style.setProperty("backgroundColor", Se) : tt.style.removeProperty("backgroundColor")), J !== $.o && (($.o = J) != null ? tt.style.setProperty("width", J) : tt.style.removeProperty("width")), Ie !== $.i && (ut.disabled = $.i = Ie), V !== $.n && c(ut, $.n = V), $;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0,
      n: void 0
    }), D(() => Br.value = F()), l;
  })()];
};
Cr(["input", "click", "keydown"]);
Jr("booking-form", ri);
function Vr() {
  const t = document.querySelectorAll(".solid-booking-container");
  t.length !== 0 && t.forEach((e) => {
    try {
      let r = [], n = e.dataset.useSingleService === "true";
      try {
        const g = e.dataset.services;
        g && (r = JSON.parse(g).map((u) => {
          let y = [];
          if (Array.isArray(u.durations) && u.durations.length > 0)
            y = u.durations.map((f) => {
              const me = f.minutes || parseInt(f.duration) || 0, G = f.price || "", R = f.duration || `${me}`;
              return {
                minutes: me,
                price: G,
                text: f.text || `${R} días - $${G.replace("$", "")}`,
                duration: R,
                value: f.value || `${R}days-${G}`
                // Asegurar que value existe
              };
            });
          else {
            if (u.duration1 && u.price1) {
              const f = parseInt(u.duration1.replace(/[^0-9]/g, "")) || 0;
              y.push({
                minutes: f * 24 * 60,
                // Convert days to minutes for compatibility
                price: u.price1,
                text: `${u.duration1} días - $${u.price1.replace("$", "")}`,
                duration: u.duration1,
                value: `${f}days-${u.price1}`
              });
            }
            if (u.duration2 && u.price2) {
              const f = parseInt(u.duration2.replace(/[^0-9]/g, "")) || 0;
              y.push({
                minutes: f * 24 * 60,
                // Convert days to minutes for compatibility
                price: u.price2,
                text: `${u.duration2} días - $${u.price2.replace("$", "")}`,
                duration: u.duration2,
                value: `${f}days-${u.price2}`
              });
            }
          }
          let x = [];
          return Array.isArray(u.hours) && (x = u.hours.filter((f) => f && typeof f == "string")), console.log(`Processing service ${u.id}: ${x.length} hours, ${y.length} durations`), console.log(`Service ${u.id} booking_config:`, u.booking_config), {
            id: String(u.id),
            // IMPORTANTE: Convertir a string para consistencia
            title: u.title || "",
            // Título del servicio
            subtitle: u.subtitle || "",
            // Subtítulo del servicio
            hours: x,
            // Horarios disponibles (array filtrado)
            durations: y,
            // Duraciones y precios en nuevo formato
            // NUEVO: Incluir configuración del tour
            booking_config: u.booking_config || null,
            // Configuración del formulario de reservas
            // Mantener compatibilidad
            duration1: u.duration1 || "",
            price1: u.price1 || "",
            duration2: u.duration2 || "",
            price2: u.price2 || ""
          };
        }), console.log("Servicios procesados con múltiples precios:", r), r.forEach((u) => {
          u.hours.length === 0 && console.warn(`Service ${u.title} has no hours configured`), u.durations.length === 0 && console.warn(`Service ${u.title} has no durations configured`);
        }));
      } catch (g) {
        console.error("Error al parsear datos de servicios:", g), console.error("Raw services data:", e.dataset.services);
      }
      if (r.length === 0) {
        console.warn("No valid services found, cannot initialize booking form"), e.innerHTML = `
          <div class="p-4 bg-amber-100 text-amber-800 rounded-md">
            <p>No services available for booking</p>
          </div>
        `;
        return;
      }
      const a = {
        formId: e.id || "booking-form",
        services: r,
        isDarkMode: e.dataset.darkMode === "true",
        accentColor: e.dataset.accentColor || "#D4B254",
        ajaxUrl: e.dataset.ajaxUrl || "",
        nonce: e.dataset.nonce || "",
        useSingleService: n,
        emailRecipient: e.dataset.emailRecipient || ""
      };
      console.log("Final props for Solid component:", a);
      const s = Dr.renderComponent(
        "booking-form",
        e,
        a
      );
      e._solidDispose = s, console.log("Formulario de reserva con Solid.js y múltiples precios cargado correctamente");
    } catch (r) {
      console.error("Error al inicializar formulario con Solid.js:", r), e.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el formulario de reserva: ${r.message}</p>
          <details class="mt-2">
            <summary class="cursor-pointer">Debug Info</summary>
            <pre class="mt-2 text-xs">${r.stack}</pre>
          </details>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", Vr) : Vr();
function ni(t, e = {}) {
  try {
    async function r() {
      var a, s;
      try {
        const d = await (await fetch(((a = window.wptbt_ajax) == null ? void 0 : a.url) || "/wp-admin/admin-ajax.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          body: new URLSearchParams({
            action: "get_tours_for_booking",
            nonce: ((s = window.wptbt_ajax) == null ? void 0 : s.nonce) || ""
          })
        })).json();
        if (d.success && d.data)
          return d.data;
      } catch (g) {
        console.warn("Error fetching tours:", g);
      }
      return [
        {
          id: "general",
          title: "Reserva General",
          subtitle: "Contacta para más información",
          hours: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"],
          durations: [
            {
              minutes: 480,
              price: "Consultar precio",
              text: "Tour personalizado - Consultar precio",
              duration: "1",
              value: "custom-tour"
            }
          ]
        }
      ];
    }
    async function n() {
      var d, u;
      const a = e.services || await r(), s = {
        formId: e.formId || "modal-booking-form",
        services: a,
        isDarkMode: e.isDarkMode || !1,
        accentColor: e.accentColor || "#D4B254",
        ajaxUrl: e.ajaxUrl || ((d = window.wptbt_ajax) == null ? void 0 : d.url) || "",
        nonce: e.nonce || ((u = window.wptbt_ajax) == null ? void 0 : u.nonce) || "",
        useSingleService: e.useSingleService || !1,
        // CORREGIDO: Permitir selección múltiple
        emailRecipient: e.emailRecipient || "",
        modalMode: e.modalMode || !1,
        onComplete: e.onComplete || (() => {
        })
      };
      console.log("Initializing booking form in modal with props:", s);
      const g = Dr.renderComponent(
        "booking-form",
        t,
        s
      );
      return t._solidDispose = g, g;
    }
    return n();
  } catch (r) {
    return console.error("Error initializing booking form:", r), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el formulario de reserva: ${r.message}</p>
      </div>
    `, null;
  }
}
typeof window < "u" && (window.initializeSolidBookingForm = ni);
export {
  Vr as initBookingForms,
  ni as initializeSolidBookingForm
};
