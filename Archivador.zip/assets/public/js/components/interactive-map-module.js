const ht = (e, t) => e === t, pe = {
  equals: ht
};
let Ge = Ze;
const Q = 1, me = 2, Ne = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var z = null;
let xe = null, wt = null, P = null, O = null, J = null, ye = 0;
function yt(e, t) {
  const r = P, i = z, s = e.length === 0, a = t === void 0 ? i : t, l = s ? Ne : {
    owned: null,
    cleanups: null,
    context: a ? a.context : null,
    owner: a
  }, o = s ? e : () => e(() => X(() => se(l)));
  z = l, P = null;
  try {
    return ce(o, !0);
  } finally {
    P = r, z = i;
  }
}
function D(e, t) {
  t = t ? Object.assign({}, pe, t) : pe;
  const r = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, i = (s) => (typeof s == "function" && (s = s(r.value)), He(r, s));
  return [Be.bind(r), i];
}
function V(e, t, r) {
  const i = ke(e, t, !1, Q);
  le(i);
}
function Ve(e, t, r) {
  Ge = Lt;
  const i = ke(e, t, !1, Q);
  i.user = !0, J ? J.push(i) : le(i);
}
function W(e, t, r) {
  r = r ? Object.assign({}, pe, r) : pe;
  const i = ke(e, t, !0, 0);
  return i.observers = null, i.observerSlots = null, i.comparator = r.equals || void 0, le(i), Be.bind(i);
}
function X(e) {
  if (P === null) return e();
  const t = P;
  P = null;
  try {
    return e();
  } finally {
    P = t;
  }
}
function vt(e) {
  Ve(() => X(e));
}
function bt(e) {
  return z === null || (z.cleanups === null ? z.cleanups = [e] : z.cleanups.push(e)), e;
}
function Be() {
  if (this.sources && this.state)
    if (this.state === Q) le(this);
    else {
      const e = O;
      O = null, ce(() => fe(this), !1), O = e;
    }
  if (P) {
    const e = this.observers ? this.observers.length : 0;
    P.sources ? (P.sources.push(this), P.sourceSlots.push(e)) : (P.sources = [this], P.sourceSlots = [e]), this.observers ? (this.observers.push(P), this.observerSlots.push(P.sources.length - 1)) : (this.observers = [P], this.observerSlots = [P.sources.length - 1]);
  }
  return this.value;
}
function He(e, t, r) {
  let i = e.value;
  return (!e.comparator || !e.comparator(i, t)) && (e.value = t, e.observers && e.observers.length && ce(() => {
    for (let s = 0; s < e.observers.length; s += 1) {
      const a = e.observers[s], l = xe && xe.running;
      l && xe.disposed.has(a), (l ? !a.tState : !a.state) && (a.pure ? O.push(a) : J.push(a), a.observers && qe(a)), l || (a.state = Q);
    }
    if (O.length > 1e6)
      throw O = [], new Error();
  }, !1)), t;
}
function le(e) {
  if (!e.fn) return;
  se(e);
  const t = ye;
  xt(
    e,
    e.value,
    t
  );
}
function xt(e, t, r) {
  let i;
  const s = z, a = P;
  P = z = e;
  try {
    i = e.fn(t);
  } catch (l) {
    return e.pure && (e.state = Q, e.owned && e.owned.forEach(se), e.owned = null), e.updatedAt = r + 1, je(l);
  } finally {
    P = a, z = s;
  }
  (!e.updatedAt || e.updatedAt <= r) && (e.updatedAt != null && "observers" in e ? He(e, i) : e.value = i, e.updatedAt = r);
}
function ke(e, t, r, i = Q, s) {
  const a = {
    fn: e,
    state: i,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: z,
    context: z ? z.context : null,
    pure: r
  };
  return z === null || z !== Ne && (z.owned ? z.owned.push(a) : z.owned = [a]), a;
}
function ge(e) {
  if (e.state === 0) return;
  if (e.state === me) return fe(e);
  if (e.suspense && X(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < ye); )
    e.state && t.push(e);
  for (let r = t.length - 1; r >= 0; r--)
    if (e = t[r], e.state === Q)
      le(e);
    else if (e.state === me) {
      const i = O;
      O = null, ce(() => fe(e, t[0]), !1), O = i;
    }
}
function ce(e, t) {
  if (O) return e();
  let r = !1;
  t || (O = []), J ? r = !0 : J = [], ye++;
  try {
    const i = e();
    return Ct(r), i;
  } catch (i) {
    r || (J = null), O = null, je(i);
  }
}
function Ct(e) {
  if (O && (Ze(O), O = null), e) return;
  const t = J;
  J = null, t.length && ce(() => Ge(t), !1);
}
function Ze(e) {
  for (let t = 0; t < e.length; t++) ge(e[t]);
}
function Lt(e) {
  let t, r = 0;
  for (t = 0; t < e.length; t++) {
    const i = e[t];
    i.user ? e[r++] = i : ge(i);
  }
  for (t = 0; t < r; t++) ge(e[t]);
}
function fe(e, t) {
  e.state = 0;
  for (let r = 0; r < e.sources.length; r += 1) {
    const i = e.sources[r];
    if (i.sources) {
      const s = i.state;
      s === Q ? i !== t && (!i.updatedAt || i.updatedAt < ye) && ge(i) : s === me && fe(i, t);
    }
  }
}
function qe(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const r = e.observers[t];
    r.state || (r.state = me, r.pure ? O.push(r) : J.push(r), r.observers && qe(r));
  }
}
function se(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const r = e.sources.pop(), i = e.sourceSlots.pop(), s = r.observers;
      if (s && s.length) {
        const a = s.pop(), l = r.observerSlots.pop();
        i < s.length && (a.sourceSlots[l] = i, s[i] = a, r.observerSlots[i] = l);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) se(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) se(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function kt(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function je(e, t = z) {
  throw kt(e);
}
function q(e, t) {
  return X(() => e(t || {}));
}
const Et = (e) => `Stale read from <${e}>.`;
function j(e) {
  const t = e.keyed, r = W(() => e.when, void 0, void 0), i = t ? r : W(r, void 0, {
    equals: (s, a) => !s == !a
  });
  return W(
    () => {
      const s = i();
      if (s) {
        const a = e.children;
        return typeof a == "function" && a.length > 0 ? X(
          () => a(
            t ? s : () => {
              if (!X(i)) throw Et("Show");
              return r();
            }
          )
        ) : a;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function St(e, t, r) {
  let i = r.length, s = t.length, a = i, l = 0, o = 0, u = t[s - 1].nextSibling, $ = null;
  for (; l < s || o < a; ) {
    if (t[l] === r[o]) {
      l++, o++;
      continue;
    }
    for (; t[s - 1] === r[a - 1]; )
      s--, a--;
    if (s === l) {
      const A = a < i ? o ? r[o - 1].nextSibling : r[a - o] : u;
      for (; o < a; ) e.insertBefore(r[o++], A);
    } else if (a === o)
      for (; l < s; )
        (!$ || !$.has(t[l])) && t[l].remove(), l++;
    else if (t[l] === r[a - 1] && r[o] === t[s - 1]) {
      const A = t[--s].nextSibling;
      e.insertBefore(r[o++], t[l++].nextSibling), e.insertBefore(r[--a], A), t[s] = r[a];
    } else {
      if (!$) {
        $ = /* @__PURE__ */ new Map();
        let G = o;
        for (; G < a; ) $.set(r[G], G++);
      }
      const A = $.get(t[l]);
      if (A != null)
        if (o < A && A < a) {
          let G = l, Y = 1, te;
          for (; ++G < s && G < a && !((te = $.get(t[G])) == null || te !== A + Y); )
            Y++;
          if (Y > A - o) {
            const Ee = t[l];
            for (; o < A; ) e.insertBefore(r[o++], Ee);
          } else e.replaceChild(r[o++], t[l++]);
        } else l++;
      else t[l++].remove();
    }
  }
}
const _e = "_$DX_DELEGATE";
function $t(e, t, r, i = {}) {
  let s;
  return yt((a) => {
    s = a, t === document ? e() : w(t, e(), t.firstChild ? null : void 0, r);
  }, i.owner), () => {
    s(), t.textContent = "";
  };
}
function R(e, t, r, i) {
  let s;
  const a = () => {
    const o = i ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return o.innerHTML = e, r ? o.content.firstChild.firstChild : i ? o.firstChild : o.content.firstChild;
  }, l = t ? () => X(() => document.importNode(s || (s = a()), !0)) : () => (s || (s = a())).cloneNode(!0);
  return l.cloneNode = l, l;
}
function Pt(e, t = window.document) {
  const r = t[_e] || (t[_e] = /* @__PURE__ */ new Set());
  for (let i = 0, s = e.length; i < s; i++) {
    const a = e[i];
    r.has(a) || (r.add(a), t.addEventListener(a, Mt));
  }
}
function T(e, t, r) {
  r == null ? e.removeAttribute(t) : e.setAttribute(t, r);
}
function Fe(e, t, r) {
  return X(() => e(t, r));
}
function w(e, t, r, i) {
  if (r !== void 0 && !i && (i = []), typeof t != "function") return he(e, t, i, r);
  V((s) => he(e, t(), s, r), i);
}
function Mt(e) {
  let t = e.target;
  const r = `$$${e.type}`, i = e.target, s = e.currentTarget, a = (u) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: u
  }), l = () => {
    const u = t[r];
    if (u && !t.disabled) {
      const $ = t[`${r}Data`];
      if ($ !== void 0 ? u.call(t, $, e) : u.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && a(t.host), !0;
  }, o = () => {
    for (; l() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const u = e.composedPath();
    a(u[0]);
    for (let $ = 0; $ < u.length - 2 && (t = u[$], !!l()); $++) {
      if (t._$host) {
        t = t._$host, o();
        break;
      }
      if (t.parentNode === s)
        break;
    }
  } else o();
  a(i);
}
function he(e, t, r, i, s) {
  for (; typeof r == "function"; ) r = r();
  if (t === r) return r;
  const a = typeof t, l = i !== void 0;
  if (e = l && r[0] && r[0].parentNode || e, a === "string" || a === "number") {
    if (a === "number" && (t = t.toString(), t === r))
      return r;
    if (l) {
      let o = r[0];
      o && o.nodeType === 3 ? o.data !== t && (o.data = t) : o = document.createTextNode(t), r = ie(e, r, i, o);
    } else
      r !== "" && typeof r == "string" ? r = e.firstChild.data = t : r = e.textContent = t;
  } else if (t == null || a === "boolean")
    r = ie(e, r, i);
  else {
    if (a === "function")
      return V(() => {
        let o = t();
        for (; typeof o == "function"; ) o = o();
        r = he(e, o, r, i);
      }), () => r;
    if (Array.isArray(t)) {
      const o = [], u = r && Array.isArray(r);
      if (Ce(o, t, r, s))
        return V(() => r = he(e, o, r, i, !0)), () => r;
      if (o.length === 0) {
        if (r = ie(e, r, i), l) return r;
      } else u ? r.length === 0 ? Re(e, o, i) : St(e, r, o) : (r && ie(e), Re(e, o));
      r = o;
    } else if (t.nodeType) {
      if (Array.isArray(r)) {
        if (l) return r = ie(e, r, i, t);
        ie(e, r, null, t);
      } else r == null || r === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      r = t;
    }
  }
  return r;
}
function Ce(e, t, r, i) {
  let s = !1;
  for (let a = 0, l = t.length; a < l; a++) {
    let o = t[a], u = r && r[e.length], $;
    if (!(o == null || o === !0 || o === !1)) if (($ = typeof o) == "object" && o.nodeType)
      e.push(o);
    else if (Array.isArray(o))
      s = Ce(e, o, u) || s;
    else if ($ === "function")
      if (i) {
        for (; typeof o == "function"; ) o = o();
        s = Ce(
          e,
          Array.isArray(o) ? o : [o],
          Array.isArray(u) ? u : [u]
        ) || s;
      } else
        e.push(o), s = !0;
    else {
      const A = String(o);
      u && u.nodeType === 3 && u.data === A ? e.push(u) : e.push(document.createTextNode(A));
    }
  }
  return s;
}
function Re(e, t, r = null) {
  for (let i = 0, s = t.length; i < s; i++) e.insertBefore(t[i], r);
}
function ie(e, t, r, i) {
  if (r === void 0) return e.textContent = "";
  const s = i || document.createTextNode("");
  if (t.length) {
    let a = !1;
    for (let l = t.length - 1; l >= 0; l--) {
      const o = t[l];
      if (s !== o) {
        const u = o.parentNode === e;
        !a && !l ? u ? e.replaceChild(s, o) : e.insertBefore(s, r) : u && o.remove();
      } else a = !0;
    }
  } else e.insertBefore(s, r);
  return [s];
}
const zt = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, ue = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const r = zt();
  return r[e] ? r[e] : e;
}, Ue = {}, It = () => document.readyState !== "loading";
function We(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  Ue[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function Je(e) {
  return Ue[e] || null;
}
function Ke(e, t, r = {}) {
  const i = Je(e);
  if (!i)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const s = $t(() => i(r), t);
    return t.dataset.solidInitialized = "true", s;
  } catch (s) {
    return console.error(`Error al renderizar el componente '${e}':`, s), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${s.message}</p>
      </div>
    `, null;
  }
}
function Le() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const r = t.dataset.solidComponent;
    if (!r || t.dataset.solidInitialized === "true") return;
    let i = {};
    try {
      t.dataset.props && (i = JSON.parse(t.dataset.props));
    } catch (s) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        s
      );
    }
    Ke(r, t, i);
  });
}
It() ? Le() : document.addEventListener("DOMContentLoaded", Le);
const Xe = {
  registerComponent: We,
  getComponent: Je,
  renderComponent: Ke,
  initComponents: Le
};
window.solidCore = Xe;
var Tt = /* @__PURE__ */ R('<div class="absolute inset-0 bg-white bg-opacity-80 flex flex-col justify-center items-center z-30"role=status><div class="relative w-16 h-16"><div class="absolute top-0 left-0 w-full h-full border-4 border-gray-200 rounded-full"></div><div class="absolute top-0 left-0 w-full h-full border-4 rounded-full animate-spin"></div></div><span class="mt-4 text-lg fancy-text italic">'), Ot = /* @__PURE__ */ R('<div class="bg-red-50 border border-red-100 text-red-700 p-6 rounded-lg shadow-sm mb-8 fancy-text italic text-center"role=alert><button class="mt-4 px-4 py-2 bg-white text-red-700 border border-red-300 rounded-md hover:bg-red-50 transition-colors"aria-describedby=error-message>'), At = /* @__PURE__ */ R('<span class="block text-lg italic font-medium mb-2">'), _t = /* @__PURE__ */ R('<div class="relative inline-block"><h2 class="text-3xl md:text-4xl lg:text-5xl fancy-text font-medium mb-4"></h2><div class="absolute -bottom-2 left-1/2 w-24 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), Ft = /* @__PURE__ */ R('<p class="text-xl md:text-2xl fancy-text font-light mt-8 max-w-2xl mx-auto italic opacity-80">'), Rt = /* @__PURE__ */ R('<div class="container mx-auto px-4 relative"><div class="text-center mb-12 relative">'), De = /* @__PURE__ */ R('<button type=button class="bg-white rounded-full p-2 shadow-md hover:shadow-lg transition-all duration-300 flex items-center justify-center"><svg xmlns=http://www.w3.org/2000/svg width=16 height=16 viewBox="0 0 24 24"fill=none stroke-width=2 stroke-linecap=round stroke-linejoin=round aria-hidden=true>'), Dt = /* @__PURE__ */ R('<div class="absolute top-4 right-4 z-10 flex flex-col gap-2"role=toolbar><button type=button class="bg-white rounded-full p-2 shadow-md hover:shadow-lg transition-all duration-300 flex items-center justify-center"><svg xmlns=http://www.w3.org/2000/svg width=16 height=16 viewBox="0 0 24 24"fill=none stroke-width=2 stroke-linecap=round stroke-linejoin=round aria-hidden=true><circle cx=12 cy=12 r=10></circle><line x1=12 y1=8 x2=12 y2=16></line><line x1=8 y1=12 x2=16 y2=12>'), Gt = /* @__PURE__ */ R('<div class="w-full h-full">'), Nt = /* @__PURE__ */ R('<div class="contact-info p-4 bg-white rounded-lg shadow-md max-w-md mx-auto"><div class="font-medium text-lg mb-2"></div><div class="text-sm opacity-80 mb-1"></div><div class="text-sm opacity-80">'), Vt = /* @__PURE__ */ R('<div class="solid-interactive-map-container w-full overflow-hidden"role=region itemscope itemtype=https://schema.org/LocalBusiness><div style=display:none; itemscope itemtype=https://schema.org/LocalBusiness><span itemprop=name></span><span itemprop=description></span><span itemprop=telephone></span><span itemprop=email></span><div itemprop=address itemscope itemtype=https://schema.org/PostalAddress><span itemprop=streetAddress></span><span itemprop=addressLocality></span><span itemprop=addressRegion></span><span itemprop=postalCode></span><span itemprop=addressCountry></span></div><div itemprop=geo itemscope itemtype=https://schema.org/GeoCoordinates><meta itemprop=latitude><meta itemprop=longitude></div></div><div aria-live=polite aria-atomic=true class=sr-only role=status></div><div class="map-wrapper relative mx-auto w-full px-4 relative"><div class="map-container relative rounded-lg overflow-hidden shadow-xl"role=application><div class="w-full h-full"></div></div><div class="map-info absolute bottom-16 left-1/2 -translate-x-1/2 z-10">'), Bt = /* @__PURE__ */ R('<svg><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></svg>', !1, !0, !1), Ht = /* @__PURE__ */ R('<svg><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></svg>', !1, !0, !1), Zt = /* @__PURE__ */ R('<svg><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></svg>', !1, !0, !1), qt = /* @__PURE__ */ R('<svg><path d="M18 10h-4v4h4m-4-8v4m-8 0v6a2 2 0 0 0 2 2h4"></svg>', !1, !0, !1);
const jt = (e) => {
  const [t, r] = D(!1), [i, s] = D(null), [a, l] = D(null), o = W(() => {
    var d, c, g, _, N, B, F, y, E, H, b, Z, re;
    console.log("Props mainLocation:", e.mainLocation);
    let n = parseFloat((d = e.mainLocation) == null ? void 0 : d.lat), p = parseFloat((c = e.mainLocation) == null ? void 0 : c.lng);
    return (isNaN(n) || n < -90 || n > 90) && (console.warn("Latitud inválida:", n, "usando valor por defecto"), n = -13.53168), (isNaN(p) || p < -180 || p > 180) && (console.warn("Longitud inválida:", p, "usando valor por defecto"), p = -71.96741), console.log("Parsed coordinates:", {
      lat: n,
      lng: p
    }), {
      title: e.title || ue("Find Us", "wp-tailwind-blocks"),
      subtitle: e.subtitle || ue("Our Location", "wp-tailwind-blocks"),
      description: e.description || ue("Visit us to experience our services in person", "wp-tailwind-blocks"),
      mainLocation: {
        lat: n,
        lng: p,
        title: ((g = e.mainLocation) == null ? void 0 : g.title) || "Mystical Terra Spa",
        address: ((_ = e.mainLocation) == null ? void 0 : _.address) || "Calle Principal 123, Cusco, Perú",
        description: ((N = e.mainLocation) == null ? void 0 : N.description) || "Our main spa location",
        // Nuevas propiedades SEO (opcionales)
        postalCode: ((B = e.mainLocation) == null ? void 0 : B.postalCode) || "08000",
        city: ((F = e.mainLocation) == null ? void 0 : F.city) || "Cusco",
        region: ((y = e.mainLocation) == null ? void 0 : y.region) || "Cusco",
        country: ((E = e.mainLocation) == null ? void 0 : E.country) || "Peru",
        phone: ((H = e.mainLocation) == null ? void 0 : H.phone) || "+51 84 123456",
        email: ((b = e.mainLocation) == null ? void 0 : b.email) || "info@mysticalterraspa.com",
        website: ((Z = e.mainLocation) == null ? void 0 : Z.website) || "https://mysticalterraspa.com",
        openingHours: ((re = e.mainLocation) == null ? void 0 : re.openingHours) || ["Mo-Su 09:00-20:00"]
      },
      pointsOfInterest: Array.isArray(e.pointsOfInterest) ? e.pointsOfInterest : [],
      zoom: e.zoom || 14,
      mapHeight: e.mapHeight || 500,
      accentColor: e.accentColor || "#D4B254",
      secondaryColor: e.secondaryColor || "#8BAB8D",
      backgroundColor: e.backgroundColor || "#F9F5F2",
      textColor: e.textColor || "#5D534F",
      showDirectionsLink: e.showDirectionsLink !== !1,
      showPointsOfInterest: e.showPointsOfInterest !== !1,
      customMapStyle: e.customMapStyle || "default",
      enableFullscreen: e.enableFullscreen !== !1,
      enableZoomControls: e.enableZoomControls !== !1,
      enableClustering: e.enableClustering !== !1,
      mapProvider: e.mapProvider === "google" ? "google" : "osm",
      apiKey: e.apiKey || "",
      showStreetview: e.showStreetview !== !1 && e.mapProvider === "google",
      address: e.address || "",
      phone: e.phone || "",
      email: e.email || "",
      bookingUrl: e.bookingUrl || "#booking",
      // Nuevas propiedades SEO
      businessType: e.businessType || "Spa",
      priceRange: e.priceRange || "$$",
      businessHours: e.businessHours || [],
      socialProfiles: e.socialProfiles || [],
      reviews: e.reviews || [],
      amenities: e.amenities || [],
      languages: e.languages || ["es", "en"],
      // NUEVO: Contexto del mapa (tour vs default)
      mapContext: e.mapContext || "default"
    };
  }), [u, $] = D(null), [A, G] = D(!0), [Y, te] = D(null), [Ee, Se] = D(null), [oe, $e] = D(null), [Qe, Pe] = D([]), [Ut, ve] = D(!1), [ae, be] = D(!1), [Wt, Ye] = D(null), [K, Me] = D(!1), [et, ze] = D("");
  let v, ee;
  const Ie = (n) => {
    ze(n), setTimeout(() => ze(""), 1e3);
  }, tt = () => {
    var d;
    const n = o().mainLocation, p = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "@id": n.website || `#business-${(d = n.title) == null ? void 0 : d.replace(/\s+/g, "-").toLowerCase()}`,
      name: n.title,
      description: n.description,
      url: n.website,
      telephone: n.phone,
      email: n.email,
      priceRange: o().priceRange,
      address: {
        "@type": "PostalAddress",
        streetAddress: n.address,
        addressLocality: n.city,
        addressRegion: n.region,
        postalCode: n.postalCode,
        addressCountry: n.country
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: n.lat,
        longitude: n.lng
      },
      hasMap: `https://maps.google.com/?q=${n.lat},${n.lng}`,
      sameAs: o().socialProfiles,
      amenityFeature: o().amenities.map((c) => ({
        "@type": "LocationFeatureSpecification",
        name: c
      })),
      knowsLanguage: o().languages
    };
    if (n.openingHours && n.openingHours.length > 0 && (p.openingHours = n.openingHours), o().reviews.length > 0) {
      p.review = o().reviews.map((g) => ({
        "@type": "Review",
        author: {
          "@type": "Person",
          name: g.author
        },
        reviewRating: {
          "@type": "Rating",
          ratingValue: g.rating,
          bestRating: "5"
        },
        reviewBody: g.text
      }));
      const c = o().reviews.reduce((g, _) => g + _.rating, 0) / o().reviews.length;
      p.aggregateRating = {
        "@type": "AggregateRating",
        ratingValue: c.toFixed(1),
        reviewCount: o().reviews.length,
        bestRating: "5"
      };
    }
    return JSON.stringify(p, null, 2);
  }, ot = () => {
    try {
      const n = document.querySelector('script[type="application/ld+json"][data-map-schema]');
      n && n.remove();
      const p = document.createElement("script");
      p.type = "application/ld+json", p.setAttribute("data-map-schema", "true"), p.textContent = tt(), document.head.appendChild(p);
    } catch (n) {
      console.warn("Error inserting schema markup:", n);
    }
  }, rt = () => {
    try {
      const n = o().mainLocation;
      [{
        property: "og:type",
        content: "business.business"
      }, {
        property: "og:title",
        content: `${o().title} - ${n.title}`
      }, {
        property: "og:description",
        content: o().description
      }, {
        property: "og:url",
        content: n.website || window.location.href
      }, {
        property: "business:contact_data:street_address",
        content: n.address
      }, {
        property: "business:contact_data:locality",
        content: n.city
      }, {
        property: "business:contact_data:region",
        content: n.region
      }, {
        property: "business:contact_data:postal_code",
        content: n.postalCode
      }, {
        property: "business:contact_data:country_name",
        content: n.country
      }, {
        property: "place:location:latitude",
        content: n.lat.toString()
      }, {
        property: "place:location:longitude",
        content: n.lng.toString()
      }].forEach((d) => {
        let c = document.querySelector(`meta[property="${d.property}"]`);
        c || (c = document.createElement("meta"), c.setAttribute("property", d.property), document.head.appendChild(c)), c.setAttribute("content", d.content);
      });
    } catch (n) {
      console.warn("Error inserting Open Graph tags:", n);
    }
  }, k = (n, p = "wptbt-interactive-map-block") => {
    const d = window.wptbtI18n_interactive_map || {};
    return d[n] ? d[n] : ue(n, p);
  }, nt = async () => {
    r(!0);
    try {
      return o().mapProvider === "google" ? (await at(), l("google")) : (await it(), l("leaflet")), r(!1), !0;
    } catch (n) {
      return console.error("Error cargando biblioteca de mapas:", n), s(n.message), r(!1), !1;
    }
  }, it = async () => {
    if (window.L && typeof window.L.map == "function" && window.L.tileLayer && window.L.marker)
      return console.log("Leaflet ya está cargado y disponible"), Promise.resolve();
    try {
      if (!document.querySelector('link[href*="leaflet.css"]')) {
        const n = document.createElement("link");
        n.rel = "stylesheet", n.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css", document.head.appendChild(n);
      }
      return new Promise((n, p) => {
        const d = setTimeout(() => {
          p(new Error("Timeout loading Leaflet script after 10 seconds"));
        }, 1e4), c = document.createElement("script");
        c.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js", c.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=", c.crossOrigin = "", c.onload = () => {
          clearTimeout(d);
          let g = 0;
          const _ = 100, N = () => {
            g++, window.L && typeof window.L.map == "function" && window.L.tileLayer && window.L.marker ? (console.log("Leaflet cargado exitosamente con todas sus funciones"), n()) : g >= _ ? p(new Error("Timeout esperando a que Leaflet esté completamente disponible")) : (console.log(`Esperando a que Leaflet esté completamente disponible... intento ${g}`), setTimeout(N, 50));
          };
          N();
        }, c.onerror = () => {
          clearTimeout(d), p(new Error("Failed to load Leaflet script"));
        }, document.head.appendChild(c);
      });
    } catch (n) {
      throw console.error("Error loading Leaflet:", n), new Error(`Error cargando Leaflet: ${n.message}`);
    }
  }, at = () => new Promise((n, p) => {
    if (window.google && window.google.maps) {
      n();
      return;
    }
    const d = setTimeout(() => {
      p(new Error("Timeout loading Google Maps API after 10 seconds"));
    }, 1e4);
    window.gm_authFailure = () => {
      clearTimeout(d), p(new Error("Google Maps API authentication failed. Check your API key."));
    };
    const c = document.createElement("script"), g = o().apiKey || "";
    c.src = `https://maps.googleapis.com/maps/api/js?key=${g}&libraries=places,geometry`, c.async = !0, c.defer = !0, c.onload = () => {
      clearTimeout(d), n();
    }, c.onerror = () => {
      clearTimeout(d), p(new Error("Failed to load Google Maps API"));
    }, document.head.appendChild(c);
  }), st = async () => {
    if (!o().enableClustering || o().mapProvider === "google" || window.L && window.L.markerClusterGroup) return Promise.resolve();
    try {
      if (!document.querySelector('link[href*="MarkerCluster.css"]')) {
        const n = document.createElement("link");
        n.rel = "stylesheet", n.href = "https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css", document.head.appendChild(n);
      }
      if (!document.querySelector('link[href*="MarkerCluster.Default.css"]')) {
        const n = document.createElement("link");
        n.rel = "stylesheet", n.href = "https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css", document.head.appendChild(n);
      }
      return new Promise((n, p) => {
        const d = setTimeout(() => {
          p(new Error("Timeout loading MarkerCluster after 5 seconds"));
        }, 5e3), c = document.createElement("script");
        c.src = "https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js", c.onload = () => {
          clearTimeout(d), n();
        }, c.onerror = () => {
          clearTimeout(d), p(new Error("Failed to load MarkerCluster"));
        }, document.head.appendChild(c);
      });
    } catch (n) {
      return console.error("Error loading MarkerCluster:", n), console.warn("MarkerCluster failed to load, continuing without clustering"), Promise.resolve();
    }
  }, lt = async () => {
    if (!o().enableClustering || o().mapProvider !== "google" || window.MarkerClusterer) return Promise.resolve();
    try {
      return new Promise((n, p) => {
        const d = setTimeout(() => {
          p(new Error("Timeout loading Google MarkerClusterer after 5 seconds"));
        }, 5e3), c = document.createElement("script");
        c.src = "https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js", c.onload = () => {
          clearTimeout(d), n();
        }, c.onerror = () => {
          clearTimeout(d), p(new Error("Failed to load Google MarkerClusterer"));
        }, document.head.appendChild(c);
      });
    } catch (n) {
      return console.error("Error loading Google MarkerClusterer:", n), console.warn("MarkerClusterer failed to load, continuing without clustering"), Promise.resolve();
    }
  }, Te = async () => {
    try {
      if (G(!0), te(null), Ie(k("Loading interactive map...")), console.log("Iniciando carga de mapa con proveedor:", o().mapProvider), !await nt())
        throw new Error("No se pudieron cargar los scripts necesarios");
      if (o().mapProvider === "google") {
        if (o().enableClustering)
          try {
            await lt();
          } catch (p) {
            console.warn("Error al cargar MarkerClusterer:", p);
          }
        await dt();
      } else {
        if (o().enableClustering)
          try {
            await st();
          } catch (p) {
            console.warn("Error al cargar MarkerCluster:", p);
          }
        await ct();
      }
      G(!1), Ie(k("Map loaded successfully")), ot(), rt();
    } catch (n) {
      console.error("Error initializing map:", n), te(k("Failed to load the map. Please try again later.") + ` (${n.message})`), G(!1);
    }
  }, ct = () => new Promise((n, p) => {
    try {
      if (!window.L || typeof window.L.map != "function")
        throw new Error("Leaflet no está cargado correctamente o L.map no está disponible");
      const d = window.L;
      if (!d.map || !d.tileLayer || !d.marker || !d.divIcon)
        throw new Error("Algunas funciones esenciales de Leaflet no están disponibles");
      if (!v)
        throw new Error("El contenedor del mapa no está disponible");
      console.log("Creando mapa Leaflet en:", v), console.log("Coordenadas:", o().mainLocation.lat, o().mainLocation.lng);
      try {
        v ? console.log("container existe:", v) : console.log("no existe container"), console.log("Inicializando mapa Leaflet...", {
          center: [o().mainLocation.lat, o().mainLocation.lng],
          zoom: o().zoom,
          zoomControl: o().enableZoomControls
        });
        const c = d.map(v, {
          center: [o().mainLocation.lat, o().mainLocation.lng],
          zoom: o().zoom,
          zoomControl: o().enableZoomControls,
          maxZoom: 19,
          minZoom: 1
        });
        let g;
        switch (o().customMapStyle) {
          case "light":
            g = d.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
              attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
              maxZoom: 19,
              minZoom: 1
            });
            break;
          case "dark":
            g = d.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
              attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
              maxZoom: 19,
              minZoom: 1
            });
            break;
          case "satellite":
            g = d.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
              attribution: "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
              maxZoom: 18,
              minZoom: 1
            });
            break;
          case "terrain":
            g = d.tileLayer("https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", {
              attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)',
              maxZoom: 17,
              minZoom: 1
            });
            break;
          default:
            g = d.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
              attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
              maxZoom: 19,
              minZoom: 1
            });
        }
        g && c ? (console.log("Agregando tileLayer al mapa..."), setTimeout(() => {
          try {
            g.addTo(c), console.log("TileLayer agregado exitosamente");
          } catch (E) {
            console.error("Error agregando tileLayer:", E);
          }
        }, 50)) : console.error("TileLayer o mapInstance no están disponibles:", {
          tileLayer: g,
          mapInstance: c
        });
        const _ = d.divIcon({
          html: `
                <div class="map-main-marker" style="
                  width: 40px;
                  height: 40px;
                  background-color: ${o().accentColor};
                  border-radius: 50%;
                  border: 3px solid white;
                  box-shadow: 0 3px 10px rgba(0,0,0,0.2);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  color: white;
                  font-size: 18px;
                  position: relative;
                ">
                  <span style="transform: translateY(-2px);">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M12 2C7.6 2 4 5.6 4 10c0 4.4 7 12 8 12s8-7.6 8-12c0-4.4-3.6-8-8-8zm0 10c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
                    </svg>
                  </span>
                </div>
              `,
          className: "",
          iconSize: [40, 40],
          iconAnchor: [20, 40]
        }), N = d.divIcon({
          html: `
                <div class="map-poi-marker" style="
                  width: 30px;
                  height: 30px;
                  background-color: ${o().secondaryColor};
                  border-radius: 50%;
                  border: 2px solid white;
                  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  color: white;
                  font-size: 14px;
                ">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 8v4M12 16h.01"></path>
                  </svg>
                </div>
              `,
          className: "",
          iconSize: [30, 30],
          iconAnchor: [15, 30]
        }), B = d.marker([o().mainLocation.lat, o().mainLocation.lng], {
          icon: _
        }).addTo(c), F = `
              <div class="map-popup" style="min-width: 200px; max-width: 300px;">
                <h3 style="color: ${o().textColor}; font-weight: 600; margin-bottom: 5px; font-size: 16px;">
                  ${o().mainLocation.title || "Mystical Terra Spa"}
                </h3>
                <div style="margin-bottom: 8px; font-size: 13px; color: #666;">
                  ${o().mainLocation.address || ""}
                </div>
                <p style="margin-bottom: 12px; font-size: 14px; color: ${o().textColor};">
                  ${o().mainLocation.description || ""}
                </p>
                ${o().showDirectionsLink ? `<a href="https://www.google.com/maps/dir/?api=1&destination=${o().mainLocation.lat},${o().mainLocation.lng}" 
                   target="_blank" 
                   rel="noopener noreferrer" 
                   style="display: inline-block; padding: 6px 12px; background-color: ${o().accentColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 12px; font-weight: 500;">
                     ${k("Get Directions")}
                   </a>` : ""}
              </div>
            `;
        if (B.bindPopup(F), $e(B), o().showPointsOfInterest && o().pointsOfInterest && o().pointsOfInterest.length > 0) {
          let E;
          if (console.log("Agregando POIs:", o().pointsOfInterest), o().enableClustering && d.markerClusterGroup)
            try {
              E = d.markerClusterGroup({
                disableClusteringAtZoom: 16,
                spiderfyOnMaxZoom: !0,
                showCoverageOnHover: !1,
                zoomToBoundsOnClick: !0,
                maxClusterRadius: 60,
                iconCreateFunction: function(b) {
                  return d.divIcon({
                    html: `<div style="
                          background-color: ${o().secondaryColor};
                          color: white;
                          width: 36px;
                          height: 36px;
                          border-radius: 50%;
                          display: flex;
                          align-items: center;
                          justify-content: center;
                          font-weight: bold;
                          border: 2px solid white;
                          box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                        ">${b.getChildCount()}</div>`,
                    className: "",
                    iconSize: d.point(36, 36)
                  });
                }
              });
            } catch (b) {
              console.warn("Error creando grupo de cluster:", b), E = d.layerGroup();
            }
          else
            E = d.layerGroup();
          const H = o().pointsOfInterest.map((b) => {
            if (!b || typeof b.lat != "number" || typeof b.lng != "number")
              return console.warn("POI inválido:", b), null;
            try {
              const Z = d.marker([b.lat, b.lng], {
                icon: N
              }), re = `
                    <div class="map-popup" style="min-width: 180px; max-width: 250px;">
                      <h3 style="color: ${o().textColor}; font-weight: 600; margin-bottom: 5px; font-size: 14px;">
                        ${b.title || "Point of Interest"}
                      </h3>
                      <div style="margin-bottom: 5px; font-size: 12px; color: #666;">
                        ${b.category || ""}
                      </div>
                      <p style="margin-bottom: 10px; font-size: 13px; color: ${o().textColor};">
                        ${b.description || ""}
                      </p>
                      ${b.website ? `<a href="${b.website}" 
                         target="_blank" 
                         rel="noopener noreferrer" 
                         style="display: inline-block; padding: 4px 8px; background-color: ${o().secondaryColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 11px;">
                           ${k("Visit Website")}
                         </a>` : ""}
                      ${o().showDirectionsLink ? `<a href="https://www.google.com/maps/dir/?api=1&destination=${b.lat},${b.lng}" 
                         target="_blank" 
                         rel="noopener noreferrer" 
                         style="display: inline-block; padding: 4px 8px; background-color: ${o().accentColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 11px; margin-left: ${b.website ? "5px" : "0"};  margin-top: ${b.website ? "5px" : "0"};">
                           ${k("Directions")}
                         </a>` : ""}
                    </div>
                  `;
              return Z.bindPopup(re), Z.on("click", () => {
                Se(b);
              }), Z;
            } catch (Z) {
              return console.warn("Error creando marcador:", Z), null;
            }
          }).filter(Boolean);
          H.forEach((b) => {
            b && E.addLayer(b);
          }), E.addTo(c), Pe(H);
        }
        $(c);
        const y = () => {
          c && (c.invalidateSize(), ve(window.innerWidth < 768));
        };
        window.addEventListener("resize", y), v._resizeHandler = y, setTimeout(() => {
          c.invalidateSize();
        }, 100), n();
      } catch (c) {
        console.error("Error al inicializar el mapa Leaflet:", c), p(new Error(`Error al inicializar el mapa Leaflet: ${c.message}`));
      }
    } catch (d) {
      console.error("Error general en initializeLeafletMap:", d), p(d);
    }
  }), dt = () => new Promise((n, p) => {
    try {
      if (!window.google || !window.google.maps)
        throw new Error("Google Maps API no está cargada correctamente");
      if (!v)
        throw new Error("El contenedor del mapa no está disponible");
      console.log("Creando mapa Google Maps en:", v), console.log("Coordenadas:", o().mainLocation.lat, o().mainLocation.lng);
      const d = ut();
      let c = window.google.maps.MapTypeId.ROADMAP;
      o().customMapStyle === "satellite" ? c = window.google.maps.MapTypeId.SATELLITE : o().customMapStyle === "terrain" && (c = window.google.maps.MapTypeId.TERRAIN);
      try {
        const g = new window.google.maps.Map(v, {
          center: {
            lat: o().mainLocation.lat,
            lng: o().mainLocation.lng
          },
          zoom: o().zoom,
          styles: d,
          mapTypeId: c,
          mapTypeControl: !0,
          mapTypeControlOptions: {
            style: window.google.maps.MapTypeControlStyle.DROPDOWN_MENU
          },
          streetViewControl: !1,
          fullscreenControl: !1,
          zoomControl: o().enableZoomControls,
          zoomControlOptions: {
            position: window.google.maps.ControlPosition.RIGHT_BOTTOM
          }
        });
        if (ee && o().showStreetview)
          try {
            const F = new window.google.maps.StreetViewPanorama(ee, {
              position: {
                lat: o().mainLocation.lat,
                lng: o().mainLocation.lng
              },
              pov: {
                heading: 165,
                pitch: 0
              },
              zoom: 1
            });
            Ye(F);
          } catch (F) {
            console.warn("Error al inicializar Street View:", F);
          }
        const _ = new window.google.maps.Marker({
          position: {
            lat: o().mainLocation.lat,
            lng: o().mainLocation.lng
          },
          map: g,
          title: o().mainLocation.title || "Mystical Terra Spa",
          animation: window.google.maps.Animation.DROP,
          icon: {
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 15,
            fillColor: o().accentColor,
            fillOpacity: 0.8,
            strokeColor: "white",
            strokeWeight: 2,
            anchor: new window.google.maps.Point(0, 0)
          }
        }), N = new window.google.maps.InfoWindow({
          content: `
                <div class="map-popup" style="min-width: 200px; max-width: 300px;">
                  <h3 style="color: ${o().textColor}; font-weight: 600; margin-bottom: 5px; font-size: 16px;">
                    ${o().mainLocation.title || "Mystical Terra Spa"}
                  </h3>
                  <div style="margin-bottom: 8px; font-size: 13px; color: #666;">
                    ${o().mainLocation.address || ""}
                  </div>
                  <p style="margin-bottom: 12px; font-size: 14px; color: ${o().textColor};">
                    ${o().mainLocation.description || ""}
                  </p>
                  ${o().showDirectionsLink ? `<a href="https://www.google.com/maps/dir/?api=1&destination=${o().mainLocation.lat},${o().mainLocation.lng}" 
                     target="_blank" 
                     rel="noopener noreferrer" 
                     style="display: inline-block; padding: 6px 12px; background-color: ${o().accentColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 12px; font-weight: 500;">
                       ${k("Get Directions")}
                     </a>` : ""}
                </div>
              `
        });
        if (_.addListener("click", () => {
          N.open(g, _);
        }), $e(_), o().showPointsOfInterest && o().pointsOfInterest && o().pointsOfInterest.length > 0) {
          console.log("Agregando POIs para Google Maps:", o().pointsOfInterest);
          const F = o().pointsOfInterest.filter((y) => y && typeof y.lat == "number" && typeof y.lng == "number").map((y) => {
            try {
              const E = new window.google.maps.Marker({
                position: {
                  lat: y.lat,
                  lng: y.lng
                },
                map: g,
                title: y.title || "Point of Interest",
                animation: window.google.maps.Animation.DROP,
                icon: {
                  path: window.google.maps.SymbolPath.CIRCLE,
                  scale: 10,
                  fillColor: o().secondaryColor,
                  fillOpacity: 0.7,
                  strokeColor: "white",
                  strokeWeight: 1.5
                }
              }), H = new window.google.maps.InfoWindow({
                content: `
                        <div class="map-popup" style="min-width: 180px; max-width: 250px;">
                          <h3 style="color: ${o().textColor}; font-weight: 600; margin-bottom: 5px; font-size: 14px;">
                            ${y.title || "Point of Interest"}
                          </h3>
                          <div style="margin-bottom: 5px; font-size: 12px; color: #666;">
                            ${y.category || ""}
                          </div>
                          <p style="margin-bottom: 10px; font-size: 13px; color: ${o().textColor};">
                            ${y.description || ""}
                          </p>
                          ${y.website ? `<a href="${y.website}" 
                             target="_blank" 
                             rel="noopener noreferrer" 
                             style="display: inline-block; padding: 4px 8px; background-color: ${o().secondaryColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 11px;">
                               ${k("Visit Website")}
                             </a>` : ""}
                          ${o().showDirectionsLink ? `<a href="https://www.google.com/maps/dir/?api=1&destination=${y.lat},${y.lng}" 
                             target="_blank" 
                             rel="noopener noreferrer" 
                             style="display: inline-block; padding: 4px 8px; background-color: ${o().accentColor}; color: white; text-decoration: none; border-radius: 4px; font-size: 11px; margin-left: ${y.website ? "5px" : "0"}; margin-top: ${y.website ? "5px" : "0"};">
                               ${k("Directions")}
                             </a>` : ""}
                        </div>
                      `
              });
              return E.addListener("click", () => {
                H.open(g, E), Se(y);
              }), E;
            } catch (E) {
              return console.warn("Error al crear marcador POI:", E), null;
            }
          }).filter(Boolean);
          if (Pe(F), o().enableClustering && window.MarkerClusterer && F.length > 0)
            try {
              new window.MarkerClusterer({
                map: g,
                markers: F,
                renderer: {
                  render: ({
                    count: y,
                    position: E
                  }) => new window.google.maps.Marker({
                    position: E,
                    label: {
                      text: String(y),
                      color: "white",
                      fontSize: "12px",
                      fontWeight: "bold"
                    },
                    icon: {
                      path: window.google.maps.SymbolPath.CIRCLE,
                      scale: 18,
                      fillColor: o().secondaryColor,
                      fillOpacity: 0.8,
                      strokeColor: "white",
                      strokeWeight: 2
                    },
                    zIndex: Number(window.google.maps.Marker.MAX_ZINDEX) + y
                  })
                },
                onClusterClick: (y, E, H) => {
                  H.fitBounds(E.bounds);
                }
              });
            } catch (y) {
              console.warn("Error al crear clustering:", y);
            }
        }
        $(g);
        const B = () => {
          g && (window.google.maps.event.trigger(g, "resize"), ve(window.innerWidth < 768));
        };
        window.addEventListener("resize", B), v._resizeHandler = B, setTimeout(() => {
          window.google.maps.event.trigger(g, "resize");
        }, 100), n();
      } catch (g) {
        console.error("Error al inicializar el mapa Google Maps:", g), p(new Error(`Error al inicializar Google Maps: ${g.message}`));
      }
    } catch (d) {
      console.error("Error general en initializeGoogleMap:", d), p(d);
    }
  }), ut = () => {
    switch (o().customMapStyle) {
      case "light":
        return [{
          elementType: "geometry",
          stylers: [{
            color: "#f5f5f5"
          }]
        }, {
          elementType: "labels.icon",
          stylers: [{
            visibility: "off"
          }]
        }];
      case "dark":
        return [{
          elementType: "geometry",
          stylers: [{
            color: "#212121"
          }]
        }, {
          elementType: "labels.icon",
          stylers: [{
            visibility: "off"
          }]
        }];
      default:
        return [];
    }
  }, pt = () => {
    if (u())
      try {
        const n = v;
        ae() ? (document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen ? document.webkitExitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : console.warn("Fullscreen API no soportada en este navegador"), be(!1)) : (n.requestFullscreen ? n.requestFullscreen() : n.mozRequestFullScreen ? n.mozRequestFullScreen() : n.webkitRequestFullscreen ? n.webkitRequestFullscreen() : n.msRequestFullscreen ? n.msRequestFullscreen() : console.warn("Fullscreen API no soportada en este navegador"), be(!0)), setTimeout(() => {
          o().mapProvider === "google" && u() ? window.google.maps.event.trigger(u(), "resize") : u() && u().invalidateSize();
        }, 200);
      } catch (n) {
        console.warn("Error al alternar pantalla completa:", n);
      }
  }, mt = () => {
    if (!(o().mapProvider !== "google" || !u()))
      try {
        Me(!K()), v && ee && (K() ? (v.style.display = "none", ee.style.display = "block") : (v.style.display = "block", ee.style.display = "none"));
      } catch (n) {
        console.warn("Error al alternar Street View:", n), Me(!1);
      }
  }, gt = () => {
    te(null), G(!0), Te();
  };
  return vt(() => {
    const n = () => {
      be(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement), o().mapProvider === "google" && u() ? window.google.maps.event.trigger(u(), "resize") : u() && u().invalidateSize();
    };
    document.addEventListener("fullscreenchange", n), document.addEventListener("mozfullscreenchange", n), document.addEventListener("webkitfullscreenchange", n), document.addEventListener("msfullscreenchange", n);
    const p = new ResizeObserver((c) => {
      for (let g of c)
        g.target === v && u() && (console.log("Contenedor del mapa redimensionado, actualizando mapa"), setTimeout(() => {
          o().mapProvider === "google" && u() ? window.google.maps.event.trigger(u(), "resize") : u() && u().invalidateSize(!0);
        }, 100));
    }), d = new IntersectionObserver((c) => {
      c.forEach((g) => {
        g.isIntersecting && g.target === v && u() && (console.log("Contenedor del mapa se volvió visible, actualizando mapa"), setTimeout(() => {
          o().mapProvider === "google" && u() ? window.google.maps.event.trigger(u(), "resize") : u() && u().invalidateSize(!0);
        }, 200));
      });
    }, {
      threshold: 0.1
    });
    ve(window.innerWidth < 768), console.log("Componente montado, inicializando mapa"), setTimeout(() => {
      Te(), v && (p.observe(v), d.observe(v));
    }, 100), bt(() => {
      console.log("Limpiando recursos del componente de mapa"), document.removeEventListener("fullscreenchange", n), document.removeEventListener("mozfullscreenchange", n), document.removeEventListener("webkitfullscreenchange", n), document.removeEventListener("msfullscreenchange", n), p && v && (p.unobserve(v), p.disconnect()), d && v && (d.unobserve(v), d.disconnect()), v && v._resizeHandler && window.removeEventListener("resize", v._resizeHandler);
      const c = document.querySelector("script[data-map-schema]");
      c && c.remove(), u() && (o().mapProvider === "google" ? (oe() && oe().setMap(null), Qe().forEach((g) => {
        g && g.setMap(null);
      })) : u().remove());
    });
  }), Ve(() => {
    const n = u();
    if (n)
      try {
        o().mapProvider === "google" ? (oe() && oe().setPosition({
          lat: o().mainLocation.lat,
          lng: o().mainLocation.lng
        }), n.setCenter({
          lat: o().mainLocation.lat,
          lng: o().mainLocation.lng
        }), n.setZoom(o().zoom)) : (oe() && oe().setLatLng([o().mainLocation.lat, o().mainLocation.lng]), n.setView([o().mainLocation.lat, o().mainLocation.lng], o().zoom));
      } catch (p) {
        console.warn("Error al actualizar coordenadas del mapa:", p);
      }
  }), (() => {
    var n = Vt(), p = n.firstChild, d = p.firstChild, c = d.nextSibling, g = c.nextSibling, _ = g.nextSibling, N = _.nextSibling, B = N.firstChild, F = B.nextSibling, y = F.nextSibling, E = y.nextSibling, H = E.nextSibling, b = N.nextSibling, Z = b.firstChild, re = Z.nextSibling, Oe = p.nextSibling, de = Oe.nextSibling, U = de.firstChild, ne = U.firstChild, ft = U.nextSibling;
    n.style.setProperty("position", "relative"), w(d, () => o().mainLocation.title), w(c, () => o().mainLocation.description), w(g, () => o().mainLocation.phone), w(_, () => o().mainLocation.email), w(B, () => o().mainLocation.address), w(F, () => o().mainLocation.city), w(y, () => o().mainLocation.region), w(E, () => o().mainLocation.postalCode), w(H, () => o().mainLocation.country), w(Oe, et), w(n, q(j, {
      get when() {
        return A();
      },
      get children() {
        var m = Tt(), x = m.firstChild, C = x.firstChild, f = C.nextSibling, L = x.nextSibling;
        return f.style.setProperty("animation-duration", "1.5s"), w(L, (() => {
          var h = W(() => !!t());
          return () => h() ? k("Loading map dependencies...") : k("Initializing map...");
        })()), V((h) => {
          var S = k("Loading map"), M = `${o().accentColor} transparent transparent transparent`, I = o().textColor;
          return S !== h.e && T(m, "aria-label", h.e = S), M !== h.t && ((h.t = M) != null ? f.style.setProperty("border-color", M) : f.style.removeProperty("border-color")), I !== h.a && ((h.a = I) != null ? L.style.setProperty("color", I) : L.style.removeProperty("color")), h;
        }, {
          e: void 0,
          t: void 0,
          a: void 0
        }), m;
      }
    }), de), w(n, q(j, {
      get when() {
        return Y();
      },
      get children() {
        var m = Ot(), x = m.firstChild;
        return w(m, Y, x), x.$$click = gt, w(x, () => k("Retry")), m;
      }
    }), de), w(n, q(j, {
      get when() {
        return o().mapContext !== "tour";
      },
      get children() {
        var m = Rt(), x = m.firstChild;
        return w(x, q(j, {
          get when() {
            return o().subtitle;
          },
          get children() {
            var C = At();
            return w(C, () => o().subtitle), V((f) => (f = o().accentColor) != null ? C.style.setProperty("color", f) : C.style.removeProperty("color")), C;
          }
        }), null), w(x, q(j, {
          get when() {
            return o().title;
          },
          get children() {
            var C = _t(), f = C.firstChild, L = f.nextSibling, h = L.firstChild;
            return w(f, () => o().title), V((S) => {
              var M = o().accentColor, I = o().accentColor;
              return M !== S.e && ((S.e = M) != null ? L.style.setProperty("background-color", M) : L.style.removeProperty("background-color")), I !== S.t && ((S.t = I) != null ? h.style.setProperty("background-color", I) : h.style.removeProperty("background-color")), S;
            }, {
              e: void 0,
              t: void 0
            }), C;
          }
        }), null), w(x, q(j, {
          get when() {
            return o().description;
          },
          get children() {
            var C = Ft();
            return w(C, () => o().description), C;
          }
        }), null), m;
      }
    }), de), U.style.setProperty("border-radius", "8px"), U.style.setProperty("box-shadow", "0 10px 25px rgba(0, 0, 0, 0.1)"), U.style.setProperty("border", "1px solid rgba(0, 0, 0, 0.1)"), w(U, q(j, {
      get when() {
        return W(() => !!u())() && !Y();
      },
      get children() {
        var m = Dt(), x = m.firstChild, C = x.firstChild;
        return m.style.setProperty("pointer-events", "auto"), w(m, q(j, {
          get when() {
            return o().enableFullscreen;
          },
          get children() {
            var f = De(), L = f.firstChild;
            return f.$$click = pt, w(L, (() => {
              var h = W(() => !!ae());
              return () => h() ? Bt() : Ht();
            })()), V((h) => {
              var S = k(ae() ? "Exit Fullscreen" : "Fullscreen"), M = k(ae() ? "Exit Fullscreen" : "Fullscreen"), I = ae() ? "#E53E3E" : o().accentColor;
              return S !== h.e && T(f, "title", h.e = S), M !== h.t && T(f, "aria-label", h.t = M), I !== h.a && T(L, "stroke", h.a = I), h;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), f;
          }
        }), x), w(m, q(j, {
          get when() {
            return W(() => o().mapProvider === "google")() && o().showStreetview;
          },
          get children() {
            var f = De(), L = f.firstChild;
            return f.$$click = mt, w(L, (() => {
              var h = W(() => !!K());
              return () => h() ? Zt() : qt();
            })()), V((h) => {
              var S = k(K() ? "Switch to Map View" : "Switch to Street View"), M = k(K() ? "Switch to Map View" : "Switch to Street View"), I = K() ? o().secondaryColor : o().accentColor;
              return S !== h.e && T(f, "title", h.e = S), M !== h.t && T(f, "aria-label", h.t = M), I !== h.a && T(L, "stroke", h.a = I), h;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), f;
          }
        }), x), x.$$click = () => {
          u() && (o().mapProvider === "google" ? (u().setCenter({
            lat: o().mainLocation.lat,
            lng: o().mainLocation.lng
          }), u().setZoom(o().zoom)) : u().setView([o().mainLocation.lat, o().mainLocation.lng], o().zoom));
        }, V((f) => {
          var L = k("Map controls"), h = k("Reset Map View"), S = k("Reset Map View"), M = o().accentColor;
          return L !== f.e && T(m, "aria-label", f.e = L), h !== f.t && T(x, "title", f.t = h), S !== f.a && T(x, "aria-label", f.a = S), M !== f.o && T(C, "stroke", f.o = M), f;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0
        }), m;
      }
    }), ne);
    var Ae = v;
    return typeof Ae == "function" ? Fe(Ae, ne) : v = ne, ne.style.setProperty("z-index", "1"), w(U, q(j, {
      get when() {
        return W(() => o().mapProvider === "google")() && o().showStreetview;
      },
      get children() {
        var m = Gt(), x = ee;
        return typeof x == "function" ? Fe(x, m) : ee = m, m.style.setProperty("z-index", "1"), V((C) => {
          var f = K() ? "block" : "none", L = k("Street view of location");
          return f !== C.e && ((C.e = f) != null ? m.style.setProperty("display", f) : m.style.removeProperty("display")), L !== C.t && T(m, "aria-label", C.t = L), C;
        }, {
          e: void 0,
          t: void 0
        }), m;
      }
    }), null), w(ft, q(j, {
      get when() {
        return o().mainLocation.contactInfo;
      },
      get children() {
        var m = Nt(), x = m.firstChild, C = x.nextSibling, f = C.nextSibling;
        return m.style.setProperty("margin-top", "-40px"), m.style.setProperty("position", "relative"), m.style.setProperty("z-index", "2"), w(x, () => o().mainLocation.title), w(C, () => o().mainLocation.address), w(f, () => o().mainLocation.contactInfo), V((L) => (L = `3px solid ${o().accentColor}`) != null ? m.style.setProperty("border-left", L) : m.style.removeProperty("border-left")), m;
      }
    })), V((m) => {
      var x = o().backgroundColor, C = o().textColor, f = k("Interactive map showing our location"), L = o().mainLocation.lat.toString(), h = o().mainLocation.lng.toString(), S = `${o().mapHeight}px`, M = k("Interactive map"), I = o().mapProvider === "google" && K() ? "none" : "block";
      return x !== m.e && ((m.e = x) != null ? n.style.setProperty("background-color", x) : n.style.removeProperty("background-color")), C !== m.t && ((m.t = C) != null ? n.style.setProperty("color", C) : n.style.removeProperty("color")), f !== m.a && T(n, "aria-label", m.a = f), L !== m.o && T(Z, "content", m.o = L), h !== m.i && T(re, "content", m.i = h), S !== m.n && ((m.n = S) != null ? U.style.setProperty("height", S) : U.style.removeProperty("height")), M !== m.s && T(U, "aria-label", m.s = M), I !== m.h && ((m.h = I) != null ? ne.style.setProperty("display", I) : ne.style.removeProperty("display")), m;
    }, {
      e: void 0,
      t: void 0,
      a: void 0,
      o: void 0,
      i: void 0,
      n: void 0,
      s: void 0,
      h: void 0
    }), n;
  })();
};
Pt(["click"]);
We("interactive-map", jt);
function we() {
  const e = document.querySelectorAll(
    ".solid-interactive-map-container"
  );
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      t.dataset.solidInitializing = "true";
      let r = [], i = {
        lat: parseFloat(t.dataset.latitude) || -13.53168,
        lng: parseFloat(t.dataset.longitude) || -71.96741,
        title: t.dataset.markerTitle || "Mystical Terra Spa",
        address: t.dataset.address || "Calle Principal 123, Cusco, Perú",
        description: t.dataset.markerDescription || "Our main spa location",
        contactInfo: t.dataset.phone ? `${t.dataset.phone}${t.dataset.email ? " | " + t.dataset.email : ""}` : ""
      };
      try {
        if (t.dataset.pointsOfInterest && t.dataset.pointsOfInterest !== "[]") {
          const a = JSON.parse(t.dataset.pointsOfInterest);
          Array.isArray(a) && (r = a.filter((l) => l && typeof l == "object" && (typeof l.lat == "number" || typeof l.latitude == "number") && (typeof l.lng == "number" || typeof l.longitude == "number")).map((l) => ({
            lat: l.lat || l.latitude,
            lng: l.lng || l.longitude,
            title: l.title || "",
            description: l.description || "",
            image: l.image || "",
            category: l.category || "",
            website: l.website || ""
          }))), console.log("POIs procesados correctamente:", r);
        } else
          console.log("No se encontraron puntos de interés o formato incorrecto");
        if (t.dataset.mainLocation)
          try {
            const a = JSON.parse(t.dataset.mainLocation);
            a && typeof a == "object" && (i = {
              lat: a.lat || a.latitude || i.lat,
              lng: a.lng || a.longitude || i.lng,
              title: a.title || i.title,
              address: a.address || i.address,
              description: a.description || i.description,
              contactInfo: a.contactInfo || i.contactInfo
            });
          } catch (a) {
            console.warn("Error al parsear mainLocation, usando valores fallback", a);
          }
      } catch (a) {
        console.warn("Error al parsear datos JSON:", a);
      }
      const s = {
        title: t.dataset.title || "Find Us",
        subtitle: t.dataset.subtitle || "Our Location",
        description: t.dataset.description || "",
        mainLocation: i,
        pointsOfInterest: r,
        zoom: parseInt(t.dataset.zoom) || 14,
        mapHeight: parseInt(t.dataset.mapHeight) || 500,
        accentColor: t.dataset.accentColor || "#D4B254",
        secondaryColor: t.dataset.secondaryColor || "#8BAB8D",
        backgroundColor: t.dataset.backgroundColor || "#F9F5F2",
        textColor: t.dataset.textColor || "#5D534F",
        showDirectionsLink: t.dataset.showDirections !== "false",
        showPointsOfInterest: t.dataset.showPointsOfInterest !== "false",
        customMapStyle: t.dataset.customMapStyle || t.dataset.mapStyle || "default",
        enableFullscreen: t.dataset.enableFullscreen !== "false",
        enableZoomControls: t.dataset.enableZoomControls !== "false",
        enableClustering: t.dataset.enableClustering !== "false",
        mapProvider: t.dataset.mapProvider || "osm",
        apiKey: t.dataset.apiKey || "",
        showStreetview: t.dataset.showStreetview !== "false",
        address: t.dataset.address || "",
        phone: t.dataset.phone || "",
        email: t.dataset.email || "",
        bookingUrl: t.dataset.bookingUrl || "#booking",
        mapContext: t.dataset.mapContext || "default"
      };
      console.log("Inicializando mapa con propiedades:", s);
      try {
        const a = Xe.renderComponent(
          "interactive-map",
          t,
          s
        );
        t._solidDispose = a, t.dataset.solidInitialized = "true", t.dataset.solidInitializing = "false", console.log(
          "Componente de mapa interactivo con Solid.js cargado correctamente"
        );
      } catch (a) {
        console.error(
          "Error al renderizar componente de mapa interactivo:",
          a
        ), t.dataset.solidInitializing = "false", t.innerHTML = `
          <div class="p-4 bg-red-100 text-red-800 rounded-md">
            <p>Error al renderizar el componente de mapa: ${a.message}</p>
            <pre class="mt-2 text-xs overflow-auto max-h-40">${a.stack}</pre>
          </div>
        `;
      }
    } catch (r) {
      console.error(
        "Error al inicializar componente de mapa interactivo con Solid.js:",
        r
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de mapa interactivo: ${r.message}</p>
          <button class="mt-2 px-3 py-1 bg-white text-red-800 rounded border border-red-300 text-sm" 
                  onclick="initInteractiveMap()">
            Reintentar
          </button>
        </div>
      `, t.dataset.solidInitializing = "false";
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", we) : we();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((r) => {
        if (r.isIntersecting) {
          const i = r.target;
          i.classList.contains("solid-interactive-map-container") && i.dataset.intersectOnce === "true" && i.dataset.solidInitialized !== "true" && i.dataset.solidInitializing !== "true" && (console.log("Mapa visible en viewport, inicializando..."), setTimeout(we, 100), i.dataset.intersectOnce = "false"), e.unobserve(r.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: "100px" }
    // Detectar antes de que esté completamente visible
  );
  document.querySelectorAll(".solid-interactive-map-container[data-intersect-once='true']").forEach((t) => {
    e.observe(t);
  });
}
window.initInteractiveMap = we;
export {
  we as initInteractiveMap
};
