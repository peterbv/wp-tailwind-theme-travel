const Ht = (e, t) => e === t, qt = Symbol("solid-track"), Se = {
  equals: Ht
};
let ut = ht;
const ee = 1, Ce = 2, ft = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var $ = null;
let Oe = null, Vt = null, x = null, C = null, X = null, Te = 0;
function Pe(e, t) {
  const r = x, l = $, s = e.length === 0, o = t === void 0 ? l : t, i = s ? ft : {
    owned: null,
    cleanups: null,
    context: o ? o.context : null,
    owner: o
  }, n = s ? e : () => e(() => ie(() => ge(i)));
  $ = i, x = null;
  try {
    return we(n, !0);
  } finally {
    x = r, $ = l;
  }
}
function N(e, t) {
  t = t ? Object.assign({}, Se, t) : Se;
  const r = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, l = (s) => (typeof s == "function" && (s = s(r.value)), yt(r, s));
  return [pt.bind(r), l];
}
function K(e, t, r) {
  const l = Ge(e, t, !1, ee);
  ve(l);
}
function Be(e, t, r) {
  ut = Wt;
  const l = Ge(e, t, !1, ee);
  l.user = !0, X ? X.push(l) : ve(l);
}
function ne(e, t, r) {
  r = r ? Object.assign({}, Se, r) : Se;
  const l = Ge(e, t, !0, 0);
  return l.observers = null, l.observerSlots = null, l.comparator = r.equals || void 0, ve(l), pt.bind(l);
}
function ie(e) {
  if (x === null) return e();
  const t = x;
  x = null;
  try {
    return e();
  } finally {
    x = t;
  }
}
function Yt(e) {
  Be(() => ie(e));
}
function Kt(e) {
  return $ === null || ($.cleanups === null ? $.cleanups = [e] : $.cleanups.push(e)), e;
}
function pt() {
  if (this.sources && this.state)
    if (this.state === ee) ve(this);
    else {
      const e = C;
      C = null, we(() => Ee(this), !1), C = e;
    }
  if (x) {
    const e = this.observers ? this.observers.length : 0;
    x.sources ? (x.sources.push(this), x.sourceSlots.push(e)) : (x.sources = [this], x.sourceSlots = [e]), this.observers ? (this.observers.push(x), this.observerSlots.push(x.sources.length - 1)) : (this.observers = [x], this.observerSlots = [x.sources.length - 1]);
  }
  return this.value;
}
function yt(e, t, r) {
  let l = e.value;
  return (!e.comparator || !e.comparator(l, t)) && (e.value = t, e.observers && e.observers.length && we(() => {
    for (let s = 0; s < e.observers.length; s += 1) {
      const o = e.observers[s], i = Oe && Oe.running;
      i && Oe.disposed.has(o), (i ? !o.tState : !o.state) && (o.pure ? C.push(o) : X.push(o), o.observers && gt(o)), i || (o.state = ee);
    }
    if (C.length > 1e6)
      throw C = [], new Error();
  }, !1)), t;
}
function ve(e) {
  if (!e.fn) return;
  ge(e);
  const t = Te;
  Xt(
    e,
    e.value,
    t
  );
}
function Xt(e, t, r) {
  let l;
  const s = $, o = x;
  x = $ = e;
  try {
    l = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = ee, e.owned && e.owned.forEach(ge), e.owned = null), e.updatedAt = r + 1, vt(i);
  } finally {
    x = o, $ = s;
  }
  (!e.updatedAt || e.updatedAt <= r) && (e.updatedAt != null && "observers" in e ? yt(e, l) : e.value = l, e.updatedAt = r);
}
function Ge(e, t, r, l = ee, s) {
  const o = {
    fn: e,
    state: l,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: $,
    context: $ ? $.context : null,
    pure: r
  };
  return $ === null || $ !== ft && ($.owned ? $.owned.push(o) : $.owned = [o]), o;
}
function ke(e) {
  if (e.state === 0) return;
  if (e.state === Ce) return Ee(e);
  if (e.suspense && ie(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < Te); )
    e.state && t.push(e);
  for (let r = t.length - 1; r >= 0; r--)
    if (e = t[r], e.state === ee)
      ve(e);
    else if (e.state === Ce) {
      const l = C;
      C = null, we(() => Ee(e, t[0]), !1), C = l;
    }
}
function we(e, t) {
  if (C) return e();
  let r = !1;
  t || (C = []), X ? r = !0 : X = [], Te++;
  try {
    const l = e();
    return Qt(r), l;
  } catch (l) {
    r || (X = null), C = null, vt(l);
  }
}
function Qt(e) {
  if (C && (ht(C), C = null), e) return;
  const t = X;
  X = null, t.length && we(() => ut(t), !1);
}
function ht(e) {
  for (let t = 0; t < e.length; t++) ke(e[t]);
}
function Wt(e) {
  let t, r = 0;
  for (t = 0; t < e.length; t++) {
    const l = e[t];
    l.user ? e[r++] = l : ke(l);
  }
  for (t = 0; t < r; t++) ke(e[t]);
}
function Ee(e, t) {
  e.state = 0;
  for (let r = 0; r < e.sources.length; r += 1) {
    const l = e.sources[r];
    if (l.sources) {
      const s = l.state;
      s === ee ? l !== t && (!l.updatedAt || l.updatedAt < Te) && ke(l) : s === Ce && Ee(l, t);
    }
  }
}
function gt(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const r = e.observers[t];
    r.state || (r.state = Ce, r.pure ? C.push(r) : X.push(r), r.observers && gt(r));
  }
}
function ge(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const r = e.sources.pop(), l = e.sourceSlots.pop(), s = r.observers;
      if (s && s.length) {
        const o = s.pop(), i = r.observerSlots.pop();
        l < s.length && (o.sourceSlots[i] = l, s[l] = o, r.observerSlots[l] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) ge(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) ge(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function Jt(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function vt(e, t = $) {
  throw Jt(e);
}
const Zt = Symbol("fallback");
function at(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function er(e, t, r = {}) {
  let l = [], s = [], o = [], i = 0, n = t.length > 1 ? [] : null;
  return Kt(() => at(o)), () => {
    let u = e() || [], f = u.length, g, c;
    return u[qt], ie(() => {
      let I, U, m, d, D, O, L, R, V;
      if (f === 0)
        i !== 0 && (at(o), o = [], l = [], s = [], i = 0, n && (n = [])), r.fallback && (l = [Zt], s[0] = Pe((me) => (o[0] = me, r.fallback())), i = 1);
      else if (i === 0) {
        for (s = new Array(f), c = 0; c < f; c++)
          l[c] = u[c], s[c] = Pe(F);
        i = f;
      } else {
        for (m = new Array(f), d = new Array(f), n && (D = new Array(f)), O = 0, L = Math.min(i, f); O < L && l[O] === u[O]; O++) ;
        for (L = i - 1, R = f - 1; L >= O && R >= O && l[L] === u[R]; L--, R--)
          m[R] = s[L], d[R] = o[L], n && (D[R] = n[L]);
        for (I = /* @__PURE__ */ new Map(), U = new Array(R + 1), c = R; c >= O; c--)
          V = u[c], g = I.get(V), U[c] = g === void 0 ? -1 : g, I.set(V, c);
        for (g = O; g <= L; g++)
          V = l[g], c = I.get(V), c !== void 0 && c !== -1 ? (m[c] = s[g], d[c] = o[g], n && (D[c] = n[g]), c = U[c], I.set(V, c)) : o[g]();
        for (c = O; c < f; c++)
          c in m ? (s[c] = m[c], o[c] = d[c], n && (n[c] = D[c], n[c](c))) : s[c] = Pe(F);
        s = s.slice(0, i = f), l = u.slice(0);
      }
      return s;
    });
    function F(I) {
      if (o[c] = I, n) {
        const [U, m] = N(c);
        return n[c] = m, t(u[c], U);
      }
      return t(u[c]);
    }
  };
}
function T(e, t) {
  return ie(() => e(t || {}));
}
const tr = (e) => `Stale read from <${e}>.`;
function Re(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return ne(er(() => e.each, e.children, t || void 0));
}
function q(e) {
  const t = e.keyed, r = ne(() => e.when, void 0, void 0), l = t ? r : ne(r, void 0, {
    equals: (s, o) => !s == !o
  });
  return ne(
    () => {
      const s = l();
      if (s) {
        const o = e.children;
        return typeof o == "function" && o.length > 0 ? ie(
          () => o(
            t ? s : () => {
              if (!ie(l)) throw tr("Show");
              return r();
            }
          )
        ) : o;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function rr(e, t, r) {
  let l = r.length, s = t.length, o = l, i = 0, n = 0, u = t[s - 1].nextSibling, f = null;
  for (; i < s || n < o; ) {
    if (t[i] === r[n]) {
      i++, n++;
      continue;
    }
    for (; t[s - 1] === r[o - 1]; )
      s--, o--;
    if (s === i) {
      const g = o < l ? n ? r[n - 1].nextSibling : r[o - n] : u;
      for (; n < o; ) e.insertBefore(r[n++], g);
    } else if (o === n)
      for (; i < s; )
        (!f || !f.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === r[o - 1] && r[n] === t[s - 1]) {
      const g = t[--s].nextSibling;
      e.insertBefore(r[n++], t[i++].nextSibling), e.insertBefore(r[--o], g), t[s] = r[o];
    } else {
      if (!f) {
        f = /* @__PURE__ */ new Map();
        let c = n;
        for (; c < o; ) f.set(r[c], c++);
      }
      const g = f.get(t[i]);
      if (g != null)
        if (n < g && g < o) {
          let c = i, F = 1, I;
          for (; ++c < s && c < o && !((I = f.get(t[c])) == null || I !== g + F); )
            F++;
          if (F > g - n) {
            const U = t[i];
            for (; n < g; ) e.insertBefore(r[n++], U);
          } else e.replaceChild(r[n++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const ct = "_$DX_DELEGATE";
function lr(e, t, r, l = {}) {
  let s;
  return Pe((o) => {
    s = o, t === document ? e() : h(t, e(), t.firstChild ? null : void 0, r);
  }, l.owner), () => {
    s(), t.textContent = "";
  };
}
function P(e, t, r, l) {
  let s;
  const o = () => {
    const n = document.createElement("template");
    return n.innerHTML = e, n.content.firstChild;
  }, i = () => (s || (s = o())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function sr(e, t = window.document) {
  const r = t[ct] || (t[ct] = /* @__PURE__ */ new Set());
  for (let l = 0, s = e.length; l < s; l++) {
    const o = e[l];
    r.has(o) || (r.add(o), t.addEventListener(o, nr));
  }
}
function z(e, t, r) {
  r == null ? e.removeAttribute(t) : e.setAttribute(t, r);
}
function or(e, t, r) {
  if (!t) return r ? z(e, "style") : t;
  const l = e.style;
  if (typeof t == "string") return l.cssText = t;
  typeof r == "string" && (l.cssText = r = void 0), r || (r = {}), t || (t = {});
  let s, o;
  for (o in r)
    t[o] == null && l.removeProperty(o), delete r[o];
  for (o in t)
    s = t[o], s !== r[o] && (l.setProperty(o, s), r[o] = s);
  return r;
}
function h(e, t, r, l) {
  if (r !== void 0 && !l && (l = []), typeof t != "function") return Ae(e, t, l, r);
  K((s) => Ae(e, t(), s, r), l);
}
function nr(e) {
  let t = e.target;
  const r = `$$${e.type}`, l = e.target, s = e.currentTarget, o = (u) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: u
  }), i = () => {
    const u = t[r];
    if (u && !t.disabled) {
      const f = t[`${r}Data`];
      if (f !== void 0 ? u.call(t, f, e) : u.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && o(t.host), !0;
  }, n = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const u = e.composedPath();
    o(u[0]);
    for (let f = 0; f < u.length - 2 && (t = u[f], !!i()); f++) {
      if (t._$host) {
        t = t._$host, n();
        break;
      }
      if (t.parentNode === s)
        break;
    }
  } else n();
  o(l);
}
function Ae(e, t, r, l, s) {
  for (; typeof r == "function"; ) r = r();
  if (t === r) return r;
  const o = typeof t, i = l !== void 0;
  if (e = i && r[0] && r[0].parentNode || e, o === "string" || o === "number") {
    if (o === "number" && (t = t.toString(), t === r))
      return r;
    if (i) {
      let n = r[0];
      n && n.nodeType === 3 ? n.data !== t && (n.data = t) : n = document.createTextNode(t), r = ue(e, r, l, n);
    } else
      r !== "" && typeof r == "string" ? r = e.firstChild.data = t : r = e.textContent = t;
  } else if (t == null || o === "boolean")
    r = ue(e, r, l);
  else {
    if (o === "function")
      return K(() => {
        let n = t();
        for (; typeof n == "function"; ) n = n();
        r = Ae(e, n, r, l);
      }), () => r;
    if (Array.isArray(t)) {
      const n = [], u = r && Array.isArray(r);
      if (Ne(n, t, r, s))
        return K(() => r = Ae(e, n, r, l, !0)), () => r;
      if (n.length === 0) {
        if (r = ue(e, r, l), i) return r;
      } else u ? r.length === 0 ? dt(e, n, l) : rr(e, r, n) : (r && ue(e), dt(e, n));
      r = n;
    } else if (t.nodeType) {
      if (Array.isArray(r)) {
        if (i) return r = ue(e, r, l, t);
        ue(e, r, null, t);
      } else r == null || r === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      r = t;
    }
  }
  return r;
}
function Ne(e, t, r, l) {
  let s = !1;
  for (let o = 0, i = t.length; o < i; o++) {
    let n = t[o], u = r && r[e.length], f;
    if (!(n == null || n === !0 || n === !1)) if ((f = typeof n) == "object" && n.nodeType)
      e.push(n);
    else if (Array.isArray(n))
      s = Ne(e, n, u) || s;
    else if (f === "function")
      if (l) {
        for (; typeof n == "function"; ) n = n();
        s = Ne(
          e,
          Array.isArray(n) ? n : [n],
          Array.isArray(u) ? u : [u]
        ) || s;
      } else
        e.push(n), s = !0;
    else {
      const g = String(n);
      u && u.nodeType === 3 && u.data === g ? e.push(u) : e.push(document.createTextNode(g));
    }
  }
  return s;
}
function dt(e, t, r = null) {
  for (let l = 0, s = t.length; l < s; l++) e.insertBefore(t[l], r);
}
function ue(e, t, r, l) {
  if (r === void 0) return e.textContent = "";
  const s = l || document.createTextNode("");
  if (t.length) {
    let o = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const n = t[i];
      if (s !== n) {
        const u = n.parentNode === e;
        !o && !i ? u ? e.replaceChild(s, n) : e.insertBefore(s, r) : u && n.remove();
      } else o = !0;
    }
  } else e.insertBefore(s, r);
  return [s];
}
const ir = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, he = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const r = ir();
  return r[e] ? r[e] : e;
}, wt = {}, ar = () => document.readyState !== "loading";
function mt(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  wt[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function bt(e) {
  return wt[e] || null;
}
function xt(e, t, r = {}) {
  const l = bt(e);
  if (!l)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const s = lr(() => l(r), t);
    return t.dataset.solidInitialized = "true", s;
  } catch (s) {
    return console.error(`Error al renderizar el componente '${e}':`, s), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${s.message}</p>
      </div>
    `, null;
  }
}
function Fe() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const r = t.dataset.solidComponent;
    if (!r || t.dataset.solidInitialized === "true") return;
    let l = {};
    try {
      t.dataset.props && (l = JSON.parse(t.dataset.props));
    } catch (s) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        s
      );
    }
    xt(r, t, l);
  });
}
ar() ? Fe() : document.addEventListener("DOMContentLoaded", Fe);
const _t = {
  registerComponent: mt,
  getComponent: bt,
  renderComponent: xt,
  initComponents: Fe
};
window.solidCore = _t;
var cr = /* @__PURE__ */ P('<svg xmlns=http://www.w3.org/2000/svg class="h-5 w-5 transition-transform duration-300 inline-block"viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z">'), dr = /* @__PURE__ */ P('<div class=relative><div class="rounded-full overflow-hidden border-2 p-1"><img class="w-16 h-16 object-cover rounded-full"></div><div class="hidden absolute inset-0 items-center justify-center rounded-full border-2 p-1"><span class="text-3xl fancy-text font-bold text-white">'), ur = /* @__PURE__ */ P('<div class="w-16 h-16 flex items-center justify-center rounded-full border-2 p-1"><span class="text-3xl fancy-text font-bold text-white">'), fr = /* @__PURE__ */ P('<p class="text-xl md:text-2xl fancy-text font-light mt-8 max-w-2xl mx-auto italic opacity-80">'), pr = /* @__PURE__ */ P('<div class="flex flex-col justify-center items-center p-8 h-64"><div class="relative w-16 h-16"><div class="absolute top-0 left-0 w-full h-full border-4 border-gray-200 rounded-full"></div><div class="absolute top-0 left-0 w-full h-full border-4 rounded-full animate-spin"></div></div><span class="mt-4 text-lg fancy-text italic">'), yr = /* @__PURE__ */ P('<div class="bg-red-50 border border-red-100 text-red-700 p-6 rounded-lg shadow-sm mb-8 fancy-text italic text-center">'), hr = /* @__PURE__ */ P('<div class="solid-reviews-carousel mx-auto max-w-6xl relative mt-12"><div class="absolute -left-8 top-0 opacity-10 pointer-events-none transform -translate-y-1/2"><svg xmlns=http://www.w3.org/2000/svg width=120 height=120 viewBox="0 0 24 24"><path d="M13 14.725c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275zm-13 0c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275z"></path></svg></div><div class="overflow-hidden rounded-xl shadow-xl relative"><div class="flex transition-transform"></div></div><div class="flex justify-center mt-10 space-x-3"></div><div class="hidden md:flex justify-between items-center absolute -bottom-2 left-0 right-0 translate-y-full pt-8"><button class="w-12 h-12 rounded-full bg-white shadow-md hover:shadow-lg transition-all duration-300 flex items-center justify-center group border border-gray-100"><svg xmlns=http://www.w3.org/2000/svg class="h-5 w-5 transition-transform duration-300 group-hover:-translate-x-1"fill=none viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7"></path></svg></button><div class=text-center><a href="https://www.google.com/maps/place/MASSAGES+CUSCO+%7C+MYSTICAL+TERRA+SPA/@-13.516813,-71.9782094,19.17z/data=!4m15!1m8!3m7!1s0x916dd6736815a6bf:0x6bba173f1e0a44a8!2sTriunfo+338,+Cusco+08000,+Per%C3%BA!3b1!8m2!3d-13.5165525!4d-71.9772607!16s%2Fg%2F11q2x8b8xl!3m5!1s0x916dd7d179c38439:0x7e61b655c44a7559!8m2!3d-13.5167063!4d-71.9771131!16s%2Fg%2F11vf1y25c9?hl=es-ES&amp;entry=ttu&amp;g_ep=EgoyMDI1MDMyNC4wIKXMDSoASAFQAw%3D%3D"target=_blank rel="noopener noreferrer"class="inline-flex items-center gap-2 text-sm font-medium py-2 px-4 rounded-full transition-all duration-300 group"><svg xmlns=http://www.w3.org/2000/svg class="h-4 w-4 transition-all duration-300 group-hover:scale-110"viewBox="0 0 24 24"fill=currentColor><path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z"></path></svg></a></div><button class="w-12 h-12 rounded-full bg-white shadow-md hover:shadow-lg transition-all duration-300 flex items-center justify-center group border border-gray-100"><svg xmlns=http://www.w3.org/2000/svg class="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1"fill=none viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), gr = /* @__PURE__ */ P('<div class="flex justify-center mt-4 opacity-80"><a href=https://www.google.com/business/ target=_blank rel="noopener noreferrer"class="flex items-center gap-2 text-xs text-gray-500 transition hover:text-gray-700"><svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 24 24"width=14 height=14 fill=#4285F4><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"></path><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"fill=#34A853></path><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"fill=#FBBC05></path><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"fill=#EA4335>'), vr = /* @__PURE__ */ P('<div class="solid-google-reviews-container w-full py-16 md:py-24 overflow-hidden"><div class="absolute -left-16 top-1/4 w-64 h-64 opacity-10 pointer-events-none rounded-full"></div><div class="absolute -right-16 bottom-1/4 w-48 h-48 opacity-10 pointer-events-none rounded-full"></div><div class="container mx-auto px-4 relative"><div class="text-center mb-16 relative"><div class="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 opacity-10 pointer-events-none"><svg xmlns=http://www.w3.org/2000/svg width=120 height=120 viewBox="0 0 24 24"class="transform rotate-12"><path d="M19.5 4c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5h2c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5h-2zm-17 0c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5h2c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5h-2zm13.5 2c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm10 7c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm10 7c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2z"></path></svg></div><span class="block text-lg italic font-medium mb-2"></span><div class="relative inline-block"><h2 class="text-3xl md:text-4xl lg:text-5xl fancy-text font-medium mb-4"></h2><div class="absolute -bottom-2 left-1/2 w-24 h-0.5 transform -translate-x-1/2"><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2"></div></div></div><div class="absolute left-1/2 bottom-0 transform -translate-x-1/2 translate-y-full"><svg xmlns=http://www.w3.org/2000/svg width=24 height=24 viewBox="0 0 24 24"fill=none stroke-width=1 stroke-linecap=round stroke-linejoin=round><path d="M12 22V2M2 12h20M17 7l-5 5-5-5M17 17l-5-5-5 5"class=opacity-40>'), wr = /* @__PURE__ */ P('<div class="hidden lg:flex items-center justify-center opacity-10"><svg xmlns=http://www.w3.org/2000/svg width=160 height=160 viewBox="0 0 24 24"class="transform rotate-12"><path d="M19.5 4c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5h2c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5h-2zm-17 0c-.276 0-.5.224-.5.5v15c0 .276.224.5.5.5h2c.276 0 .5-.224.5-.5v-15c0-.276-.224-.5-.5-.5h-2zm13.5 2c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm10 7c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm10 7c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2zm-10 0c0 1.103-.897 2-2 2s-2-.897-2-2 .897-2 2-2 2 .897 2 2z">'), mr = /* @__PURE__ */ P('<div class="min-w-full p-8"><div class="grid grid-cols-1 lg:grid-cols-2 gap-8">'), br = /* @__PURE__ */ P("<div class=mr-4>"), xr = /* @__PURE__ */ P('<h3 class="text-xl fancy-text font-medium mb-1 transition-all">'), _r = /* @__PURE__ */ P('<p class="text-sm opacity-60 italic mb-1">'), $r = /* @__PURE__ */ P('<div class="flex mt-1">'), Pr = /* @__PURE__ */ P('<p class="text-xs opacity-50 mt-2 italic">'), Sr = /* @__PURE__ */ P('<div class="review-card bg-white rounded-xl overflow-hidden h-full relative group"><div class="absolute inset-0 opacity-5 pointer-events-none"></div><div class="absolute top-4 right-4 text-4xl fancy-text opacity-20 leading-none">"</div><div class="relative p-6 flex flex-col h-full z-10"><div class="flex items-start mb-4"><div class="flex-1 pt-2"></div></div><div class="w-full h-px my-3 relative overflow-hidden"><div class="absolute inset-0 opacity-20"></div><div class="absolute left-0 top-0 h-full w-1/3 transition-all duration-500"></div></div><div class="review-content flex-grow mb-4 relative overflow-hidden"><p class="text-base font-light leading-relaxed relative italic"></p></div><div class="mt-auto text-right">'), Cr = /* @__PURE__ */ P('<button class="w-3 h-3 rounded-full transition-all duration-300 relative"><span class="absolute inset-0 rounded-full animate-ping">');
const kr = (e) => {
  const {
    title: t = he("What Our Clients Say", "wp-tailwind-blocks"),
    subtitle: r = he("Testimonials", "wp-tailwind-blocks"),
    description: l = he("Discover the experiences of those who have already enjoyed our services", "wp-tailwind-blocks"),
    reviews: s = [],
    placeInfo: o = {},
    displayName: i = !0,
    displayAvatar: n = !0,
    displayRating: u = !0,
    displayDate: f = !0,
    displayRole: g = !0,
    clientRole: c = he("Client", "wp-tailwind-blocks"),
    autoplay: F = !0,
    autoplaySpeed: I = 6e3,
    backgroundColor: U = "#F9F5F2",
    // Color de fondo suave y cálido
    textColor: m = "#5D534F",
    // Color de texto más cálido que el negro puro
    accentColor: d = "#D4B254",
    // Dorado elegante
    secondaryColor: D = "#8BAB8D",
    // Verde salvia para elementos secundarios
    carouselType: O = "slide",
    ajaxUrl: L = "",
    nonce: R = "",
    placeId: V = "",
    apiKey: me = "",
    reviewCount: $t = 5,
    minRating: Pt = 4,
    isDynamic: He = !1
  } = e, B = (a, _ = "wptbt-google-reviews-block") => {
    const y = window.wptbtI18n_google_reviews || {};
    return y[a] ? y[a] : he(a, _);
  }, [fe, Ie] = N(0), [St, Ct] = N(s || []), [Er, kt] = N(o || {}), [qe, Ve] = N(He), [De, Et] = N(null), [Ye, At] = N([]), [be, Tt] = N(0), [pe, Ke] = N(null), [Xe, Qe] = N(!1), [xe, We] = N(null), Je = () => {
    pe() && (clearInterval(pe()), Ke(null));
  }, Ze = () => {
    if (F && !pe() && !Xe()) {
      const a = setInterval(() => {
        et();
      }, I);
      Ke(a);
    }
  }, et = () => {
    Ie((a) => (a + 1) % be());
  }, It = () => {
    Ie((a) => (a - 1 + be()) % be());
  }, Dt = (a) => {
    Ie(a);
  }, Lt = async () => {
    if (!V || !me) {
      console.warn(B("Google Reviews: Place ID and API Key are required to load dynamic reviews", "wp-tailwind-blocks")), Ve(!1);
      return;
    }
    try {
      const a = new FormData();
      a.append("action", "get_google_reviews"), a.append("nonce", R), a.append("place_id", V), a.append("api_key", me), a.append("review_count", $t), a.append("min_rating", Pt);
      const _ = await fetch(L, {
        method: "POST",
        credentials: "same-origin",
        body: a
      });
      if (!_.ok)
        throw new Error(`${B("Error in response", "wp-tailwind-blocks")}: ${_.status} ${_.statusText}`);
      const y = await _.json();
      if (y.success && y.data.reviews)
        Ct(y.data.reviews), kt(y.data.place_info);
      else
        throw new Error(B("Invalid response format", "wp-tailwind-blocks"));
    } catch (a) {
      console.error(B("Error loading reviews:", "wp-tailwind-blocks"), a), Et(B("Unable to load reviews. Please try again later.", "wp-tailwind-blocks"));
    } finally {
      Ve(!1);
    }
  }, Mt = (a) => {
    const _ = [];
    for (let y = 0; y < a.length; y += 2)
      y + 1 < a.length ? _.push([a[y], a[y + 1]]) : _.push([a[y]]);
    return _;
  };
  Yt(() => (He && Lt(), F && Ze(), () => {
    pe() && clearInterval(pe());
  })), Be(() => {
    const a = Mt(St());
    At(a), Tt(a.length);
  }), Be(() => {
    !Xe() && F && Ze();
  });
  const jt = (a) => {
    const _ = [];
    for (let y = 1; y <= 5; y++)
      _.push((() => {
        var v = cr();
        return v.style.setProperty("transform-origin", "center"), (y <= a ? d : "#E9E2D8") != null ? v.style.setProperty("fill", y <= a ? d : "#E9E2D8") : v.style.removeProperty("fill"), K((M) => (M = y <= xe() ? "scale(1.2)" : "scale(1)") != null ? v.style.setProperty("transform", M) : v.style.removeProperty("transform")), v;
      })());
    return _;
  }, zt = (a, _) => {
    const y = _ === xe();
    return a.profile_photo_url ? (() => {
      var v = dr(), M = v.firstChild, Q = M.firstChild, te = M.nextSibling, ae = te.firstChild;
      return v.style.setProperty("transition", "all 0.3s ease"), (y ? "scale(1.05)" : "scale(1)") != null ? v.style.setProperty("transform", y ? "scale(1.05)" : "scale(1)") : v.style.removeProperty("transform"), d != null ? M.style.setProperty("border-color", d) : M.style.removeProperty("border-color"), Q.addEventListener("error", (E) => {
        E.target.style.display = "none", E.target.nextElementSibling.style.display = "flex";
      }), d != null ? te.style.setProperty("border-color", d) : te.style.removeProperty("border-color"), D != null ? te.style.setProperty("background-color", D) : te.style.removeProperty("background-color"), h(ae, (() => {
        var E = ne(() => !!a.author_name);
        return () => E() ? a.author_name.charAt(0) : "?";
      })()), K((E) => {
        var ye = a.profile_photo_url, ce = a.author_name;
        return ye !== E.e && z(Q, "src", E.e = ye), ce !== E.t && z(Q, "alt", E.t = ce), E;
      }, {
        e: void 0,
        t: void 0
      }), v;
    })() : (() => {
      var v = ur(), M = v.firstChild;
      return d != null ? v.style.setProperty("border-color", d) : v.style.removeProperty("border-color"), D != null ? v.style.setProperty("background-color", D) : v.style.removeProperty("background-color"), v.style.setProperty("transition", "all 0.3s ease"), (y ? "scale(1.05)" : "scale(1)") != null ? v.style.setProperty("transform", y ? "scale(1.05)" : "scale(1)") : v.style.removeProperty("transform"), h(M, (() => {
        var Q = ne(() => !!a.author_name);
        return () => Q() ? a.author_name.charAt(0) : "?";
      })()), v;
    })();
  }, Ot = () => ({
    transform: `translateX(-${fe() * 100}%)`,
    transition: "transform 0.8s cubic-bezier(0.4, 0, 0.2, 1)"
  });
  return (() => {
    var a = vr(), _ = a.firstChild, y = _.nextSibling, v = y.nextSibling, M = v.firstChild, Q = M.firstChild, te = Q.firstChild, ae = Q.nextSibling, E = ae.nextSibling, ye = E.firstChild, ce = ye.nextSibling, tt = ce.firstChild, rt = E.nextSibling, Rt = rt.firstChild;
    return a.addEventListener("mouseleave", () => Qe(!1)), a.addEventListener("mouseenter", () => Qe(!0)), U != null ? a.style.setProperty("background-color", U) : a.style.removeProperty("background-color"), m != null ? a.style.setProperty("color", m) : a.style.removeProperty("color"), a.style.setProperty("background-image", `
          radial-gradient(circle at 10% 20%, rgba(138, 171, 141, 0.05) 0%, rgba(138, 171, 141, 0) 20%),
          radial-gradient(circle at 90% 80%, rgba(212, 178, 84, 0.07) 0%, rgba(212, 178, 84, 0) 20%)
        `), D != null ? _.style.setProperty("background-color", D) : _.style.removeProperty("background-color"), d != null ? y.style.setProperty("background-color", d) : y.style.removeProperty("background-color"), z(te, "fill", D), d != null ? ae.style.setProperty("color", d) : ae.style.removeProperty("color"), h(ae, r), h(ye, t), d != null ? ce.style.setProperty("background-color", d) : ce.style.removeProperty("background-color"), d != null ? tt.style.setProperty("background-color", d) : tt.style.removeProperty("background-color"), h(M, T(q, {
      when: l,
      get children() {
        var k = fr();
        return h(k, l), k;
      }
    }), rt), z(Rt, "stroke", d), h(v, T(q, {
      get when() {
        return qe();
      },
      get children() {
        var k = pr(), W = k.firstChild, Le = W.firstChild, Y = Le.nextSibling, de = W.nextSibling;
        return `${d} transparent transparent transparent` != null ? Y.style.setProperty("border-color", `${d} transparent transparent transparent`) : Y.style.removeProperty("border-color"), Y.style.setProperty("animation-duration", "1.5s"), m != null ? de.style.setProperty("color", m) : de.style.removeProperty("color"), h(de, () => B("Loading testimonials...", "wp-tailwind-blocks")), k;
      }
    }), null), h(v, T(q, {
      get when() {
        return De();
      },
      get children() {
        var k = yr();
        return h(k, De), k;
      }
    }), null), h(v, T(q, {
      get when() {
        return ne(() => !qe() && !De())() && Ye().length > 0;
      },
      get children() {
        return [(() => {
          var k = hr(), W = k.firstChild, Le = W.firstChild, Y = W.nextSibling, de = Y.firstChild, lt = Y.nextSibling, Bt = lt.nextSibling, J = Bt.firstChild, Nt = J.firstChild, st = J.nextSibling, G = st.firstChild;
          G.firstChild;
          var re = st.nextSibling, Ft = re.firstChild;
          return z(Le, "fill", d), Y.style.setProperty("box-shadow", "0 15px 35px rgba(0,0,0,0.05), 0 5px 15px rgba(0,0,0,0.03)"), Y.style.setProperty("background-color", "rgba(255,255,255,0.9)"), Y.style.setProperty("backdrop-filter", "blur(10px)"), h(de, T(Re, {
            get each() {
              return Ye();
            },
            children: (p, H) => (() => {
              var S = mr(), A = S.firstChild;
              return h(A, T(Re, {
                each: p,
                children: (w, le) => {
                  const Z = H() * 2 + le();
                  return (() => {
                    var j = Sr(), se = j.firstChild, oe = se.nextSibling, Ut = oe.nextSibling, Me = Ut.firstChild, _e = Me.firstChild, ot = Me.nextSibling, je = ot.firstChild, $e = je.nextSibling, nt = ot.nextSibling, ze = nt.firstChild, Gt = nt.nextSibling;
                    return j.addEventListener("mouseleave", () => We(null)), j.addEventListener("mouseenter", () => We(Z)), j.style.setProperty("border", "1px solid rgba(0,0,0,0.05)"), j.style.setProperty("box-shadow", "0 4px 16px rgba(0,0,0,0.04)"), j.style.setProperty("transform", "translateY(0)"), j.style.setProperty("transition", "all 0.4s ease-out"), `radial-gradient(circle at top right, ${d}, transparent 70%)` != null ? se.style.setProperty("background", `radial-gradient(circle at top right, ${d}, transparent 70%)`) : se.style.removeProperty("background"), se.style.setProperty("z-index", "0"), d != null ? oe.style.setProperty("color", d) : oe.style.removeProperty("color"), h(Me, T(q, {
                      when: n,
                      get children() {
                        var b = br();
                        return h(b, () => zt(w, Z)), b;
                      }
                    }), _e), h(_e, T(q, {
                      when: i,
                      get children() {
                        var b = xr();
                        return m != null ? b.style.setProperty("color", m) : b.style.removeProperty("color"), h(b, () => w.author_name), K((it) => (it = Z === xe() ? `0 0 1px ${d}33` : "none") != null ? b.style.setProperty("text-shadow", it) : b.style.removeProperty("text-shadow")), b;
                      }
                    }), null), h(_e, T(q, {
                      when: g,
                      get children() {
                        var b = _r();
                        return h(b, c), b;
                      }
                    }), null), h(_e, T(q, {
                      get when() {
                        return u && w.rating;
                      },
                      get children() {
                        var b = $r();
                        return h(b, () => jt(w.rating)), b;
                      }
                    }), null), d != null ? je.style.setProperty("background-color", d) : je.style.removeProperty("background-color"), d != null ? $e.style.setProperty("background-color", d) : $e.style.removeProperty("background-color"), m != null ? ze.style.setProperty("color", m) : ze.style.removeProperty("color"), h(ze, () => w.text), h(Gt, T(q, {
                      get when() {
                        return f && w.relative_time_description;
                      },
                      get children() {
                        var b = Pr();
                        return h(b, () => w.relative_time_description), b;
                      }
                    })), K((b) => (b = Z === xe() ? "translateX(200%)" : "translateX(0)") != null ? $e.style.setProperty("transform", b) : $e.style.removeProperty("transform")), j;
                  })();
                }
              }), null), h(A, T(q, {
                get when() {
                  return p.length === 1;
                },
                get children() {
                  var w = wr(), le = w.firstChild;
                  return z(le, "fill", d), w;
                }
              }), null), S;
            })()
          })), h(lt, T(Re, {
            get each() {
              return Array(be()).fill(0);
            },
            children: (p, H) => (() => {
              var S = Cr(), A = S.firstChild;
              return S.$$click = () => Dt(H()), d != null ? A.style.setProperty("background-color", d) : A.style.removeProperty("background-color"), A.style.setProperty("animation-duration", "1.5s"), A.style.setProperty("animation-iteration-count", "infinite"), A.style.setProperty("animation-delay", "0.3s"), K((w) => {
                var le = fe() === H() ? d : "#E9E2D8", Z = fe() === H() ? "scale(1.2)" : "scale(1)", j = fe() === H() ? "1" : "0.7", se = B("Go to testimonial", "wp-tailwind-blocks") + " " + (H() + 1), oe = fe() === H() ? "0.4" : "0";
                return le !== w.e && ((w.e = le) != null ? S.style.setProperty("background-color", le) : S.style.removeProperty("background-color")), Z !== w.t && ((w.t = Z) != null ? S.style.setProperty("transform", Z) : S.style.removeProperty("transform")), j !== w.a && ((w.a = j) != null ? S.style.setProperty("opacity", j) : S.style.removeProperty("opacity")), se !== w.o && z(S, "aria-label", w.o = se), oe !== w.i && ((w.i = oe) != null ? A.style.setProperty("opacity", oe) : A.style.removeProperty("opacity")), w;
              }, {
                e: void 0,
                t: void 0,
                a: void 0,
                o: void 0,
                i: void 0
              }), S;
            })()
          })), J.addEventListener("mouseleave", (p) => {
            p.currentTarget.style.transform = "translateY(0px)", p.currentTarget.style.boxShadow = "";
          }), J.addEventListener("mouseenter", (p) => {
            p.currentTarget.style.transform = "translateY(-3px)", p.currentTarget.style.boxShadow = "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)";
          }), J.$$click = () => {
            Je(), It();
          }, J.style.setProperty("transform", "translateY(0px)"), J.style.setProperty("transition", "all 0.3s ease"), z(Nt, "stroke", m), G.addEventListener("mouseleave", (p) => {
            p.currentTarget.style.backgroundColor = "rgba(255,255,255,0.8)", p.currentTarget.style.color = m, p.currentTarget.style.boxShadow = "0 2px 10px rgba(0,0,0,0.05)";
          }), G.addEventListener("mouseenter", (p) => {
            p.currentTarget.style.backgroundColor = d, p.currentTarget.style.color = "white", p.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.1)";
          }), G.style.setProperty("background-color", "rgba(255,255,255,0.8)"), `1px solid ${d}40` != null ? G.style.setProperty("border", `1px solid ${d}40`) : G.style.removeProperty("border"), m != null ? G.style.setProperty("color", m) : G.style.removeProperty("color"), G.style.setProperty("box-shadow", "0 2px 10px rgba(0,0,0,0.05)"), h(G, () => B("Leave your review", "wp-tailwind-blocks"), null), re.addEventListener("mouseleave", (p) => {
            p.currentTarget.style.transform = "translateY(0px)", p.currentTarget.style.boxShadow = "";
          }), re.addEventListener("mouseenter", (p) => {
            p.currentTarget.style.transform = "translateY(-3px)", p.currentTarget.style.boxShadow = "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)";
          }), re.$$click = () => {
            Je(), et();
          }, re.style.setProperty("transform", "translateY(0px)"), re.style.setProperty("transition", "all 0.3s ease"), z(Ft, "stroke", m), K((p) => {
            var H = Ot(), S = B("Previous testimonial", "wp-tailwind-blocks"), A = B("Next testimonial", "wp-tailwind-blocks");
            return p.e = or(de, H, p.e), S !== p.t && z(J, "aria-label", p.t = S), A !== p.a && z(re, "aria-label", p.a = A), p;
          }, {
            e: void 0,
            t: void 0,
            a: void 0
          }), k;
        })(), (() => {
          var k = gr(), W = k.firstChild;
          return W.firstChild, h(W, () => B("Google Reviews", "wp-tailwind-blocks"), null), k;
        })()];
      }
    }), null), a;
  })();
};
sr(["click"]);
mt("google-reviews", kr);
function Ue() {
  const e = document.querySelectorAll(
    ".solid-google-reviews-container"
  );
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      let r = [], l = {}, s = t.dataset.dynamic === "true";
      try {
        t.dataset.reviews && (r = JSON.parse(t.dataset.reviews)), t.dataset.placeInfo && (l = JSON.parse(t.dataset.placeInfo));
      } catch (n) {
        console.warn("Error al parsear datos de reseñas:", n);
      }
      const o = {
        title: t.dataset.title || "What Our Clients Say",
        subtitle: t.dataset.subtitle || "Google Reviews",
        description: t.dataset.description || "See what our customers are saying about us",
        reviews: r,
        placeInfo: l,
        displayName: t.dataset.displayName !== "false",
        displayAvatar: t.dataset.displayAvatar !== "false",
        displayRating: t.dataset.displayRating !== "false",
        displayDate: t.dataset.displayDate === "true",
        displayRole: t.dataset.displayRole !== "false",
        clientRole: t.dataset.clientRole || "Customer",
        autoplay: t.dataset.autoplay !== "false",
        autoplaySpeed: parseInt(t.dataset.autoplaySpeed) || 5e3,
        backgroundColor: t.dataset.backgroundColor || "#FFFFFF",
        textColor: t.dataset.textColor || "#424242",
        accentColor: t.dataset.accentColor || "#D4B254",
        carouselType: t.dataset.effect || "slide",
        ajaxUrl: t.dataset.ajaxUrl || "",
        nonce: t.dataset.nonce || "",
        placeId: t.dataset.placeId || "",
        apiKey: t.dataset.apiKey || "",
        reviewCount: parseInt(t.dataset.reviewCount) || 5,
        minRating: parseInt(t.dataset.minRating) || 4,
        isDynamic: s
      }, i = _t.renderComponent(
        "google-reviews",
        t,
        o
      );
      t._solidDispose = i, console.log(
        "Componente de reseñas de Google con Solid.js cargado correctamente"
      );
    } catch (r) {
      console.error(
        "Error al inicializar componente de reseñas con Solid.js:",
        r
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de reseñas: ${r.message}</p>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", Ue) : Ue();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((r) => {
        if (r.isIntersecting) {
          const l = r.target;
          l.classList.contains("solid-google-reviews-container") && l.dataset.intersectOnce === "true" && l.dataset.solidInitialized !== "true" && (Ue(), l.dataset.intersectOnce = "true"), e.unobserve(r.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  document.querySelectorAll(".solid-google-reviews-container[data-intersect-once]").forEach((t) => {
    e.observe(t);
  });
}
export {
  Ue as initGoogleReviews
};
