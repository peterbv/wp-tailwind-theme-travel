const lt = (e, t) => e === t, it = Symbol("solid-track"), ae = {
  equals: lt
};
let Me = He;
const U = 1, ue = 2, je = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var v = null;
let we = null, at = null, b = null, $ = null, N = null, pe = 0;
function le(e, t) {
  const s = b, n = v, o = e.length === 0, r = t === void 0 ? n : t, i = o ? je : {
    owned: null,
    cleanups: null,
    context: r ? r.context : null,
    owner: r
  }, l = o ? e : () => e(() => z(() => Z(i)));
  v = i, b = null;
  try {
    return te(l, !0);
  } finally {
    b = s, v = n;
  }
}
function O(e, t) {
  t = t ? Object.assign({}, ae, t) : ae;
  const s = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, n = (o) => (typeof o == "function" && (o = o(s.value)), Fe(s, o));
  return [Be.bind(s), n];
}
function j(e, t, s) {
  const n = ve(e, t, !1, U);
  ee(n);
}
function Ne(e, t, s) {
  Me = ft;
  const n = ve(e, t, !1, U);
  n.user = !0, N ? N.push(n) : ee(n);
}
function ie(e, t, s) {
  s = s ? Object.assign({}, ae, s) : ae;
  const n = ve(e, t, !0, 0);
  return n.observers = null, n.observerSlots = null, n.comparator = s.equals || void 0, ee(n), Be.bind(n);
}
function z(e) {
  if (b === null) return e();
  const t = b;
  b = null;
  try {
    return e();
  } finally {
    b = t;
  }
}
function ut(e) {
  Ne(() => z(e));
}
function ze(e) {
  return v === null || (v.cleanups === null ? v.cleanups = [e] : v.cleanups.push(e)), e;
}
function Be() {
  if (this.sources && this.state)
    if (this.state === U) ee(this);
    else {
      const e = $;
      $ = null, te(() => de(this), !1), $ = e;
    }
  if (b) {
    const e = this.observers ? this.observers.length : 0;
    b.sources ? (b.sources.push(this), b.sourceSlots.push(e)) : (b.sources = [this], b.sourceSlots = [e]), this.observers ? (this.observers.push(b), this.observerSlots.push(b.sources.length - 1)) : (this.observers = [b], this.observerSlots = [b.sources.length - 1]);
  }
  return this.value;
}
function Fe(e, t, s) {
  let n = e.value;
  return (!e.comparator || !e.comparator(n, t)) && (e.value = t, e.observers && e.observers.length && te(() => {
    for (let o = 0; o < e.observers.length; o += 1) {
      const r = e.observers[o], i = we && we.running;
      i && we.disposed.has(r), (i ? !r.tState : !r.state) && (r.pure ? $.push(r) : N.push(r), r.observers && Ue(r)), i || (r.state = U);
    }
    if ($.length > 1e6)
      throw $ = [], new Error();
  }, !1)), t;
}
function ee(e) {
  if (!e.fn) return;
  Z(e);
  const t = pe;
  ct(
    e,
    e.value,
    t
  );
}
function ct(e, t, s) {
  let n;
  const o = v, r = b;
  b = v = e;
  try {
    n = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = U, e.owned && e.owned.forEach(Z), e.owned = null), e.updatedAt = s + 1, Ve(i);
  } finally {
    b = r, v = o;
  }
  (!e.updatedAt || e.updatedAt <= s) && (e.updatedAt != null && "observers" in e ? Fe(e, n) : e.value = n, e.updatedAt = s);
}
function ve(e, t, s, n = U, o) {
  const r = {
    fn: e,
    state: n,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: v,
    context: v ? v.context : null,
    pure: s
  };
  return v === null || v !== je && (v.owned ? v.owned.push(r) : v.owned = [r]), r;
}
function ce(e) {
  if (e.state === 0) return;
  if (e.state === ue) return de(e);
  if (e.suspense && z(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < pe); )
    e.state && t.push(e);
  for (let s = t.length - 1; s >= 0; s--)
    if (e = t[s], e.state === U)
      ee(e);
    else if (e.state === ue) {
      const n = $;
      $ = null, te(() => de(e, t[0]), !1), $ = n;
    }
}
function te(e, t) {
  if ($) return e();
  let s = !1;
  t || ($ = []), N ? s = !0 : N = [], pe++;
  try {
    const n = e();
    return dt(s), n;
  } catch (n) {
    s || (N = null), $ = null, Ve(n);
  }
}
function dt(e) {
  if ($ && (He($), $ = null), e) return;
  const t = N;
  N = null, t.length && te(() => Me(t), !1);
}
function He(e) {
  for (let t = 0; t < e.length; t++) ce(e[t]);
}
function ft(e) {
  let t, s = 0;
  for (t = 0; t < e.length; t++) {
    const n = e[t];
    n.user ? e[s++] = n : ce(n);
  }
  for (t = 0; t < s; t++) ce(e[t]);
}
function de(e, t) {
  e.state = 0;
  for (let s = 0; s < e.sources.length; s += 1) {
    const n = e.sources[s];
    if (n.sources) {
      const o = n.state;
      o === U ? n !== t && (!n.updatedAt || n.updatedAt < pe) && ce(n) : o === ue && de(n, t);
    }
  }
}
function Ue(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const s = e.observers[t];
    s.state || (s.state = ue, s.pure ? $.push(s) : N.push(s), s.observers && Ue(s));
  }
}
function Z(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const s = e.sources.pop(), n = e.sourceSlots.pop(), o = s.observers;
      if (o && o.length) {
        const r = o.pop(), i = s.observerSlots.pop();
        n < o.length && (r.sourceSlots[i] = n, o[n] = r, s.observerSlots[n] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) Z(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) Z(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function ht(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function Ve(e, t = v) {
  throw ht(e);
}
const pt = Symbol("fallback");
function De(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function gt(e, t, s = {}) {
  let n = [], o = [], r = [], i = 0, l = t.length > 1 ? [] : null;
  return ze(() => De(r)), () => {
    let d = e() || [], h = d.length, f, a;
    return d[it], z(() => {
      let S, g, F, V, q, D, A, C, E;
      if (h === 0)
        i !== 0 && (De(r), r = [], n = [], o = [], i = 0, l && (l = [])), s.fallback && (n = [pt], o[0] = le((se) => (r[0] = se, s.fallback())), i = 1);
      else if (i === 0) {
        for (o = new Array(h), a = 0; a < h; a++)
          n[a] = d[a], o[a] = le(B);
        i = h;
      } else {
        for (F = new Array(h), V = new Array(h), l && (q = new Array(h)), D = 0, A = Math.min(i, h); D < A && n[D] === d[D]; D++) ;
        for (A = i - 1, C = h - 1; A >= D && C >= D && n[A] === d[C]; A--, C--)
          F[C] = o[A], V[C] = r[A], l && (q[C] = l[A]);
        for (S = /* @__PURE__ */ new Map(), g = new Array(C + 1), a = C; a >= D; a--)
          E = d[a], f = S.get(E), g[a] = f === void 0 ? -1 : f, S.set(E, a);
        for (f = D; f <= A; f++)
          E = n[f], a = S.get(E), a !== void 0 && a !== -1 ? (F[a] = o[f], V[a] = r[f], l && (q[a] = l[f]), a = g[a], S.set(E, a)) : r[f]();
        for (a = D; a < h; a++)
          a in F ? (o[a] = F[a], r[a] = V[a], l && (l[a] = q[a], l[a](a))) : o[a] = le(B);
        o = o.slice(0, i = h), n = d.slice(0);
      }
      return o;
    });
    function B(S) {
      if (r[a] = S, l) {
        const [g, F] = O(a);
        return l[a] = F, t(d[a], g);
      }
      return t(d[a]);
    }
  };
}
function L(e, t) {
  return z(() => e(t || {}));
}
const mt = (e) => `Stale read from <${e}>.`;
function Ie(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return ie(gt(() => e.each, e.children, t || void 0));
}
function H(e) {
  const t = e.keyed, s = ie(() => e.when, void 0, void 0), n = t ? s : ie(s, void 0, {
    equals: (o, r) => !o == !r
  });
  return ie(
    () => {
      const o = n();
      if (o) {
        const r = e.children;
        return typeof r == "function" && r.length > 0 ? z(
          () => r(
            t ? o : () => {
              if (!z(n)) throw mt("Show");
              return s();
            }
          )
        ) : r;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function wt(e, t, s) {
  let n = s.length, o = t.length, r = n, i = 0, l = 0, d = t[o - 1].nextSibling, h = null;
  for (; i < o || l < r; ) {
    if (t[i] === s[l]) {
      i++, l++;
      continue;
    }
    for (; t[o - 1] === s[r - 1]; )
      o--, r--;
    if (o === i) {
      const f = r < n ? l ? s[l - 1].nextSibling : s[r - l] : d;
      for (; l < r; ) e.insertBefore(s[l++], f);
    } else if (r === l)
      for (; i < o; )
        (!h || !h.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === s[r - 1] && s[l] === t[o - 1]) {
      const f = t[--o].nextSibling;
      e.insertBefore(s[l++], t[i++].nextSibling), e.insertBefore(s[--r], f), t[o] = s[r];
    } else {
      if (!h) {
        h = /* @__PURE__ */ new Map();
        let a = l;
        for (; a < r; ) h.set(s[a], a++);
      }
      const f = h.get(t[i]);
      if (f != null)
        if (l < f && f < r) {
          let a = i, B = 1, S;
          for (; ++a < o && a < r && !((S = h.get(t[a])) == null || S !== f + B); )
            B++;
          if (B > f - l) {
            const g = t[i];
            for (; l < f; ) e.insertBefore(s[l++], g);
          } else e.replaceChild(s[l++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const Pe = "_$DX_DELEGATE";
function yt(e, t, s, n = {}) {
  let o;
  return le((r) => {
    o = r, t === document ? e() : x(t, e(), t.firstChild ? null : void 0, s);
  }, n.owner), () => {
    o(), t.textContent = "";
  };
}
function T(e, t, s, n) {
  let o;
  const r = () => {
    const l = n ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return l.innerHTML = e, s ? l.content.firstChild.firstChild : n ? l.firstChild : l.content.firstChild;
  }, i = t ? () => z(() => document.importNode(o || (o = r()), !0)) : () => (o || (o = r())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function bt(e, t = window.document) {
  const s = t[Pe] || (t[Pe] = /* @__PURE__ */ new Set());
  for (let n = 0, o = e.length; n < o; n++) {
    const r = e[n];
    s.has(r) || (s.add(r), t.addEventListener(r, Ct));
  }
}
function M(e, t, s) {
  s == null ? e.removeAttribute(t) : e.setAttribute(t, s);
}
function vt(e, t) {
  t == null ? e.removeAttribute("class") : e.className = t;
}
function Le(e, t, s) {
  if (!t) return s ? M(e, "style") : t;
  const n = e.style;
  if (typeof t == "string") return n.cssText = t;
  typeof s == "string" && (n.cssText = s = void 0), s || (s = {}), t || (t = {});
  let o, r;
  for (r in s)
    t[r] == null && n.removeProperty(r), delete s[r];
  for (r in t)
    o = t[r], o !== s[r] && (n.setProperty(r, o), s[r] = o);
  return s;
}
function xt(e, t, s) {
  return z(() => e(t, s));
}
function x(e, t, s, n) {
  if (s !== void 0 && !n && (n = []), typeof t != "function") return fe(e, t, n, s);
  j((o) => fe(e, t(), o, s), n);
}
function Ct(e) {
  let t = e.target;
  const s = `$$${e.type}`, n = e.target, o = e.currentTarget, r = (d) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: d
  }), i = () => {
    const d = t[s];
    if (d && !t.disabled) {
      const h = t[`${s}Data`];
      if (h !== void 0 ? d.call(t, h, e) : d.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && r(t.host), !0;
  }, l = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const d = e.composedPath();
    r(d[0]);
    for (let h = 0; h < d.length - 2 && (t = d[h], !!i()); h++) {
      if (t._$host) {
        t = t._$host, l();
        break;
      }
      if (t.parentNode === o)
        break;
    }
  } else l();
  r(n);
}
function fe(e, t, s, n, o) {
  for (; typeof s == "function"; ) s = s();
  if (t === s) return s;
  const r = typeof t, i = n !== void 0;
  if (e = i && s[0] && s[0].parentNode || e, r === "string" || r === "number") {
    if (r === "number" && (t = t.toString(), t === s))
      return s;
    if (i) {
      let l = s[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), s = J(e, s, n, l);
    } else
      s !== "" && typeof s == "string" ? s = e.firstChild.data = t : s = e.textContent = t;
  } else if (t == null || r === "boolean")
    s = J(e, s, n);
  else {
    if (r === "function")
      return j(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        s = fe(e, l, s, n);
      }), () => s;
    if (Array.isArray(t)) {
      const l = [], d = s && Array.isArray(s);
      if (ye(l, t, s, o))
        return j(() => s = fe(e, l, s, n, !0)), () => s;
      if (l.length === 0) {
        if (s = J(e, s, n), i) return s;
      } else d ? s.length === 0 ? Oe(e, l, n) : wt(e, s, l) : (s && J(e), Oe(e, l));
      s = l;
    } else if (t.nodeType) {
      if (Array.isArray(s)) {
        if (i) return s = J(e, s, n, t);
        J(e, s, null, t);
      } else s == null || s === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      s = t;
    }
  }
  return s;
}
function ye(e, t, s, n) {
  let o = !1;
  for (let r = 0, i = t.length; r < i; r++) {
    let l = t[r], d = s && s[e.length], h;
    if (!(l == null || l === !0 || l === !1)) if ((h = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      o = ye(e, l, d) || o;
    else if (h === "function")
      if (n) {
        for (; typeof l == "function"; ) l = l();
        o = ye(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(d) ? d : [d]
        ) || o;
      } else
        e.push(l), o = !0;
    else {
      const f = String(l);
      d && d.nodeType === 3 && d.data === f ? e.push(d) : e.push(document.createTextNode(f));
    }
  }
  return o;
}
function Oe(e, t, s = null) {
  for (let n = 0, o = t.length; n < o; n++) e.insertBefore(t[n], s);
}
function J(e, t, s, n) {
  if (s === void 0) return e.textContent = "";
  const o = n || document.createTextNode("");
  if (t.length) {
    let r = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const l = t[i];
      if (o !== l) {
        const d = l.parentNode === e;
        !r && !i ? d ? e.replaceChild(o, l) : e.insertBefore(o, s) : d && l.remove();
      } else r = !0;
    }
  } else e.insertBefore(o, s);
  return [o];
}
const $t = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, St = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const s = $t();
  return s[e] ? s[e] : e;
}, qe = {}, Et = () => document.readyState !== "loading";
function Re(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  qe[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function We(e) {
  return qe[e] || null;
}
function Ge(e, t, s = {}) {
  const n = We(e);
  if (!n)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const o = yt(() => n(s), t);
    return t.dataset.solidInitialized = "true", o;
  } catch (o) {
    return console.error(`Error al renderizar el componente '${e}':`, o), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${o.message}</p>
      </div>
    `, null;
  }
}
function be() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const s = t.dataset.solidComponent;
    if (!s || t.dataset.solidInitialized === "true") return;
    let n = {};
    try {
      t.dataset.props && (n = JSON.parse(t.dataset.props));
    } catch (o) {
      console.warn(
        `Error al parsear propiedades para ${s}:`,
        o
      );
    }
    Ge(s, t, n);
  });
}
Et() ? be() : document.addEventListener("DOMContentLoaded", be);
const Je = {
  registerComponent: Re,
  getComponent: We,
  renderComponent: Ge,
  initComponents: be
};
window.solidCore = Je;
var At = /* @__PURE__ */ T("<script type=application/ld+json>"), kt = /* @__PURE__ */ T('<p class="block text-base italic font-medium mb-1">'), _t = /* @__PURE__ */ T('<div class="relative inline-block"><h2 class="text-2xl md:text-3xl font-bold mb-2"></h2><div class="absolute -bottom-1 left-1/2 w-16 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), Tt = /* @__PURE__ */ T('<p class="text-gray-600 mt-3 max-w-2xl mx-auto">'), Dt = /* @__PURE__ */ T('<header class="text-center mb-8 relative">'), It = /* @__PURE__ */ T('<button type=button class="carousel-prev absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-5 h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7">'), Pt = /* @__PURE__ */ T('<button type=button class="carousel-next absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-5 h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), Lt = /* @__PURE__ */ T('<div class="carousel-dots flex justify-center space-x-2 mt-6">'), Ot = /* @__PURE__ */ T('<section><div class="container mx-auto px-4 relative"><div class="destinations-carousel-wrapper relative"><div class="carousel-track overflow-hidden mx-12"><div class="carousel-slides flex transition-transform duration-600 ease-in-out">'), Mt = /* @__PURE__ */ T('<img class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"loading=lazy>', !0, !1, !1), jt = /* @__PURE__ */ T('<article class="destination-card flex-shrink-0 px-3 transition-all duration-300"><div class="destination-card-inner relative overflow-hidden rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl aspect-[4/3] cursor-pointer group"><div class="absolute inset-0"><div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div></div><a class="absolute inset-0 flex items-center justify-center text-center text-white z-10 group-hover:bg-black/10 transition-colors duration-300"><h3 class="text-2xl md:text-3xl font-bold tracking-tight drop-shadow-lg">'), Nt = /* @__PURE__ */ T('<div class="w-full h-full bg-gradient-to-br from-gray-200 via-gray-300 to-gray-400 flex items-center justify-center"><div class=text-center><svg class="w-12 h-12 text-gray-500 mx-auto mb-2"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=1.5 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=1.5 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg><p class="text-gray-600 text-sm font-medium">'), zt = /* @__PURE__ */ T('<button type=button class="carousel-dot w-3 h-3 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2">');
const Bt = (e) => {
  const t = (c, w = "wptbt-destinations-carousel") => {
    const y = window.wptbtI18n_destinations_carousel || {};
    return y[c] ? y[c] : St(c, w);
  }, {
    title: s = "",
    subtitle: n = "",
    description: o = "",
    destinations: r = [],
    autoplaySpeed: i = 3e3,
    // Velocidad del autoplay en ms
    showDots: l = !0,
    showArrows: d = !0,
    pauseOnHover: h = !0,
    infinite: f = !0,
    slidesToShow: a = 3,
    // Número de destinos visibles a la vez
    backgroundColor: B = "#F8FAFC",
    textColor: S = "#1F2937",
    accentColor: g = "#DC2626",
    secondaryColor: F = "#059669",
    fullWidth: V = !1,
    animationDirection: q = "left",
    // "left" | "right"
    // Nuevas props para SEO
    carouselId: D = "destinations-carousel",
    baseUrl: A = window.location.origin + window.location.pathname
  } = e, [C, E] = O(0), [se, Ft] = O(!0), [xe, Ce] = O(null), [ne, $e] = O(!1), [Ht, Xe] = O(!1), [Ut, Ke] = O(0), [Ye, Se] = O(null), [W, X] = O(!1);
  let Ee;
  const [ge, re] = O([]), Qe = () => {
    if (!f || r.length === 0) return r;
    const c = Math.max(3, Math.ceil((a + 2) / r.length)), w = [];
    for (let y = 0; y < c; y++)
      w.push(...r.map((K, G) => ({
        ...K,
        uniqueId: `${K.id || G}-${y}`
        // ID único para evitar conflictos
      })));
    return w;
  }, Ze = () => f ? r.length : Math.max(0, r.length - a + 1), Ae = () => {
    if (!se() || i <= 0) return;
    me();
    const c = setInterval(() => {
      (!ne() || !h) && ke();
    }, i);
    Ce(c);
  }, me = () => {
    xe() && (clearInterval(xe()), Ce(null));
  }, ke = () => {
    W() || (f ? (X(!0), E((c) => c + 1), setTimeout(() => {
      if (!W()) return;
      const w = [...ge()], y = w.shift();
      y && (w.push(y), re(w), E(0)), X(!1);
    }, 500)) : E((c) => Math.min(c + 1, r.length - a)));
  }, et = () => {
    if (!W())
      if (f) {
        X(!0);
        const w = [...ge()], y = w.pop();
        y && (w.unshift(y), re(w), E(0)), setTimeout(() => {
          X(!1);
        }, 50);
      } else
        E((c) => Math.max(c - 1, 0));
  }, tt = (c) => {
    E(c);
  };
  ut(() => {
    f && r.length > 0 ? (re(Qe()), E(0)) : re(r), r.length > a && Ae(), Xe(!0), X(!1);
  }), ze(() => {
    me();
  }), Ne(() => {
    ne() && h ? me() : !ne() && se() && !W() && setTimeout(() => {
      !ne() && !W() && Ae();
    }, 100);
  });
  const st = () => {
    Ke((c) => c + 1);
  }, nt = (c) => c.link || c.permalink || `${A}destinations/${c.slug || c.id}`, rt = () => {
    const c = 100 / a;
    return f ? {
      transform: `translateX(${q === "left" ? -C() * c : C() * c}%)`,
      transition: W() ? "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "none"
    } : {
      transform: `translateX(${q === "left" ? -C() * c : C() * c}%)`,
      transition: "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
    };
  }, _e = () => {
    if (r.length === 0) return null;
    const c = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: s || "Destinations Carousel",
      description: o || "Explore amazing travel destinations",
      numberOfItems: r.length,
      itemListElement: r.map((w, y) => ({
        "@type": "ListItem",
        position: y + 1,
        item: {
          "@type": "TouristDestination",
          name: w.name || "",
          description: w.description || "",
          image: w.image || "",
          url: w.link || `${A}#destination-${y}`,
          tourCount: w.tourCount || 0
        }
      }))
    };
    return JSON.stringify(c);
  };
  return (() => {
    var c = Ot(), w = c.firstChild, y = w.firstChild, K = y.firstChild, G = K.firstChild;
    c.addEventListener("mouseleave", () => $e(!1)), c.addEventListener("mouseenter", () => $e(!0)), M(c, "id", D), vt(c, `destinations-carousel-component w-full py-8 md:py-12 relative ${V ? "vw-100" : ""}`), x(c, L(H, {
      get when() {
        return _e();
      },
      get children() {
        var u = At();
        return x(u, _e), u;
      }
    }), w), x(w, L(H, {
      when: s || n || o,
      get children() {
        var u = Dt();
        return x(u, L(H, {
          when: n,
          get children() {
            var m = kt();
            return g != null ? m.style.setProperty("color", g) : m.style.removeProperty("color"), x(m, n), m;
          }
        }), null), x(u, L(H, {
          when: s,
          get children() {
            var m = _t(), p = m.firstChild, k = p.nextSibling, P = k.firstChild;
            return x(p, s), g != null ? k.style.setProperty("background-color", g) : k.style.removeProperty("background-color"), g != null ? P.style.setProperty("background-color", g) : P.style.removeProperty("background-color"), m;
          }
        }), null), x(u, L(H, {
          when: o,
          get children() {
            var m = Tt();
            return x(m, o), m;
          }
        }), null), u;
      }
    }), y), x(y, L(H, {
      get when() {
        return d && r.length > a;
      },
      get children() {
        return [(() => {
          var u = It(), m = u.firstChild;
          return u.$$click = et, g != null ? u.style.setProperty("focus", g) : u.style.removeProperty("focus"), `2px solid ${g}20` != null ? u.style.setProperty("border", `2px solid ${g}20`) : u.style.removeProperty("border"), M(m, "stroke", S), j(() => M(u, "aria-label", t("Previous destinations"))), u;
        })(), (() => {
          var u = Pt(), m = u.firstChild;
          return u.$$click = ke, g != null ? u.style.setProperty("focus", g) : u.style.removeProperty("focus"), `2px solid ${g}20` != null ? u.style.setProperty("border", `2px solid ${g}20`) : u.style.removeProperty("border"), M(m, "stroke", S), j(() => M(u, "aria-label", t("Next destinations"))), u;
        })()];
      }
    }), K);
    var Te = Ee;
    return typeof Te == "function" ? xt(Te, G) : Ee = G, x(G, L(Ie, {
      get each() {
        return ge();
      },
      children: (u, m) => (() => {
        var p = jt(), k = p.firstChild, P = k.firstChild, Y = P.firstChild, Q = P.nextSibling, ot = Q.firstChild;
        return p.addEventListener("mouseleave", () => Se(null)), p.addEventListener("mouseenter", () => Se(m())), `${100 / a}%` != null ? p.style.setProperty("width", `${100 / a}%`) : p.style.removeProperty("width"), `${100 / a}%` != null ? p.style.setProperty("min-width", `${100 / a}%`) : p.style.removeProperty("min-width"), p.style.setProperty("flex-shrink", "0"), x(P, L(H, {
          get when() {
            return u.image;
          },
          get fallback() {
            return (() => {
              var _ = Nt(), I = _.firstChild, R = I.firstChild, oe = R.nextSibling;
              return x(oe, () => u.name || u.title), _;
            })();
          },
          get children() {
            var _ = Mt();
            return _.addEventListener("load", st), j((I) => {
              var R = u.image, oe = u.name || u.title;
              return R !== I.e && M(_, "src", I.e = R), oe !== I.t && M(_, "alt", I.t = oe), I;
            }, {
              e: void 0,
              t: void 0
            }), _;
          }
        }), Y), x(ot, () => u.name || u.title), j((_) => {
          var I = Ye() === m() ? "translateY(-4px)" : "translateY(0)", R = nt(u);
          return I !== _.e && ((_.e = I) != null ? p.style.setProperty("transform", I) : p.style.removeProperty("transform")), R !== _.t && M(Q, "href", _.t = R), _;
        }, {
          e: void 0,
          t: void 0
        }), p;
      })()
    })), x(y, L(H, {
      get when() {
        return l && !f && r.length > a;
      },
      get children() {
        var u = Lt();
        return x(u, L(Ie, {
          get each() {
            return Array(Ze()).fill().map((m, p) => p);
          },
          children: (m) => (() => {
            var p = zt();
            return p.$$click = () => tt(m), g != null ? p.style.setProperty("focus", g) : p.style.removeProperty("focus"), j((k) => {
              var P = C() === m ? g : "#D1D5DB", Y = C() === m ? "scale(1.2)" : "scale(1)", Q = `${t("Go to slide")} ${m + 1}`;
              return P !== k.e && ((k.e = P) != null ? p.style.setProperty("background-color", P) : p.style.removeProperty("background-color")), Y !== k.t && ((k.t = Y) != null ? p.style.setProperty("transform", Y) : p.style.removeProperty("transform")), Q !== k.a && M(p, "aria-label", k.a = Q), k;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), p;
          })()
        })), u;
      }
    }), null), j((u) => {
      var m = {
        backgroundColor: B,
        color: S,
        ...V ? {
          "margin-left": "calc(50% - 50vw)",
          "margin-right": "calc(50% - 50vw)",
          width: "100vw",
          "max-width": "100vw"
        } : {}
      }, p = rt();
      return u.e = Le(c, m, u.e), u.t = Le(G, p, u.t), u;
    }, {
      e: void 0,
      t: void 0
    }), c;
  })();
};
bt(["click"]);
Re("destinations-carousel", Bt);
function he() {
  const e = document.querySelectorAll(
    ".solid-destinations-carousel-container"
  );
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      t.dataset.solidInitializing = "true";
      let s = [];
      try {
        if (t.dataset.destinations && t.dataset.destinations !== "[]") {
          const r = JSON.parse(t.dataset.destinations);
          Array.isArray(r) && (s = r);
        }
      } catch (r) {
        console.warn("Error al parsear datos de destinos:", r);
      }
      const n = {
        title: t.dataset.title || "",
        subtitle: t.dataset.subtitle || "",
        description: t.dataset.description || "",
        destinations: s,
        autoplaySpeed: parseInt(t.dataset.autoplaySpeed) || 3e3,
        showDots: t.dataset.showDots !== "false",
        showArrows: t.dataset.showArrows !== "false",
        pauseOnHover: t.dataset.pauseOnHover !== "false",
        slidesToShow: parseInt(t.dataset.slidesToShow) || 3,
        backgroundColor: t.dataset.backgroundColor || "#F8FAFC",
        textColor: t.dataset.textColor || "#1F2937",
        accentColor: t.dataset.accentColor || "#DC2626",
        secondaryColor: t.dataset.secondaryColor || "#059669",
        fullWidth: t.dataset.fullWidth === "true",
        animationDirection: t.dataset.animationDirection || "left",
        carouselId: t.dataset.carouselId || "destinations-carousel"
      };
      console.log("Inicializando carousel de destinos con propiedades:", n);
      const o = Je.renderComponent(
        "destinations-carousel",
        t,
        n
      );
      t._solidDispose = o, t.dataset.solidInitialized = "true", t.dataset.solidInitializing = "false", console.log(
        "Componente de destinations carousel con Solid.js cargado correctamente"
      );
    } catch (s) {
      console.error(
        "Error al inicializar componente de destinations carousel con Solid.js:",
        s
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de carousel de destinos: ${s.message}</p>
          <button class="mt-2 px-3 py-1 bg-white text-red-800 rounded border border-red-300 text-sm" 
                  onclick="initDestinationsCarousel()">
            Reintentar
          </button>
        </div>
      `, t.dataset.solidInitializing = "false";
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", he) : he();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((s) => {
        if (s.isIntersecting) {
          const n = s.target;
          n.classList.contains("solid-destinations-carousel-container") && n.dataset.intersectOnce === "true" && n.dataset.solidInitialized !== "true" && n.dataset.solidInitializing !== "true" && (console.log("Destinations carousel visible en viewport, inicializando..."), setTimeout(he, 100), n.dataset.intersectOnce = "false"), e.unobserve(s.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: "100px" }
  );
  document.querySelectorAll(".solid-destinations-carousel-container[data-intersect-once='true']").forEach((t) => {
    e.observe(t);
  });
}
window.initDestinationsCarousel = he;
