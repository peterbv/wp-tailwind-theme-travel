const pt = (e, t) => e === t, gt = Symbol("solid-track"), le = {
  equals: pt
};
let Re = Xe;
const U = 1, ie = 2, qe = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var b = null;
let ve = null, mt = null, v = null, C = null, j = null, fe = 0;
function re(e, t) {
  const s = v, n = b, o = e.length === 0, r = t === void 0 ? n : t, i = o ? qe : {
    owned: null,
    cleanups: null,
    context: r ? r.context : null,
    owner: r
  }, l = o ? e : () => e(() => z(() => Y(i)));
  b = i, v = null;
  try {
    return Z(l, !0);
  } finally {
    v = s, b = n;
  }
}
function D(e, t) {
  t = t ? Object.assign({}, le, t) : le;
  const s = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, n = (o) => (typeof o == "function" && (o = o(s.value)), Je(s, o));
  return [Ge.bind(s), n];
}
function H(e, t, s) {
  const n = Se(e, t, !1, U);
  Q(n);
}
function We(e, t, s) {
  Re = bt;
  const n = Se(e, t, !1, U);
  n.user = !0, j ? j.push(n) : Q(n);
}
function oe(e, t, s) {
  s = s ? Object.assign({}, le, s) : le;
  const n = Se(e, t, !0, 0);
  return n.observers = null, n.observerSlots = null, n.comparator = s.equals || void 0, Q(n), Ge.bind(n);
}
function z(e) {
  if (v === null) return e();
  const t = v;
  v = null;
  try {
    return e();
  } finally {
    v = t;
  }
}
function wt(e) {
  We(() => z(e));
}
function be(e) {
  return b === null || (b.cleanups === null ? b.cleanups = [e] : b.cleanups.push(e)), e;
}
function Ge() {
  if (this.sources && this.state)
    if (this.state === U) Q(this);
    else {
      const e = C;
      C = null, Z(() => ue(this), !1), C = e;
    }
  if (v) {
    const e = this.observers ? this.observers.length : 0;
    v.sources ? (v.sources.push(this), v.sourceSlots.push(e)) : (v.sources = [this], v.sourceSlots = [e]), this.observers ? (this.observers.push(v), this.observerSlots.push(v.sources.length - 1)) : (this.observers = [v], this.observerSlots = [v.sources.length - 1]);
  }
  return this.value;
}
function Je(e, t, s) {
  let n = e.value;
  return (!e.comparator || !e.comparator(n, t)) && (e.value = t, e.observers && e.observers.length && Z(() => {
    for (let o = 0; o < e.observers.length; o += 1) {
      const r = e.observers[o], i = ve && ve.running;
      i && ve.disposed.has(r), (i ? !r.tState : !r.state) && (r.pure ? C.push(r) : j.push(r), r.observers && Ke(r)), i || (r.state = U);
    }
    if (C.length > 1e6)
      throw C = [], new Error();
  }, !1)), t;
}
function Q(e) {
  if (!e.fn) return;
  Y(e);
  const t = fe;
  yt(
    e,
    e.value,
    t
  );
}
function yt(e, t, s) {
  let n;
  const o = b, r = v;
  v = b = e;
  try {
    n = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = U, e.owned && e.owned.forEach(Y), e.owned = null), e.updatedAt = s + 1, Ye(i);
  } finally {
    v = r, b = o;
  }
  (!e.updatedAt || e.updatedAt <= s) && (e.updatedAt != null && "observers" in e ? Je(e, n) : e.value = n, e.updatedAt = s);
}
function Se(e, t, s, n = U, o) {
  const r = {
    fn: e,
    state: n,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: b,
    context: b ? b.context : null,
    pure: s
  };
  return b === null || b !== qe && (b.owned ? b.owned.push(r) : b.owned = [r]), r;
}
function ae(e) {
  if (e.state === 0) return;
  if (e.state === ie) return ue(e);
  if (e.suspense && z(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < fe); )
    e.state && t.push(e);
  for (let s = t.length - 1; s >= 0; s--)
    if (e = t[s], e.state === U)
      Q(e);
    else if (e.state === ie) {
      const n = C;
      C = null, Z(() => ue(e, t[0]), !1), C = n;
    }
}
function Z(e, t) {
  if (C) return e();
  let s = !1;
  t || (C = []), j ? s = !0 : j = [], fe++;
  try {
    const n = e();
    return vt(s), n;
  } catch (n) {
    s || (j = null), C = null, Ye(n);
  }
}
function vt(e) {
  if (C && (Xe(C), C = null), e) return;
  const t = j;
  j = null, t.length && Z(() => Re(t), !1);
}
function Xe(e) {
  for (let t = 0; t < e.length; t++) ae(e[t]);
}
function bt(e) {
  let t, s = 0;
  for (t = 0; t < e.length; t++) {
    const n = e[t];
    n.user ? e[s++] = n : ae(n);
  }
  for (t = 0; t < s; t++) ae(e[t]);
}
function ue(e, t) {
  e.state = 0;
  for (let s = 0; s < e.sources.length; s += 1) {
    const n = e.sources[s];
    if (n.sources) {
      const o = n.state;
      o === U ? n !== t && (!n.updatedAt || n.updatedAt < fe) && ae(n) : o === ie && ue(n, t);
    }
  }
}
function Ke(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const s = e.observers[t];
    s.state || (s.state = ie, s.pure ? C.push(s) : j.push(s), s.observers && Ke(s));
  }
}
function Y(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const s = e.sources.pop(), n = e.sourceSlots.pop(), o = s.observers;
      if (o && o.length) {
        const r = o.pop(), i = s.observerSlots.pop();
        n < o.length && (r.sourceSlots[i] = n, o[n] = r, s.observerSlots[n] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) Y(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) Y(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function xt(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function Ye(e, t = b) {
  throw xt(e);
}
const Ct = Symbol("fallback");
function Be(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function St(e, t, s = {}) {
  let n = [], o = [], r = [], i = 0, l = t.length > 1 ? [] : null;
  return be(() => Be(r)), () => {
    let d = e() || [], h = d.length, f, a;
    return d[gt], z(() => {
      let A, y, F, V, R, _, k, x, S;
      if (h === 0)
        i !== 0 && (Be(r), r = [], n = [], o = [], i = 0, l && (l = [])), s.fallback && (n = [Ct], o[0] = re((ee) => (r[0] = ee, s.fallback())), i = 1);
      else if (i === 0) {
        for (o = new Array(h), a = 0; a < h; a++)
          n[a] = d[a], o[a] = re(B);
        i = h;
      } else {
        for (F = new Array(h), V = new Array(h), l && (R = new Array(h)), _ = 0, k = Math.min(i, h); _ < k && n[_] === d[_]; _++) ;
        for (k = i - 1, x = h - 1; k >= _ && x >= _ && n[k] === d[x]; k--, x--)
          F[x] = o[k], V[x] = r[k], l && (R[x] = l[k]);
        for (A = /* @__PURE__ */ new Map(), y = new Array(x + 1), a = x; a >= _; a--)
          S = d[a], f = A.get(S), y[a] = f === void 0 ? -1 : f, A.set(S, a);
        for (f = _; f <= k; f++)
          S = n[f], a = A.get(S), a !== void 0 && a !== -1 ? (F[a] = o[f], V[a] = r[f], l && (R[a] = l[f]), a = y[a], A.set(S, a)) : r[f]();
        for (a = _; a < h; a++)
          a in F ? (o[a] = F[a], r[a] = V[a], l && (l[a] = R[a], l[a](a))) : o[a] = re(B);
        o = o.slice(0, i = h), n = d.slice(0);
      }
      return o;
    });
    function B(A) {
      if (r[a] = A, l) {
        const [y, F] = D(a);
        return l[a] = F, t(d[a], y);
      }
      return t(d[a]);
    }
  };
}
function N(e, t) {
  return z(() => e(t || {}));
}
const $t = (e) => `Stale read from <${e}>.`;
function Fe(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return oe(St(() => e.each, e.children, t || void 0));
}
function q(e) {
  const t = e.keyed, s = oe(() => e.when, void 0, void 0), n = t ? s : oe(s, void 0, {
    equals: (o, r) => !o == !r
  });
  return oe(
    () => {
      const o = n();
      if (o) {
        const r = e.children;
        return typeof r == "function" && r.length > 0 ? z(
          () => r(
            t ? o : () => {
              if (!z(n)) throw $t("Show");
              return s();
            }
          )
        ) : r;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function Et(e, t, s) {
  let n = s.length, o = t.length, r = n, i = 0, l = 0, d = t[o - 1].nextSibling, h = null;
  for (; i < o || l < r; ) {
    if (t[i] === s[l]) {
      i++, l++;
      continue;
    }
    for (; t[o - 1] === s[r - 1]; )
      o--, r--;
    if (o === i) {
      const f = r < n ? l ? s[l - 1].nextSibling : s[r - l] : d;
      for (; l < r; ) e.insertBefore(s[l++], f);
    } else if (r === l)
      for (; i < o; )
        (!h || !h.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === s[r - 1] && s[l] === t[o - 1]) {
      const f = t[--o].nextSibling;
      e.insertBefore(s[l++], t[i++].nextSibling), e.insertBefore(s[--r], f), t[o] = s[r];
    } else {
      if (!h) {
        h = /* @__PURE__ */ new Map();
        let a = l;
        for (; a < r; ) h.set(s[a], a++);
      }
      const f = h.get(t[i]);
      if (f != null)
        if (l < f && f < r) {
          let a = i, B = 1, A;
          for (; ++a < o && a < r && !((A = h.get(t[a])) == null || A !== f + B); )
            B++;
          if (B > f - l) {
            const y = t[i];
            for (; l < f; ) e.insertBefore(s[l++], y);
          } else e.replaceChild(s[l++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const He = "_$DX_DELEGATE";
function At(e, t, s, n = {}) {
  let o;
  return re((r) => {
    o = r, t === document ? e() : E(t, e(), t.firstChild ? null : void 0, s);
  }, n.owner), () => {
    o(), t.textContent = "";
  };
}
function I(e, t, s, n) {
  let o;
  const r = () => {
    const l = n ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return l.innerHTML = e, s ? l.content.firstChild.firstChild : n ? l.firstChild : l.content.firstChild;
  }, i = t ? () => z(() => document.importNode(o || (o = r()), !0)) : () => (o || (o = r())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function kt(e, t = window.document) {
  const s = t[He] || (t[He] = /* @__PURE__ */ new Set());
  for (let n = 0, o = e.length; n < o; n++) {
    const r = e[n];
    s.has(r) || (s.add(r), t.addEventListener(r, Dt));
  }
}
function P(e, t, s) {
  s == null ? e.removeAttribute(t) : e.setAttribute(t, s);
}
function Tt(e, t) {
  t == null ? e.removeAttribute("class") : e.className = t;
}
function Ue(e, t, s) {
  if (!t) return s ? P(e, "style") : t;
  const n = e.style;
  if (typeof t == "string") return n.cssText = t;
  typeof s == "string" && (n.cssText = s = void 0), s || (s = {}), t || (t = {});
  let o, r;
  for (r in s)
    t[r] == null && n.removeProperty(r), delete s[r];
  for (r in t)
    o = t[r], o !== s[r] && (n.setProperty(r, o), s[r] = o);
  return s;
}
function _t(e, t, s) {
  return z(() => e(t, s));
}
function E(e, t, s, n) {
  if (s !== void 0 && !n && (n = []), typeof t != "function") return ce(e, t, n, s);
  H((o) => ce(e, t(), o, s), n);
}
function Dt(e) {
  let t = e.target;
  const s = `$$${e.type}`, n = e.target, o = e.currentTarget, r = (d) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: d
  }), i = () => {
    const d = t[s];
    if (d && !t.disabled) {
      const h = t[`${s}Data`];
      if (h !== void 0 ? d.call(t, h, e) : d.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && r(t.host), !0;
  }, l = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const d = e.composedPath();
    r(d[0]);
    for (let h = 0; h < d.length - 2 && (t = d[h], !!i()); h++) {
      if (t._$host) {
        t = t._$host, l();
        break;
      }
      if (t.parentNode === o)
        break;
    }
  } else l();
  r(n);
}
function ce(e, t, s, n, o) {
  for (; typeof s == "function"; ) s = s();
  if (t === s) return s;
  const r = typeof t, i = n !== void 0;
  if (e = i && s[0] && s[0].parentNode || e, r === "string" || r === "number") {
    if (r === "number" && (t = t.toString(), t === s))
      return s;
    if (i) {
      let l = s[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), s = J(e, s, n, l);
    } else
      s !== "" && typeof s == "string" ? s = e.firstChild.data = t : s = e.textContent = t;
  } else if (t == null || r === "boolean")
    s = J(e, s, n);
  else {
    if (r === "function")
      return H(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        s = ce(e, l, s, n);
      }), () => s;
    if (Array.isArray(t)) {
      const l = [], d = s && Array.isArray(s);
      if (xe(l, t, s, o))
        return H(() => s = ce(e, l, s, n, !0)), () => s;
      if (l.length === 0) {
        if (s = J(e, s, n), i) return s;
      } else d ? s.length === 0 ? Ve(e, l, n) : Et(e, s, l) : (s && J(e), Ve(e, l));
      s = l;
    } else if (t.nodeType) {
      if (Array.isArray(s)) {
        if (i) return s = J(e, s, n, t);
        J(e, s, null, t);
      } else s == null || s === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      s = t;
    }
  }
  return s;
}
function xe(e, t, s, n) {
  let o = !1;
  for (let r = 0, i = t.length; r < i; r++) {
    let l = t[r], d = s && s[e.length], h;
    if (!(l == null || l === !0 || l === !1)) if ((h = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      o = xe(e, l, d) || o;
    else if (h === "function")
      if (n) {
        for (; typeof l == "function"; ) l = l();
        o = xe(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(d) ? d : [d]
        ) || o;
      } else
        e.push(l), o = !0;
    else {
      const f = String(l);
      d && d.nodeType === 3 && d.data === f ? e.push(d) : e.push(document.createTextNode(f));
    }
  }
  return o;
}
function Ve(e, t, s = null) {
  for (let n = 0, o = t.length; n < o; n++) e.insertBefore(t[n], s);
}
function J(e, t, s, n) {
  if (s === void 0) return e.textContent = "";
  const o = n || document.createTextNode("");
  if (t.length) {
    let r = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const l = t[i];
      if (o !== l) {
        const d = l.parentNode === e;
        !r && !i ? d ? e.replaceChild(o, l) : e.insertBefore(o, s) : d && l.remove();
      } else r = !0;
    }
  } else e.insertBefore(o, s);
  return [o];
}
const It = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, Pt = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const s = It();
  return s[e] ? s[e] : e;
}, Qe = {}, Lt = () => document.readyState !== "loading";
function Ze(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  Qe[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function et(e) {
  return Qe[e] || null;
}
function tt(e, t, s = {}) {
  const n = et(e);
  if (!n)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const o = At(() => n(s), t);
    return t.dataset.solidInitialized = "true", o;
  } catch (o) {
    return console.error(`Error al renderizar el componente '${e}':`, o), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${o.message}</p>
      </div>
    `, null;
  }
}
function Ce() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const s = t.dataset.solidComponent;
    if (!s || t.dataset.solidInitialized === "true") return;
    let n = {};
    try {
      t.dataset.props && (n = JSON.parse(t.dataset.props));
    } catch (o) {
      console.warn(
        `Error al parsear propiedades para ${s}:`,
        o
      );
    }
    tt(s, t, n);
  });
}
Lt() ? Ce() : document.addEventListener("DOMContentLoaded", Ce);
const st = {
  registerComponent: Ze,
  getComponent: et,
  renderComponent: tt,
  initComponents: Ce
};
window.solidCore = st;
var Ot = /* @__PURE__ */ I("<script type=application/ld+json>"), Mt = /* @__PURE__ */ I('<p class="block text-base italic font-medium mb-1">'), Nt = /* @__PURE__ */ I('<div class="relative inline-block"><h2 class="text-2xl md:text-3xl font-bold mb-2"></h2><div class="absolute -bottom-1 left-1/2 w-16 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), jt = /* @__PURE__ */ I('<p class="text-gray-600 mt-3 max-w-2xl mx-auto">'), zt = /* @__PURE__ */ I('<header class="text-center mb-8 relative">'), Bt = /* @__PURE__ */ I('<button type=button class="carousel-prev absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4 sm:w-5 sm:h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7">'), Ft = /* @__PURE__ */ I('<button type=button class="carousel-next absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4 sm:w-5 sm:h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), Ht = /* @__PURE__ */ I('<div class="carousel-dots flex justify-center space-x-2 mt-6">'), Ut = /* @__PURE__ */ I('<section><div class="container mx-auto px-4 relative overflow-y-visible"><div class="destinations-carousel-wrapper relative pt-3 pb-6"><div class="carousel-track overflow-x-hidden overflow-y-visible mx-6 sm:mx-8 md:mx-12 py-3"><div class="carousel-slides flex transition-transform duration-600 ease-in-out">'), Vt = /* @__PURE__ */ I('<article class="destination-card flex-shrink-0 px-2 sm:px-3 transition-all duration-300"><div class="destination-card-inner relative overflow-hidden rounded-2xl shadow-lg transition-all duration-300 hover:shadow-xl h-64 sm:h-72 md:h-80 lg:h-80 cursor-pointer group"><div class="destination-image absolute inset-0 overflow-hidden"><img class="w-full h-full object-cover transition-transform duration-500"loading=lazy></div><div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div><a class="absolute inset-0 flex items-center justify-center text-center text-white z-10 group-hover:bg-black/10 transition-colors duration-300 p-4"><h3 class="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight drop-shadow-lg leading-tight">', !0, !1, !1), Rt = /* @__PURE__ */ I('<button type=button class="carousel-dot w-3 h-3 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2">');
const qt = (e) => {
  const t = (u, m = "wptbt-destinations-carousel") => {
    const p = window.wptbtI18n_destinations_carousel || {};
    return p[u] ? p[u] : Pt(u, m);
  }, {
    title: s = "",
    subtitle: n = "",
    description: o = "",
    destinations: r = [],
    autoplaySpeed: i = 3e3,
    // Velocidad del autoplay en ms
    showDots: l = !0,
    showArrows: d = !0,
    pauseOnHover: h = !0,
    infinite: f = !0,
    slidesToShow: a = 3,
    // Número de destinos visibles a la vez
    backgroundColor: B = "#F8FAFC",
    textColor: A = "#1F2937",
    accentColor: y = "#DC2626",
    secondaryColor: F = "#059669",
    fullWidth: V = !1,
    animationDirection: R = "left",
    // "left" | "right"
    // Nuevas props para SEO
    carouselId: _ = "destinations-carousel",
    baseUrl: k = window.location.origin + window.location.pathname
  } = e, [x, S] = D(0), [ee, Wt] = D(!0), [$e, Ee] = D(null), [te, Ae] = D(!1), [Gt, nt] = D(!1), [Jt, rt] = D(0), [ke, Te] = D(null), [W, X] = D(!1), [L, ot] = D(a);
  let _e;
  const [he, se] = D([]), lt = () => {
    if (!f || r.length === 0) return r;
    const u = Math.max(3, Math.ceil((a + 2) / r.length)), m = [];
    for (let p = 0; p < u; p++)
      m.push(...r.map((K, G) => ({
        ...K,
        uniqueId: `${K.id || G}-${p}`
        // ID único para evitar conflictos
      })));
    return m;
  }, it = () => f ? r.length : Math.max(0, r.length - L() + 1), De = () => {
    if (!ee() || i <= 0) return;
    pe();
    const u = setInterval(() => {
      (!te() || !h) && Ie();
    }, i);
    Ee(u);
  }, pe = () => {
    $e() && (clearInterval($e()), Ee(null));
  }, Ie = () => {
    W() || (f ? (X(!0), S((u) => u + 1), setTimeout(() => {
      if (!W()) return;
      const m = [...he()], p = m.shift();
      p && (m.push(p), se(m), S(0)), X(!1);
    }, 500)) : S((u) => Math.min(u + 1, r.length - L())));
  }, at = () => {
    if (!W())
      if (f) {
        X(!0);
        const m = [...he()], p = m.pop();
        p && (m.unshift(p), se(m), S(0)), setTimeout(() => {
          X(!1);
        }, 50);
      } else
        S((u) => Math.max(u - 1, 0));
  }, ut = (u) => {
    S(u);
  };
  wt(() => {
    Pe();
    const u = () => Pe();
    window.addEventListener("resize", u), f && r.length > 0 ? (se(lt()), S(0)) : se(r), r.length > L() && De(), nt(!0), X(!1), be(() => {
      window.removeEventListener("resize", u);
    });
  }), be(() => {
    pe();
  }), We(() => {
    te() && h ? pe() : !te() && ee() && !W() && setTimeout(() => {
      !te() && !W() && De();
    }, 100);
  });
  const ct = () => {
    rt((u) => u + 1);
  }, dt = (u) => u.link || u.permalink || `${k}destinations/${u.slug || u.id}`, ft = () => {
    const u = 100 / L();
    return f ? {
      transform: `translateX(${R === "left" ? -x() * u : x() * u}%)`,
      transition: W() ? "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "none"
    } : {
      transform: `translateX(${R === "left" ? -x() * u : x() * u}%)`,
      transition: "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
    };
  }, Pe = () => {
    const u = window.innerWidth, m = a;
    let p;
    u < 768 ? p = Math.min(m, 1) : u < 1024 ? p = Math.min(m, 2) : p = m, p !== L() && (ot(p), x() > Math.max(0, r.length - p) && S(Math.max(0, r.length - p)));
  }, Le = () => {
    if (r.length === 0) return null;
    const u = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: s || "Destinations Carousel",
      description: o || "Explore amazing travel destinations",
      numberOfItems: r.length,
      itemListElement: r.map((m, p) => ({
        "@type": "ListItem",
        position: p + 1,
        item: {
          "@type": "TouristDestination",
          name: m.name || "",
          description: m.description || "",
          image: m.image || "",
          url: m.link || `${k}#destination-${p}`,
          tourCount: m.tourCount || 0
        }
      }))
    };
    return JSON.stringify(u);
  };
  return (() => {
    var u = Ut(), m = u.firstChild, p = m.firstChild, K = p.firstChild, G = K.firstChild;
    u.addEventListener("mouseleave", () => Ae(!1)), u.addEventListener("mouseenter", () => Ae(!0)), P(u, "id", _), Tt(u, `destinations-carousel-component w-full py-8 md:py-12 relative ${V ? "vw-100" : ""}`), E(u, N(q, {
      get when() {
        return Le();
      },
      get children() {
        var c = Ot();
        return E(c, Le), c;
      }
    }), m), E(m, N(q, {
      when: s || n || o,
      get children() {
        var c = zt();
        return E(c, N(q, {
          when: n,
          get children() {
            var w = Mt();
            return y != null ? w.style.setProperty("color", y) : w.style.removeProperty("color"), E(w, n), w;
          }
        }), null), E(c, N(q, {
          when: s,
          get children() {
            var w = Nt(), g = w.firstChild, T = g.nextSibling, O = T.firstChild;
            return E(g, s), y != null ? T.style.setProperty("background-color", y) : T.style.removeProperty("background-color"), y != null ? O.style.setProperty("background-color", y) : O.style.removeProperty("background-color"), w;
          }
        }), null), E(c, N(q, {
          when: o,
          get children() {
            var w = jt();
            return E(w, o), w;
          }
        }), null), c;
      }
    }), p), E(p, N(q, {
      get when() {
        return d && r.length > L();
      },
      get children() {
        return [(() => {
          var c = Bt(), w = c.firstChild;
          return c.$$click = at, y != null ? c.style.setProperty("focus", y) : c.style.removeProperty("focus"), `2px solid ${y}20` != null ? c.style.setProperty("border", `2px solid ${y}20`) : c.style.removeProperty("border"), P(w, "stroke", A), H(() => P(c, "aria-label", t("Previous destinations"))), c;
        })(), (() => {
          var c = Ft(), w = c.firstChild;
          return c.$$click = Ie, y != null ? c.style.setProperty("focus", y) : c.style.removeProperty("focus"), `2px solid ${y}20` != null ? c.style.setProperty("border", `2px solid ${y}20`) : c.style.removeProperty("border"), P(w, "stroke", A), H(() => P(c, "aria-label", t("Next destinations"))), c;
        })()];
      }
    }), K);
    var Oe = _e;
    return typeof Oe == "function" ? _t(Oe, G) : _e = G, E(G, N(Fe, {
      get each() {
        return he();
      },
      children: (c, w) => (() => {
        var g = Vt(), T = g.firstChild, O = T.firstChild, M = O.firstChild, ne = O.nextSibling, Me = ne.nextSibling, ht = Me.firstChild;
        return g.addEventListener("mouseleave", () => Te(null)), g.addEventListener("mouseenter", () => Te(w())), g.style.setProperty("flex-shrink", "0"), M.addEventListener("load", ct), E(ht, () => c.name || c.title), H(($) => {
          var ge = `${100 / L()}%`, me = `${100 / L()}%`, we = ke() === w() ? "translateY(-4px)" : "translateY(0)", Ne = c.image || c.featured_image, je = c.name || c.title, ye = ke() === w() ? "scale(1.05)" : "scale(1)", ze = dt(c);
          return ge !== $.e && (($.e = ge) != null ? g.style.setProperty("width", ge) : g.style.removeProperty("width")), me !== $.t && (($.t = me) != null ? g.style.setProperty("min-width", me) : g.style.removeProperty("min-width")), we !== $.a && (($.a = we) != null ? g.style.setProperty("transform", we) : g.style.removeProperty("transform")), Ne !== $.o && P(M, "src", $.o = Ne), je !== $.i && P(M, "alt", $.i = je), ye !== $.n && (($.n = ye) != null ? M.style.setProperty("transform", ye) : M.style.removeProperty("transform")), ze !== $.s && P(Me, "href", $.s = ze), $;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0,
          s: void 0
        }), g;
      })()
    })), E(p, N(q, {
      get when() {
        return l && !f && r.length > L();
      },
      get children() {
        var c = Ht();
        return E(c, N(Fe, {
          get each() {
            return Array(it()).fill().map((w, g) => g);
          },
          children: (w) => (() => {
            var g = Rt();
            return g.$$click = () => ut(w), y != null ? g.style.setProperty("focus", y) : g.style.removeProperty("focus"), H((T) => {
              var O = x() === w ? y : "#D1D5DB", M = x() === w ? "scale(1.2)" : "scale(1)", ne = `${t("Go to slide")} ${w + 1}`;
              return O !== T.e && ((T.e = O) != null ? g.style.setProperty("background-color", O) : g.style.removeProperty("background-color")), M !== T.t && ((T.t = M) != null ? g.style.setProperty("transform", M) : g.style.removeProperty("transform")), ne !== T.a && P(g, "aria-label", T.a = ne), T;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), g;
          })()
        })), c;
      }
    }), null), H((c) => {
      var w = {
        backgroundColor: B,
        color: A,
        ...V ? {
          "margin-left": "calc(50% - 50vw)",
          "margin-right": "calc(50% - 50vw)",
          width: "100vw",
          "max-width": "100vw"
        } : {}
      }, g = ft();
      return c.e = Ue(u, w, c.e), c.t = Ue(G, g, c.t), c;
    }, {
      e: void 0,
      t: void 0
    }), u;
  })();
};
kt(["click"]);
Ze("destinations-carousel", qt);
function de() {
  const e = document.querySelectorAll(
    ".solid-destinations-carousel-container"
  );
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      t.dataset.solidInitializing = "true";
      let s = [];
      try {
        if (t.dataset.destinations && t.dataset.destinations !== "[]") {
          const r = JSON.parse(t.dataset.destinations);
          Array.isArray(r) && (s = r);
        }
      } catch (r) {
        console.warn("Error al parsear datos de destinos:", r);
      }
      const n = {
        title: t.dataset.title || "",
        subtitle: t.dataset.subtitle || "",
        description: t.dataset.description || "",
        destinations: s,
        autoplaySpeed: parseInt(t.dataset.autoplaySpeed) || 3e3,
        showDots: t.dataset.showDots !== "false",
        showArrows: t.dataset.showArrows !== "false",
        pauseOnHover: t.dataset.pauseOnHover !== "false",
        slidesToShow: parseInt(t.dataset.slidesToShow) || 3,
        backgroundColor: t.dataset.backgroundColor || "#F8FAFC",
        textColor: t.dataset.textColor || "#1F2937",
        accentColor: t.dataset.accentColor || "#DC2626",
        secondaryColor: t.dataset.secondaryColor || "#059669",
        fullWidth: t.dataset.fullWidth === "true",
        animationDirection: t.dataset.animationDirection || "left",
        carouselId: t.dataset.carouselId || "destinations-carousel"
      };
      console.log("Inicializando carousel de destinos con propiedades:", n);
      const o = st.renderComponent(
        "destinations-carousel",
        t,
        n
      );
      t._solidDispose = o, t.dataset.solidInitialized = "true", t.dataset.solidInitializing = "false", console.log(
        "Componente de destinations carousel con Solid.js cargado correctamente"
      );
    } catch (s) {
      console.error(
        "Error al inicializar componente de destinations carousel con Solid.js:",
        s
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de carousel de destinos: ${s.message}</p>
          <button class="mt-2 px-3 py-1 bg-white text-red-800 rounded border border-red-300 text-sm" 
                  onclick="initDestinationsCarousel()">
            Reintentar
          </button>
        </div>
      `, t.dataset.solidInitializing = "false";
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", de) : de();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((s) => {
        if (s.isIntersecting) {
          const n = s.target;
          n.classList.contains("solid-destinations-carousel-container") && n.dataset.intersectOnce === "true" && n.dataset.solidInitialized !== "true" && n.dataset.solidInitializing !== "true" && (console.log("Destinations carousel visible en viewport, inicializando..."), setTimeout(de, 100), n.dataset.intersectOnce = "false"), e.unobserve(s.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: "100px" }
  );
  document.querySelectorAll(".solid-destinations-carousel-container[data-intersect-once='true']").forEach((t) => {
    e.observe(t);
  });
}
window.initDestinationsCarousel = de;
