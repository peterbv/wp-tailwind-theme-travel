const xt = (e, t) => e === t, Pt = Symbol("solid-track"), le = {
  equals: xt
};
let ot = at;
const I = 1, ne = 2, lt = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var w = null;
let Oe = null, St = null, y = null, m = null, O = null, ue = 0;
function re(e, t) {
  const r = y, s = w, o = e.length === 0, n = t === void 0 ? s : t, i = o ? lt : {
    owned: null,
    cleanups: null,
    context: n ? n.context : null,
    owner: n
  }, l = o ? e : () => e(() => M(() => W(i)));
  w = i, y = null;
  try {
    return H(l, !0);
  } finally {
    y = r, w = s;
  }
}
function se(e, t) {
  t = t ? Object.assign({}, le, t) : le;
  const r = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, s = (o) => (typeof o == "function" && (o = o(r.value)), it(r, o));
  return [nt.bind(r), s];
}
function R(e, t, r) {
  const s = Ne(e, t, !1, I);
  V(s);
}
function Et(e, t, r) {
  ot = Tt;
  const s = Ne(e, t, !1, I);
  s.user = !0, O ? O.push(s) : V(s);
}
function oe(e, t, r) {
  r = r ? Object.assign({}, le, r) : le;
  const s = Ne(e, t, !0, 0);
  return s.observers = null, s.observerSlots = null, s.comparator = r.equals || void 0, V(s), nt.bind(s);
}
function M(e) {
  if (y === null) return e();
  const t = y;
  y = null;
  try {
    return e();
  } finally {
    y = t;
  }
}
function Ze(e) {
  Et(() => M(e));
}
function At(e) {
  return w === null || (w.cleanups === null ? w.cleanups = [e] : w.cleanups.push(e)), e;
}
function nt() {
  if (this.sources && this.state)
    if (this.state === I) V(this);
    else {
      const e = m;
      m = null, H(() => ae(this), !1), m = e;
    }
  if (y) {
    const e = this.observers ? this.observers.length : 0;
    y.sources ? (y.sources.push(this), y.sourceSlots.push(e)) : (y.sources = [this], y.sourceSlots = [e]), this.observers ? (this.observers.push(y), this.observerSlots.push(y.sources.length - 1)) : (this.observers = [y], this.observerSlots = [y.sources.length - 1]);
  }
  return this.value;
}
function it(e, t, r) {
  let s = e.value;
  return (!e.comparator || !e.comparator(s, t)) && (e.value = t, e.observers && e.observers.length && H(() => {
    for (let o = 0; o < e.observers.length; o += 1) {
      const n = e.observers[o], i = Oe && Oe.running;
      i && Oe.disposed.has(n), (i ? !n.tState : !n.state) && (n.pure ? m.push(n) : O.push(n), n.observers && ct(n)), i || (n.state = I);
    }
    if (m.length > 1e6)
      throw m = [], new Error();
  }, !1)), t;
}
function V(e) {
  if (!e.fn) return;
  W(e);
  const t = ue;
  $t(
    e,
    e.value,
    t
  );
}
function $t(e, t, r) {
  let s;
  const o = w, n = y;
  y = w = e;
  try {
    s = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = I, e.owned && e.owned.forEach(W), e.owned = null), e.updatedAt = r + 1, ut(i);
  } finally {
    y = n, w = o;
  }
  (!e.updatedAt || e.updatedAt <= r) && (e.updatedAt != null && "observers" in e ? it(e, s) : e.value = s, e.updatedAt = r);
}
function Ne(e, t, r, s = I, o) {
  const n = {
    fn: e,
    state: s,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: w,
    context: w ? w.context : null,
    pure: r
  };
  return w === null || w !== lt && (w.owned ? w.owned.push(n) : w.owned = [n]), n;
}
function ie(e) {
  if (e.state === 0) return;
  if (e.state === ne) return ae(e);
  if (e.suspense && M(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < ue); )
    e.state && t.push(e);
  for (let r = t.length - 1; r >= 0; r--)
    if (e = t[r], e.state === I)
      V(e);
    else if (e.state === ne) {
      const s = m;
      m = null, H(() => ae(e, t[0]), !1), m = s;
    }
}
function H(e, t) {
  if (m) return e();
  let r = !1;
  t || (m = []), O ? r = !0 : O = [], ue++;
  try {
    const s = e();
    return kt(r), s;
  } catch (s) {
    r || (O = null), m = null, ut(s);
  }
}
function kt(e) {
  if (m && (at(m), m = null), e) return;
  const t = O;
  O = null, t.length && H(() => ot(t), !1);
}
function at(e) {
  for (let t = 0; t < e.length; t++) ie(e[t]);
}
function Tt(e) {
  let t, r = 0;
  for (t = 0; t < e.length; t++) {
    const s = e[t];
    s.user ? e[r++] = s : ie(s);
  }
  for (t = 0; t < r; t++) ie(e[t]);
}
function ae(e, t) {
  e.state = 0;
  for (let r = 0; r < e.sources.length; r += 1) {
    const s = e.sources[r];
    if (s.sources) {
      const o = s.state;
      o === I ? s !== t && (!s.updatedAt || s.updatedAt < ue) && ie(s) : o === ne && ae(s, t);
    }
  }
}
function ct(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const r = e.observers[t];
    r.state || (r.state = ne, r.pure ? m.push(r) : O.push(r), r.observers && ct(r));
  }
}
function W(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const r = e.sources.pop(), s = e.sourceSlots.pop(), o = r.observers;
      if (o && o.length) {
        const n = o.pop(), i = r.observerSlots.pop();
        s < o.length && (n.sourceSlots[i] = s, o[s] = n, r.observerSlots[s] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) W(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) W(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function Lt(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function ut(e, t = w) {
  throw Lt(e);
}
const _t = Symbol("fallback");
function et(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function Ot(e, t, r = {}) {
  let s = [], o = [], n = [], i = 0, l = t.length > 1 ? [] : null;
  return At(() => et(n)), () => {
    let c = e() || [], d = c.length, p, a;
    return c[Pt], M(() => {
      let x, k, T, D, N, P, b, C, L;
      if (d === 0)
        i !== 0 && (et(n), n = [], s = [], o = [], i = 0, l && (l = [])), r.fallback && (s = [_t], o[0] = re((G) => (n[0] = G, r.fallback())), i = 1);
      else if (i === 0) {
        for (o = new Array(d), a = 0; a < d; a++)
          s[a] = c[a], o[a] = re(B);
        i = d;
      } else {
        for (T = new Array(d), D = new Array(d), l && (N = new Array(d)), P = 0, b = Math.min(i, d); P < b && s[P] === c[P]; P++) ;
        for (b = i - 1, C = d - 1; b >= P && C >= P && s[b] === c[C]; b--, C--)
          T[C] = o[b], D[C] = n[b], l && (N[C] = l[b]);
        for (x = /* @__PURE__ */ new Map(), k = new Array(C + 1), a = C; a >= P; a--)
          L = c[a], p = x.get(L), k[a] = p === void 0 ? -1 : p, x.set(L, a);
        for (p = P; p <= b; p++)
          L = s[p], a = x.get(L), a !== void 0 && a !== -1 ? (T[a] = o[p], D[a] = n[p], l && (N[a] = l[p]), a = k[a], x.set(L, a)) : n[p]();
        for (a = P; a < d; a++)
          a in T ? (o[a] = T[a], n[a] = D[a], l && (l[a] = N[a], l[a](a))) : o[a] = re(B);
        o = o.slice(0, i = d), s = c.slice(0);
      }
      return o;
    });
    function B(x) {
      if (n[a] = x, l) {
        const [k, T] = se(a);
        return l[a] = T, t(c[a], k);
      }
      return t(c[a]);
    }
  };
}
function ee(e, t) {
  return M(() => e(t || {}));
}
const Bt = (e) => `Stale read from <${e}>.`;
function qt(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return oe(Ot(() => e.each, e.children, t || void 0));
}
function Be(e) {
  const t = e.keyed, r = oe(() => e.when, void 0, void 0), s = t ? r : oe(r, void 0, {
    equals: (o, n) => !o == !n
  });
  return oe(
    () => {
      const o = s();
      if (o) {
        const n = e.children;
        return typeof n == "function" && n.length > 0 ? M(
          () => n(
            t ? o : () => {
              if (!M(s)) throw Bt("Show");
              return r();
            }
          )
        ) : n;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function Mt(e, t, r) {
  let s = r.length, o = t.length, n = s, i = 0, l = 0, c = t[o - 1].nextSibling, d = null;
  for (; i < o || l < n; ) {
    if (t[i] === r[l]) {
      i++, l++;
      continue;
    }
    for (; t[o - 1] === r[n - 1]; )
      o--, n--;
    if (o === i) {
      const p = n < s ? l ? r[l - 1].nextSibling : r[n - l] : c;
      for (; l < n; ) e.insertBefore(r[l++], p);
    } else if (n === l)
      for (; i < o; )
        (!d || !d.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === r[n - 1] && r[l] === t[o - 1]) {
      const p = t[--o].nextSibling;
      e.insertBefore(r[l++], t[i++].nextSibling), e.insertBefore(r[--n], p), t[o] = r[n];
    } else {
      if (!d) {
        d = /* @__PURE__ */ new Map();
        let a = l;
        for (; a < n; ) d.set(r[a], a++);
      }
      const p = d.get(t[i]);
      if (p != null)
        if (l < p && p < n) {
          let a = i, B = 1, x;
          for (; ++a < o && a < n && !((x = d.get(t[a])) == null || x !== p + B); )
            B++;
          if (B > p - l) {
            const k = t[i];
            for (; l < p; ) e.insertBefore(r[l++], k);
          } else e.replaceChild(r[l++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const tt = "_$DX_DELEGATE";
function It(e, t, r, s = {}) {
  let o;
  return re((n) => {
    o = n, t === document ? e() : _(t, e(), t.firstChild ? null : void 0, r);
  }, s.owner), () => {
    o(), t.textContent = "";
  };
}
function Y(e, t, r, s) {
  let o;
  const n = () => {
    const l = document.createElement("template");
    return l.innerHTML = e, l.content.firstChild;
  }, i = () => (o || (o = n())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function Dt(e, t = window.document) {
  const r = t[tt] || (t[tt] = /* @__PURE__ */ new Set());
  for (let s = 0, o = e.length; s < o; s++) {
    const n = e[s];
    r.has(n) || (r.add(n), t.addEventListener(n, zt));
  }
}
function q(e, t, r) {
  r == null ? e.removeAttribute(t) : e.setAttribute(t, r);
}
function rt(e, t) {
  t == null ? e.removeAttribute("class") : e.className = t;
}
function Nt(e, t, r) {
  return M(() => e(t, r));
}
function _(e, t, r, s) {
  if (r !== void 0 && !s && (s = []), typeof t != "function") return ce(e, t, s, r);
  R((o) => ce(e, t(), o, r), s);
}
function zt(e) {
  let t = e.target;
  const r = `$$${e.type}`, s = e.target, o = e.currentTarget, n = (c) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: c
  }), i = () => {
    const c = t[r];
    if (c && !t.disabled) {
      const d = t[`${r}Data`];
      if (d !== void 0 ? c.call(t, d, e) : c.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && n(t.host), !0;
  }, l = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const c = e.composedPath();
    n(c[0]);
    for (let d = 0; d < c.length - 2 && (t = c[d], !!i()); d++) {
      if (t._$host) {
        t = t._$host, l();
        break;
      }
      if (t.parentNode === o)
        break;
    }
  } else l();
  n(s);
}
function ce(e, t, r, s, o) {
  for (; typeof r == "function"; ) r = r();
  if (t === r) return r;
  const n = typeof t, i = s !== void 0;
  if (e = i && r[0] && r[0].parentNode || e, n === "string" || n === "number") {
    if (n === "number" && (t = t.toString(), t === r))
      return r;
    if (i) {
      let l = r[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), r = Q(e, r, s, l);
    } else
      r !== "" && typeof r == "string" ? r = e.firstChild.data = t : r = e.textContent = t;
  } else if (t == null || n === "boolean")
    r = Q(e, r, s);
  else {
    if (n === "function")
      return R(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        r = ce(e, l, r, s);
      }), () => r;
    if (Array.isArray(t)) {
      const l = [], c = r && Array.isArray(r);
      if (Me(l, t, r, o))
        return R(() => r = ce(e, l, r, s, !0)), () => r;
      if (l.length === 0) {
        if (r = Q(e, r, s), i) return r;
      } else c ? r.length === 0 ? st(e, l, s) : Mt(e, r, l) : (r && Q(e), st(e, l));
      r = l;
    } else if (t.nodeType) {
      if (Array.isArray(r)) {
        if (i) return r = Q(e, r, s, t);
        Q(e, r, null, t);
      } else r == null || r === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      r = t;
    }
  }
  return r;
}
function Me(e, t, r, s) {
  let o = !1;
  for (let n = 0, i = t.length; n < i; n++) {
    let l = t[n], c = r && r[e.length], d;
    if (!(l == null || l === !0 || l === !1)) if ((d = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      o = Me(e, l, c) || o;
    else if (d === "function")
      if (s) {
        for (; typeof l == "function"; ) l = l();
        o = Me(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(c) ? c : [c]
        ) || o;
      } else
        e.push(l), o = !0;
    else {
      const p = String(l);
      c && c.nodeType === 3 && c.data === p ? e.push(c) : e.push(document.createTextNode(p));
    }
  }
  return o;
}
function st(e, t, r = null) {
  for (let s = 0, o = t.length; s < o; s++) e.insertBefore(t[s], r);
}
function Q(e, t, r, s) {
  if (r === void 0) return e.textContent = "";
  const o = s || document.createTextNode("");
  if (t.length) {
    let n = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const l = t[i];
      if (o !== l) {
        const c = l.parentNode === e;
        !n && !i ? c ? e.replaceChild(o, l) : e.insertBefore(o, r) : c && l.remove();
      } else n = !0;
    }
  } else e.insertBefore(o, r);
  return [o];
}
const Ft = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, qe = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t);
  const r = Ft();
  return r[e] ? r[e] : e;
}, ft = {}, Qt = () => document.readyState !== "loading";
function dt(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  ft[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function pt(e) {
  return ft[e] || null;
}
function ht(e, t, r = {}) {
  const s = pt(e);
  if (!s)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const o = It(() => s(r), t);
    return t.dataset.solidInitialized = "true", o;
  } catch (o) {
    return console.error(`Error al renderizar el componente '${e}':`, o), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${o.message}</p>
      </div>
    `, null;
  }
}
function Ie() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const r = t.dataset.solidComponent;
    if (!r || t.dataset.solidInitialized === "true") return;
    let s = {};
    try {
      t.dataset.props && (s = JSON.parse(t.dataset.props));
    } catch (o) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        o
      );
    }
    ht(r, t, s);
  });
}
Qt() ? Ie() : document.addEventListener("DOMContentLoaded", Ie);
const yt = {
  registerComponent: dt,
  getComponent: pt,
  renderComponent: ht,
  initComponents: Ie
};
window.solidCore = yt;
var jt = /* @__PURE__ */ Y('<div class="absolute top-0 left-0 right-0 z-10 transform rotate-180"><svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 1440 100"preserveAspectRatio=none class="w-full h-16 md:h-20"><path fill=white d=M0,85.7L20,75.4C40,65.1,80,44.6,120,33.9C160,23.2,200,22.4,240,28.6C280,34.8,320,48.1,360,50C400,51.9,440,42.5,480,39.8C520,37.2,560,41.3,600,48.3C640,55.2,680,65,720,62.3C760,59.5,800,44.2,840,41.9C880,39.7,920,50.5,960,54.3C1000,58.2,1040,55.2,1080,58.2C1120,61.1,1160,69.9,1200,73.3C1240,76.8,1280,74.9,1320,70.9C1360,67,1400,61,1420,58L1440,55L1440,100L1420,100C1400,100,1360,100,1320,100C1280,100,1240,100,1200,100C1160,100,1120,100,1080,100C1040,100,1000,100,960,100C920,100,880,100,840,100C800,100,760,100,720,100C680,100,640,100,600,100C560,100,520,100,480,100C440,100,400,100,360,100C320,100,280,100,240,100C200,100,160,100,120,100C80,100,40,100,20,100L0,100Z>'), Ut = /* @__PURE__ */ Y('<div class="text-center mt-12"><a class="inline-flex items-center px-8 py-3 rounded-full text-white font-medium transition-all duration-300 group"><svg xmlns=http://www.w3.org/2000/svg class="h-4 w-4 mr-2 transition-transform duration-300 group-hover:-rotate-12"viewBox="0 0 20 20"fill=currentColor><path fill-rule=evenodd d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z"clip-rule=evenodd>'), Rt = /* @__PURE__ */ Y('<div class="absolute bottom-0 left-0 right-0 z-10"><svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 1440 100"preserveAspectRatio=none class="w-full h-16 md:h-20"><path fill=white d=M0,85.7L20,75.4C40,65.1,80,44.6,120,33.9C160,23.2,200,22.4,240,28.6C280,34.8,320,48.1,360,50C400,51.9,440,42.5,480,39.8C520,37.2,560,41.3,600,48.3C640,55.2,680,65,720,62.3C760,59.5,800,44.2,840,41.9C880,39.7,920,50.5,960,54.3C1000,58.2,1040,55.2,1080,58.2C1120,61.1,1160,69.9,1200,73.3C1240,76.8,1280,74.9,1320,70.9C1360,67,1400,61,1420,58L1440,55L1440,100L1420,100C1400,100,1360,100,1320,100C1280,100,1240,100,1200,100C1160,100,1120,100,1080,100C1040,100,1000,100,960,100C920,100,880,100,840,100C800,100,760,100,720,100C680,100,640,100,600,100C560,100,520,100,480,100C440,100,400,100,360,100C320,100,280,100,240,100C200,100,160,100,120,100C80,100,40,100,20,100L0,100Z>'), Wt = /* @__PURE__ */ Y('<div><div><div class="absolute -left-16 top-1/4 w-64 h-64 opacity-10 pointer-events-none rounded-full"></div><div class="absolute -right-16 bottom-1/4 w-48 h-48 opacity-10 pointer-events-none rounded-full"></div><div class="container mx-auto px-4 relative"><div class="text-center mb-16 relative"><div class="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 opacity-10 pointer-events-none"><svg xmlns=http://www.w3.org/2000/svg width=120 height=120 viewBox="0 0 24 24"class="transform rotate-12"><path d="M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm1.25 17c0 .69-.559 1.25-1.25 1.25-.689 0-1.25-.56-1.25-1.25s.561-1.25 1.25-1.25c.691 0 1.25.56 1.25 1.25zm1.393-9.998c-.608-.616-1.515-.955-2.551-.955-2.18 0-3.59 1.55-3.59 3.95h2.011c0-1.486.829-2.013 1.538-2.013.634 0 1.307.421 1.364 1.226.062.847-.39 1.277-.962 1.821-1.412 1.343-1.438 1.993-1.432 3.468h2.005c-.013-.664.03-1.203.935-2.178.677-.73 1.519-1.638 1.536-3.022.011-.924-.284-1.719-.854-2.297z"></path></svg></div><span class="block text-lg italic font-medium mb-2"></span><div class="relative inline-block"><h2 class="text-3xl md:text-4xl lg:text-5xl fancy-text font-medium mb-4"></h2><div class="absolute -bottom-2 left-1/2 w-24 h-0.5 transform -translate-x-1/2"><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2"></div></div></div><div class="absolute left-1/2 bottom-0 transform -translate-x-1/2 translate-y-full"><svg xmlns=http://www.w3.org/2000/svg width=24 height=24 viewBox="0 0 24 24"fill=none stroke-width=1 stroke-linecap=round stroke-linejoin=round><path d="M12 22V2M2 12h20M17 7l-5 5-5-5M17 17l-5-5-5 5"class=opacity-40></path></svg></div></div><div class="max-w-3xl mx-auto relative"><div class="absolute -left-8 top-0 opacity-10 pointer-events-none transform -translate-y-1/2"><svg xmlns=http://www.w3.org/2000/svg width=120 height=120 viewBox="0 0 24 24"><path d="M13 14.725c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275zm-13 0c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275z">'), Vt = /* @__PURE__ */ Y('<div class="faq-item mb-5 rounded-xl overflow-hidden shadow-sm transition-all duration-500 group"><div class="faq-question-container relative cursor-pointer"><div class="absolute inset-0 opacity-5 pointer-events-none"></div><h3 class="relative z-10"><button class="w-full text-left p-5 relative font-medium text-lg flex items-center transition-all duration-300"><span class="flex-shrink-0 mr-4 w-8 h-8 rounded-full grid place-items-center transition-all duration-300"><svg xmlns=http://www.w3.org/2000/svg class="h-4 w-4 text-white transition-transform duration-500"viewBox="0 0 20 20"fill=currentColor><path fill-rule=evenodd d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"clip-rule=evenodd></path></svg></span><span class="flex-1 transition-all duration-300"></span></button></h3></div><div role=region class="faq-answer relative z-10 overflow-hidden transition-all duration-500"><div class="w-full h-px mb-4 relative overflow-hidden"><div class="absolute inset-0 opacity-20"></div><div class="absolute left-0 top-0 h-full w-1/3 transition-all duration-500"></div></div><div class="prose max-w-none font-light">');
const Ht = (e) => {
  const {
    title: t = qe("Frequently Asked Questions", "wp-tailwind-blocks"),
    subtitle: r = qe("We answer your questions", "wp-tailwind-blocks"),
    faqs: s = [],
    backgroundColor: o = "#F7EDE2",
    // Warm background color
    textColor: n = "#424242",
    // Dark text color
    accentColor: i = "#D4B254",
    // Elegant gold
    secondaryColor: l = "#8BAB8D",
    // Sage green for secondary elements
    layout: c = "full",
    // 'full' or 'boxed'
    showTopWave: d = !0,
    showBottomWave: p = !0,
    contactText: a = qe("Do you have more questions?", "wp-tailwind-blocks"),
    contactUrl: B = "#contact",
    showContactButton: x = !0,
    openFirst: k = !1,
    singleOpen: T = !1,
    // Only one question open at a time
    animateEntrance: D = !0
    // Animate entrance of FAQs
  } = e, [N, P] = se(/* @__PURE__ */ new Set()), [b, C] = se(!1), [L, G] = se(null), ze = (g) => {
    P((v) => {
      const E = new Set(v);
      return E.has(g) ? E.delete(g) : (T && E.clear(), E.add(g)), E;
    });
  }, S = (g) => N().has(g);
  Ze(() => {
    k && s.length > 0 && ze(0), D ? setTimeout(() => {
      C(!0);
    }, 100) : C(!0);
  });
  let z;
  return Ze(() => {
    if (typeof IntersectionObserver > "u") return;
    const g = new IntersectionObserver((v) => {
      v.forEach((E) => {
        E.isIntersecting && !b() && (C(!0), g.unobserve(E.target));
      });
    }, {
      threshold: 0.2
    });
    return z && g.observe(z), () => {
      z && g.unobserve(z);
    };
  }), (() => {
    var g = Wt(), v = g.firstChild, E = v.firstChild, fe = E.nextSibling, de = fe.nextSibling, Fe = de.firstChild, Qe = Fe.firstChild, gt = Qe.firstChild, X = Qe.nextSibling, je = X.nextSibling, Ue = je.firstChild, pe = Ue.nextSibling, Re = pe.firstChild, vt = je.nextSibling, wt = vt.firstChild, We = Fe.nextSibling, mt = We.firstChild, bt = mt.firstChild;
    rt(g, `wptbt-faq-wrapper w-full ${c === "full" ? "full-width" : ""}`), (c === "full" ? "0 calc(50% - 50vw)" : "0") != null ? g.style.setProperty("margin", c === "full" ? "0 calc(50% - 50vw)" : "0") : g.style.removeProperty("margin"), (c === "full" ? "100vw" : "100%") != null ? g.style.setProperty("width", c === "full" ? "100vw" : "100%") : g.style.removeProperty("width"), (c === "full" ? "100vw" : "100%") != null ? g.style.setProperty("max-width", c === "full" ? "100vw" : "100%") : g.style.removeProperty("max-width");
    var Ve = z;
    return typeof Ve == "function" ? Nt(Ve, v) : z = v, o != null ? v.style.setProperty("background-color", o) : v.style.removeProperty("background-color"), n != null ? v.style.setProperty("color", n) : v.style.removeProperty("color"), v.style.setProperty("transition", "opacity 0.8s ease-out, transform 0.8s ease-out"), v.style.setProperty("overflow", "hidden"), v.style.setProperty("position", "relative"), l != null ? E.style.setProperty("background-color", l) : E.style.removeProperty("background-color"), i != null ? fe.style.setProperty("background-color", i) : fe.style.removeProperty("background-color"), _(v, ee(Be, {
      when: c === "full" && d,
      get children() {
        return jt();
      }
    }), de), q(gt, "fill", l), i != null ? X.style.setProperty("color", i) : X.style.removeProperty("color"), _(X, r), _(Ue, t), i != null ? pe.style.setProperty("background-color", i) : pe.style.removeProperty("background-color"), i != null ? Re.style.setProperty("background-color", i) : Re.style.removeProperty("background-color"), q(wt, "stroke", i), q(bt, "fill", i), _(We, ee(qt, {
      each: s,
      children: (A, f) => (() => {
        var h = Vt(), he = h.firstChild, J = he.firstChild, Ct = J.nextSibling, j = Ct.firstChild, F = j.firstChild, He = F.firstChild, U = F.nextSibling, $ = he.nextSibling, Ye = $.firstChild, ye = Ye.firstChild, K = ye.nextSibling, Z = Ye.nextSibling;
        return h.addEventListener("mouseleave", () => G(null)), h.addEventListener("mouseenter", () => G(f())), h.style.setProperty("background", "rgba(255,255,255,0.9)"), h.style.setProperty("backdrop-filter", "blur(5px)"), he.$$click = () => ze(f()), `radial-gradient(circle at top right, ${i}, transparent 70%)` != null ? J.style.setProperty("background", `radial-gradient(circle at top right, ${i}, transparent 70%)`) : J.style.removeProperty("background"), J.style.setProperty("z-index", "0"), _(U, () => A.question), $.style.setProperty("padding-left", "60px"), $.style.setProperty("padding-right", "24px"), i != null ? ye.style.setProperty("background-color", i) : ye.style.removeProperty("background-color"), i != null ? K.style.setProperty("background-color", i) : K.style.removeProperty("background-color"), Z.style.setProperty("line-height", "1.7"), R((u) => {
          var ge = b() ? "translateY(0)" : "translateY(20px)", ve = b() ? "1" : "0", we = `transform 0.5s ease ${f() * 0.1}s, opacity 0.5s ease ${f() * 0.1}s, box-shadow 0.3s ease`, me = S(f()) ? "0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.05)" : "0 1px 3px rgba(0,0,0,0.1)", be = S(f()) ? `1px solid ${i}30` : "1px solid rgba(0,0,0,0.05)", Ce = S(f()) ? i : n, Ge = S(f()) ? "true" : "false", Xe = `faq-answer-${f()}`, xe = S(f()) ? i : l, Pe = L() === f() ? "scale(1.1)" : "scale(1)", Se = S(f()) ? "rotate(180deg)" : "rotate(0deg)", Ee = S(f()) ? "600" : "500", Ae = S(f()) ? `0 0 1px ${i}33` : "none", Je = `faq-answer-${f()}`, $e = S(f()) ? "1000px" : "0px", ke = S(f()) ? "1" : "0", Te = S(f()) ? "24px" : "0px", Le = L() === f() ? "translateX(200%)" : "translateX(0)", Ke = A.answer, _e = S(f()) ? n : `${n}dd`;
          return ge !== u.e && ((u.e = ge) != null ? h.style.setProperty("transform", ge) : h.style.removeProperty("transform")), ve !== u.t && ((u.t = ve) != null ? h.style.setProperty("opacity", ve) : h.style.removeProperty("opacity")), we !== u.a && ((u.a = we) != null ? h.style.setProperty("transition", we) : h.style.removeProperty("transition")), me !== u.o && ((u.o = me) != null ? h.style.setProperty("box-shadow", me) : h.style.removeProperty("box-shadow")), be !== u.i && ((u.i = be) != null ? h.style.setProperty("border", be) : h.style.removeProperty("border")), Ce !== u.n && ((u.n = Ce) != null ? j.style.setProperty("color", Ce) : j.style.removeProperty("color")), Ge !== u.s && q(j, "aria-expanded", u.s = Ge), Xe !== u.h && q(j, "aria-controls", u.h = Xe), xe !== u.r && ((u.r = xe) != null ? F.style.setProperty("background-color", xe) : F.style.removeProperty("background-color")), Pe !== u.d && ((u.d = Pe) != null ? F.style.setProperty("transform", Pe) : F.style.removeProperty("transform")), Se !== u.l && ((u.l = Se) != null ? He.style.setProperty("transform", Se) : He.style.removeProperty("transform")), Ee !== u.u && ((u.u = Ee) != null ? U.style.setProperty("font-weight", Ee) : U.style.removeProperty("font-weight")), Ae !== u.c && ((u.c = Ae) != null ? U.style.setProperty("text-shadow", Ae) : U.style.removeProperty("text-shadow")), Je !== u.w && q($, "id", u.w = Je), $e !== u.m && ((u.m = $e) != null ? $.style.setProperty("max-height", $e) : $.style.removeProperty("max-height")), ke !== u.f && ((u.f = ke) != null ? $.style.setProperty("opacity", ke) : $.style.removeProperty("opacity")), Te !== u.y && ((u.y = Te) != null ? $.style.setProperty("padding-bottom", Te) : $.style.removeProperty("padding-bottom")), Le !== u.g && ((u.g = Le) != null ? K.style.setProperty("transform", Le) : K.style.removeProperty("transform")), Ke !== u.p && (Z.innerHTML = u.p = Ke), _e !== u.b && ((u.b = _e) != null ? Z.style.setProperty("color", _e) : Z.style.removeProperty("color")), u;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0,
          s: void 0,
          h: void 0,
          r: void 0,
          d: void 0,
          l: void 0,
          u: void 0,
          c: void 0,
          w: void 0,
          m: void 0,
          f: void 0,
          y: void 0,
          g: void 0,
          p: void 0,
          b: void 0
        }), h;
      })()
    }), null), _(de, ee(Be, {
      when: x,
      get children() {
        var A = Ut(), f = A.firstChild;
        return f.firstChild, f.addEventListener("mouseleave", (h) => {
          h.currentTarget.style.transform = "translateY(0)", h.currentTarget.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
        }), f.addEventListener("mouseenter", (h) => {
          h.currentTarget.style.transform = "translateY(-3px)", h.currentTarget.style.boxShadow = "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)";
        }), q(f, "href", B), i != null ? f.style.setProperty("background-color", i) : f.style.removeProperty("background-color"), f.style.setProperty("box-shadow", "0 4px 6px rgba(0, 0, 0, 0.1)"), f.style.setProperty("transform", "translateY(0)"), q(f, "style::hover", {
          transform: "translateY(-3px)",
          "box-shadow": "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
        }), _(f, a, null), A;
      }
    }), null), _(v, ee(Be, {
      when: c === "full" && p,
      get children() {
        return Rt();
      }
    }), null), R((A) => {
      var f = `wptbt-faq-container py-16 md:py-20 lg:py-24 relative ${b() ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`, h = `
            radial-gradient(circle at 10% 20%, rgba(${te(l)}, 0.05) 0%, rgba(${te(l)}, 0) 20%),
            radial-gradient(circle at 90% 80%, rgba(${te(i)}, 0.07) 0%, rgba(${te(i)}, 0) 20%)
          `;
      return f !== A.e && rt(v, A.e = f), h !== A.t && ((A.t = h) != null ? v.style.setProperty("background-image", h) : v.style.removeProperty("background-image")), A;
    }, {
      e: void 0,
      t: void 0
    }), g;
  })();
};
function te(e) {
  e = e.replace(/^#/, "");
  let t = parseInt(e, 16), r = t >> 16 & 255, s = t >> 8 & 255, o = t & 255;
  return `${r}, ${s}, ${o}`;
}
Dt(["click"]);
dt("faq", Ht);
function De() {
  const e = document.querySelectorAll(".solid-faq-container");
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      let r = [];
      try {
        t.dataset.faqs && (r = JSON.parse(t.dataset.faqs));
      } catch (n) {
        console.warn("Error al parsear datos de FAQs:", n);
      }
      console.log(t.dataset);
      const s = {
        title: t.dataset.title || "Preguntas Frecuentes",
        subtitle: t.dataset.subtitle || "Resolvemos tus dudas",
        faqs: r,
        backgroundColor: t.dataset.backgroundColor || "#F7EDE2",
        textColor: t.dataset.textColor || "#424242",
        accentColor: t.dataset.accentColor || "#D4B254",
        secondaryColor: t.dataset.secondaryColor || "#8BAB8D",
        layout: t.dataset.layout || "full",
        contactText: t.dataset.contactText || "¿Tienes más preguntas?",
        contactUrl: t.dataset.contactUrl || "#contact",
        showContactButton: t.dataset.showContactButton !== "false",
        openFirst: t.dataset.openFirst === "true",
        singleOpen: t.dataset.singleOpen === "true",
        animateEntrance: t.dataset.animateEntrance !== "false",
        showTopWave: t.dataset.showTopWave === "true",
        showBottomWave: t.dataset.showBottomWave === "true"
      }, o = yt.renderComponent("faq", t, s);
      t._solidDispose = o, console.log("Componente de FAQ con Solid.js cargado correctamente");
    } catch (r) {
      console.error(
        "Error al inicializar componente de FAQ con Solid.js:",
        r
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de FAQ: ${r.message}</p>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", De) : De();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((r) => {
        if (r.isIntersecting) {
          const s = r.target;
          s.classList.contains("solid-faq-container") && s.dataset.intersectOnce === "true" && s.dataset.solidInitialized !== "true" && (De(), s.dataset.intersectOnce = "true"), e.unobserve(r.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  document.querySelectorAll(".solid-faq-container[data-intersect-once]").forEach((t) => {
    e.observe(t);
  });
}
export {
  De as initFAQs
};
