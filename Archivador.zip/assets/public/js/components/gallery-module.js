const vl = (t, e) => t === e, gl = Symbol("solid-track"), Ye = {
  equals: vl
};
let Rt = Yt;
const xe = 1, Je = 2, Ft = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var z = null;
let at = null, ml = null, O = null, W = null, me = null, tt = 0;
function Ue(t, e) {
  const l = O, r = z, n = t.length === 0, o = e === void 0 ? r : e, d = n ? Ft : {
    owned: null,
    cleanups: null,
    context: o ? o.context : null,
    owner: o
  }, s = n ? t : () => t(() => ye(() => Ve(d)));
  z = d, O = null;
  try {
    return je(s, !0);
  } finally {
    O = l, z = r;
  }
}
function Y(t, e) {
  e = e ? Object.assign({}, Ye, e) : Ye;
  const l = {
    value: t,
    observers: null,
    observerSlots: null,
    comparator: e.equals || void 0
  }, r = (n) => (typeof n == "function" && (n = n(l.value)), Wt(l, n));
  return [qt.bind(l), r];
}
function R(t, e, l) {
  const r = ft(t, e, !1, xe);
  He(r);
}
function Ke(t, e, l) {
  Rt = $l;
  const r = ft(t, e, !1, xe);
  (!l || !l.render) && (r.user = !0), me ? me.push(r) : He(r);
}
function Be(t, e, l) {
  l = l ? Object.assign({}, Ye, l) : Ye;
  const r = ft(t, e, !0, 0);
  return r.observers = null, r.observerSlots = null, r.comparator = l.equals || void 0, He(r), qt.bind(r);
}
function ye(t) {
  if (O === null) return t();
  const e = O;
  O = null;
  try {
    return t();
  } finally {
    O = e;
  }
}
function yl(t) {
  Ke(() => ye(t));
}
function Xe(t) {
  return z === null || (z.cleanups === null ? z.cleanups = [t] : z.cleanups.push(t)), t;
}
function bl() {
  return z;
}
function wl(t, e) {
  const l = z, r = O;
  z = t, O = null;
  try {
    return je(e, !0);
  } catch (n) {
    ht(n);
  } finally {
    z = l, O = r;
  }
}
function qt() {
  if (this.sources && this.state)
    if (this.state === xe) He(this);
    else {
      const t = W;
      W = null, je(() => Ze(this), !1), W = t;
    }
  if (O) {
    const t = this.observers ? this.observers.length : 0;
    O.sources ? (O.sources.push(this), O.sourceSlots.push(t)) : (O.sources = [this], O.sourceSlots = [t]), this.observers ? (this.observers.push(O), this.observerSlots.push(O.sources.length - 1)) : (this.observers = [O], this.observerSlots = [O.sources.length - 1]);
  }
  return this.value;
}
function Wt(t, e, l) {
  let r = t.value;
  return (!t.comparator || !t.comparator(r, e)) && (t.value = e, t.observers && t.observers.length && je(() => {
    for (let n = 0; n < t.observers.length; n += 1) {
      const o = t.observers[n], d = at && at.running;
      d && at.disposed.has(o), (d ? !o.tState : !o.state) && (o.pure ? W.push(o) : me.push(o), o.observers && Jt(o)), d || (o.state = xe);
    }
    if (W.length > 1e6)
      throw W = [], new Error();
  }, !1)), e;
}
function He(t) {
  if (!t.fn) return;
  Ve(t);
  const e = tt;
  pl(
    t,
    t.value,
    e
  );
}
function pl(t, e, l) {
  let r;
  const n = z, o = O;
  O = z = t;
  try {
    r = t.fn(e);
  } catch (d) {
    return t.pure && (t.state = xe, t.owned && t.owned.forEach(Ve), t.owned = null), t.updatedAt = l + 1, ht(d);
  } finally {
    O = o, z = n;
  }
  (!t.updatedAt || t.updatedAt <= l) && (t.updatedAt != null && "observers" in t ? Wt(t, r) : t.value = r, t.updatedAt = l);
}
function ft(t, e, l, r = xe, n) {
  const o = {
    fn: t,
    state: r,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: e,
    owner: z,
    context: z ? z.context : null,
    pure: l
  };
  return z === null || z !== Ft && (z.owned ? z.owned.push(o) : z.owned = [o]), o;
}
function Qe(t) {
  if (t.state === 0) return;
  if (t.state === Je) return Ze(t);
  if (t.suspense && ye(t.suspense.inFallback)) return t.suspense.effects.push(t);
  const e = [t];
  for (; (t = t.owner) && (!t.updatedAt || t.updatedAt < tt); )
    t.state && e.push(t);
  for (let l = e.length - 1; l >= 0; l--)
    if (t = e[l], t.state === xe)
      He(t);
    else if (t.state === Je) {
      const r = W;
      W = null, je(() => Ze(t, e[0]), !1), W = r;
    }
}
function je(t, e) {
  if (W) return t();
  let l = !1;
  e || (W = []), me ? l = !0 : me = [], tt++;
  try {
    const r = t();
    return xl(l), r;
  } catch (r) {
    l || (me = null), W = null, ht(r);
  }
}
function xl(t) {
  if (W && (Yt(W), W = null), t) return;
  const e = me;
  me = null, e.length && je(() => Rt(e), !1);
}
function Yt(t) {
  for (let e = 0; e < t.length; e++) Qe(t[e]);
}
function $l(t) {
  let e, l = 0;
  for (e = 0; e < t.length; e++) {
    const r = t[e];
    r.user ? t[l++] = r : Qe(r);
  }
  for (e = 0; e < l; e++) Qe(t[e]);
}
function Ze(t, e) {
  t.state = 0;
  for (let l = 0; l < t.sources.length; l += 1) {
    const r = t.sources[l];
    if (r.sources) {
      const n = r.state;
      n === xe ? r !== e && (!r.updatedAt || r.updatedAt < tt) && Qe(r) : n === Je && Ze(r, e);
    }
  }
}
function Jt(t) {
  for (let e = 0; e < t.observers.length; e += 1) {
    const l = t.observers[e];
    l.state || (l.state = Je, l.pure ? W.push(l) : me.push(l), l.observers && Jt(l));
  }
}
function Ve(t) {
  let e;
  if (t.sources)
    for (; t.sources.length; ) {
      const l = t.sources.pop(), r = t.sourceSlots.pop(), n = l.observers;
      if (n && n.length) {
        const o = n.pop(), d = l.observerSlots.pop();
        r < n.length && (o.sourceSlots[d] = r, n[r] = o, l.observerSlots[r] = d);
      }
    }
  if (t.tOwned) {
    for (e = t.tOwned.length - 1; e >= 0; e--) Ve(t.tOwned[e]);
    delete t.tOwned;
  }
  if (t.owned) {
    for (e = t.owned.length - 1; e >= 0; e--) Ve(t.owned[e]);
    t.owned = null;
  }
  if (t.cleanups) {
    for (e = t.cleanups.length - 1; e >= 0; e--) t.cleanups[e]();
    t.cleanups = null;
  }
  t.state = 0;
}
function Cl(t) {
  return t instanceof Error ? t : new Error(typeof t == "string" ? t : "Unknown error", {
    cause: t
  });
}
function ht(t, e = z) {
  throw Cl(t);
}
const Sl = Symbol("fallback");
function Gt(t) {
  for (let e = 0; e < t.length; e++) t[e]();
}
function Pl(t, e, l = {}) {
  let r = [], n = [], o = [], d = 0, s = e.length > 1 ? [] : null;
  return Xe(() => Gt(o)), () => {
    let g = t() || [], p = g.length, L, a;
    return g[gl], ye(() => {
      let K, ie, X, Me, le, Q, Z, de, re;
      if (p === 0)
        d !== 0 && (Gt(o), o = [], r = [], n = [], d = 0, s && (s = [])), l.fallback && (r = [Sl], n[0] = Ue((Oe) => (o[0] = Oe, l.fallback())), d = 1);
      else if (d === 0) {
        for (n = new Array(p), a = 0; a < p; a++)
          r[a] = g[a], n[a] = Ue(ve);
        d = p;
      } else {
        for (X = new Array(p), Me = new Array(p), s && (le = new Array(p)), Q = 0, Z = Math.min(d, p); Q < Z && r[Q] === g[Q]; Q++) ;
        for (Z = d - 1, de = p - 1; Z >= Q && de >= Q && r[Z] === g[de]; Z--, de--)
          X[de] = n[Z], Me[de] = o[Z], s && (le[de] = s[Z]);
        for (K = /* @__PURE__ */ new Map(), ie = new Array(de + 1), a = de; a >= Q; a--)
          re = g[a], L = K.get(re), ie[a] = L === void 0 ? -1 : L, K.set(re, a);
        for (L = Q; L <= Z; L++)
          re = r[L], a = K.get(re), a !== void 0 && a !== -1 ? (X[a] = n[L], Me[a] = o[L], s && (le[a] = s[L]), a = ie[a], K.set(re, a)) : o[L]();
        for (a = Q; a < p; a++)
          a in X ? (n[a] = X[a], o[a] = Me[a], s && (s[a] = le[a], s[a](a))) : n[a] = Ue(ve);
        n = n.slice(0, d = p), r = g.slice(0);
      }
      return n;
    });
    function ve(K) {
      if (o[a] = K, s) {
        const [ie, X] = Y(a);
        return s[a] = X, e(g[a], ie);
      }
      return e(g[a]);
    }
  };
}
function V(t, e) {
  return ye(() => t(e || {}));
}
const kl = (t) => `Stale read from <${t}>.`;
function Ae(t) {
  const e = "fallback" in t && {
    fallback: () => t.fallback
  };
  return Be(Pl(() => t.each, t.children, e || void 0));
}
function se(t) {
  const e = t.keyed, l = Be(() => t.when, void 0, void 0), r = e ? l : Be(l, void 0, {
    equals: (n, o) => !n == !o
  });
  return Be(
    () => {
      const n = r();
      if (n) {
        const o = t.children;
        return typeof o == "function" && o.length > 0 ? ye(
          () => o(
            e ? n : () => {
              if (!ye(r)) throw kl("Show");
              return l();
            }
          )
        ) : o;
      }
      return t.fallback;
    },
    void 0,
    void 0
  );
}
function El(t, e, l) {
  let r = l.length, n = e.length, o = r, d = 0, s = 0, g = e[n - 1].nextSibling, p = null;
  for (; d < n || s < o; ) {
    if (e[d] === l[s]) {
      d++, s++;
      continue;
    }
    for (; e[n - 1] === l[o - 1]; )
      n--, o--;
    if (n === d) {
      const L = o < r ? s ? l[s - 1].nextSibling : l[o - s] : g;
      for (; s < o; ) t.insertBefore(l[s++], L);
    } else if (o === s)
      for (; d < n; )
        (!p || !p.has(e[d])) && e[d].remove(), d++;
    else if (e[d] === l[o - 1] && l[s] === e[n - 1]) {
      const L = e[--n].nextSibling;
      t.insertBefore(l[s++], e[d++].nextSibling), t.insertBefore(l[--o], L), e[n] = l[o];
    } else {
      if (!p) {
        p = /* @__PURE__ */ new Map();
        let a = s;
        for (; a < o; ) p.set(l[a], a++);
      }
      const L = p.get(e[d]);
      if (L != null)
        if (s < L && L < o) {
          let a = d, ve = 1, K;
          for (; ++a < n && a < o && !((K = p.get(e[a])) == null || K !== L + ve); )
            ve++;
          if (ve > L - s) {
            const ie = e[d];
            for (; s < L; ) t.insertBefore(l[s++], ie);
          } else t.replaceChild(l[s++], e[d++]);
        } else d++;
      else e[d++].remove();
    }
  }
}
const Ut = "_$DX_DELEGATE";
function Ll(t, e, l, r = {}) {
  let n;
  return Ue((o) => {
    n = o, e === document ? t() : y(e, t(), e.firstChild ? null : void 0, l);
  }, r.owner), () => {
    n(), e.textContent = "";
  };
}
function T(t, e, l, r) {
  let n;
  const o = () => {
    const s = r ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return s.innerHTML = t, l ? s.content.firstChild.firstChild : r ? s.firstChild : s.content.firstChild;
  }, d = e ? () => ye(() => document.importNode(n || (n = o()), !0)) : () => (n || (n = o())).cloneNode(!0);
  return d.cloneNode = d, d;
}
function _l(t, e = window.document) {
  const l = e[Ut] || (e[Ut] = /* @__PURE__ */ new Set());
  for (let r = 0, n = t.length; r < n; r++) {
    const o = t[r];
    l.has(o) || (l.add(o), e.addEventListener(o, Al));
  }
}
function u(t, e, l) {
  l == null ? t.removeAttribute(e) : t.setAttribute(e, l);
}
function Se(t, e) {
  e == null ? t.removeAttribute("class") : t.className = e;
}
function Bt(t, e, l) {
  if (!e) return l ? u(t, "style") : e;
  const r = t.style;
  if (typeof e == "string") return r.cssText = e;
  typeof l == "string" && (r.cssText = l = void 0), l || (l = {}), e || (e = {});
  let n, o;
  for (o in l)
    e[o] == null && r.removeProperty(o), delete l[o];
  for (o in e)
    n = e[o], n !== l[o] && (r.setProperty(o, n), l[o] = n);
  return l;
}
function Il(t, e, l) {
  return ye(() => t(e, l));
}
function y(t, e, l, r) {
  if (l !== void 0 && !r && (r = []), typeof e != "function") return et(t, e, r, l);
  R((n) => et(t, e(), n, l), r);
}
function Al(t) {
  let e = t.target;
  const l = `$$${t.type}`, r = t.target, n = t.currentTarget, o = (g) => Object.defineProperty(t, "target", {
    configurable: !0,
    value: g
  }), d = () => {
    const g = e[l];
    if (g && !e.disabled) {
      const p = e[`${l}Data`];
      if (p !== void 0 ? g.call(e, p, t) : g.call(e, t), t.cancelBubble) return;
    }
    return e.host && typeof e.host != "string" && !e.host._$host && e.contains(t.target) && o(e.host), !0;
  }, s = () => {
    for (; d() && (e = e._$host || e.parentNode || e.host); ) ;
  };
  if (Object.defineProperty(t, "currentTarget", {
    configurable: !0,
    get() {
      return e || document;
    }
  }), t.composedPath) {
    const g = t.composedPath();
    o(g[0]);
    for (let p = 0; p < g.length - 2 && (e = g[p], !!d()); p++) {
      if (e._$host) {
        e = e._$host, s();
        break;
      }
      if (e.parentNode === n)
        break;
    }
  } else s();
  o(r);
}
function et(t, e, l, r, n) {
  for (; typeof l == "function"; ) l = l();
  if (e === l) return l;
  const o = typeof e, d = r !== void 0;
  if (t = d && l[0] && l[0].parentNode || t, o === "string" || o === "number") {
    if (o === "number" && (e = e.toString(), e === l))
      return l;
    if (d) {
      let s = l[0];
      s && s.nodeType === 3 ? s.data !== e && (s.data = e) : s = document.createTextNode(e), l = Te(t, l, r, s);
    } else
      l !== "" && typeof l == "string" ? l = t.firstChild.data = e : l = t.textContent = e;
  } else if (e == null || o === "boolean")
    l = Te(t, l, r);
  else {
    if (o === "function")
      return R(() => {
        let s = e();
        for (; typeof s == "function"; ) s = s();
        l = et(t, s, l, r);
      }), () => l;
    if (Array.isArray(e)) {
      const s = [], g = l && Array.isArray(l);
      if (ct(s, e, l, n))
        return R(() => l = et(t, s, l, r, !0)), () => l;
      if (s.length === 0) {
        if (l = Te(t, l, r), d) return l;
      } else g ? l.length === 0 ? Vt(t, s, r) : El(t, l, s) : (l && Te(t), Vt(t, s));
      l = s;
    } else if (e.nodeType) {
      if (Array.isArray(l)) {
        if (d) return l = Te(t, l, r, e);
        Te(t, l, null, e);
      } else l == null || l === "" || !t.firstChild ? t.appendChild(e) : t.replaceChild(e, t.firstChild);
      l = e;
    }
  }
  return l;
}
function ct(t, e, l, r) {
  let n = !1;
  for (let o = 0, d = e.length; o < d; o++) {
    let s = e[o], g = l && l[t.length], p;
    if (!(s == null || s === !0 || s === !1)) if ((p = typeof s) == "object" && s.nodeType)
      t.push(s);
    else if (Array.isArray(s))
      n = ct(t, s, g) || n;
    else if (p === "function")
      if (r) {
        for (; typeof s == "function"; ) s = s();
        n = ct(
          t,
          Array.isArray(s) ? s : [s],
          Array.isArray(g) ? g : [g]
        ) || n;
      } else
        t.push(s), n = !0;
    else {
      const L = String(s);
      g && g.nodeType === 3 && g.data === L ? t.push(g) : t.push(document.createTextNode(L));
    }
  }
  return n;
}
function Vt(t, e, l = null) {
  for (let r = 0, n = e.length; r < n; r++) t.insertBefore(e[r], l);
}
function Te(t, e, l, r) {
  if (l === void 0) return t.textContent = "";
  const n = r || document.createTextNode("");
  if (e.length) {
    let o = !1;
    for (let d = e.length - 1; d >= 0; d--) {
      const s = e[d];
      if (n !== s) {
        const g = s.parentNode === t;
        !o && !d ? g ? t.replaceChild(n, s) : t.insertBefore(n, l) : g && s.remove();
      } else o = !0;
    }
  } else t.insertBefore(n, l);
  return [n];
}
const Tl = "http://www.w3.org/2000/svg";
function jl(t, e = !1) {
  return e ? document.createElementNS(Tl, t) : document.createElement(t);
}
function Ml(t) {
  const { useShadow: e } = t, l = document.createTextNode(""), r = () => t.mount || document.body, n = bl();
  let o;
  return Ke(
    () => {
      o || (o = wl(n, () => Be(() => t.children)));
      const d = r();
      if (d instanceof HTMLHeadElement) {
        const [s, g] = Y(!1), p = () => g(!0);
        Ue((L) => y(d, () => s() ? L() : o(), null)), Xe(p);
      } else {
        const s = jl(t.isSVG ? "g" : "div", t.isSVG), g = e && s.attachShadow ? s.attachShadow({
          mode: "open"
        }) : s;
        Object.defineProperty(s, "_$host", {
          get() {
            return l.parentNode;
          },
          configurable: !0
        }), y(g, o), d.appendChild(s), t.ref && t.ref(s), Xe(() => d.removeChild(s));
      }
    },
    void 0,
    {
      render: !0
    }
  ), l;
}
const Ol = () => {
  const t = {};
  return Object.keys(window).forEach((e) => {
    e.startsWith("wptbtI18n_") && Object.assign(t, window[e]);
  }), window.wptbtI18n && Object.assign(t, window.wptbtI18n), t;
}, zl = (t, e) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(t, e || "wp-tailwind-blocks");
  const l = Ol();
  return l[t] ? l[t] : t;
}, Kt = {}, Nl = () => document.readyState !== "loading";
function Xt(t, e) {
  if (typeof t != "string" || t.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof e != "function") {
    console.error(
      `El componente ${t} debe ser una función válida de Solid.js`
    );
    return;
  }
  Kt[t] = e, console.log(`Componente '${t}' registrado correctamente`);
}
function Qt(t) {
  return Kt[t] || null;
}
function Zt(t, e, l = {}) {
  const r = Qt(t);
  if (!r)
    return console.error(`El componente '${t}' no está registrado`), null;
  if (!e || !(e instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; e.firstChild; )
      e.removeChild(e.firstChild);
    const n = Ll(() => r(l), e);
    return e.dataset.solidInitialized = "true", n;
  } catch (n) {
    return console.error(`Error al renderizar el componente '${t}':`, n), e.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${n.message}</p>
      </div>
    `, null;
  }
}
function dt() {
  const t = document.querySelectorAll("[data-solid-component]");
  t.length !== 0 && t.forEach((e) => {
    const l = e.dataset.solidComponent;
    if (!l || e.dataset.solidInitialized === "true") return;
    let r = {};
    try {
      e.dataset.props && (r = JSON.parse(e.dataset.props));
    } catch (n) {
      console.warn(
        `Error al parsear propiedades para ${l}:`,
        n
      );
    }
    Zt(l, e, r);
  });
}
Nl() ? dt() : document.addEventListener("DOMContentLoaded", dt);
const el = {
  registerComponent: Xt,
  getComponent: Qt,
  renderComponent: Zt,
  initComponents: dt
};
window.solidCore = el;
var Dl = /* @__PURE__ */ T("<script type=application/ld+json>"), Gl = /* @__PURE__ */ T('<p class="block text-base italic font-medium mb-1">'), Ul = /* @__PURE__ */ T('<div class="relative inline-block"><h1 class="text-2xl md:text-3xl fancy-text font-medium mb-2"></h1><div class="absolute -bottom-1 left-1/2 w-16 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), Bl = /* @__PURE__ */ T('<p class="text-gray-600 mt-3 max-w-2xl mx-auto">'), Vl = /* @__PURE__ */ T('<p class="text-sm text-gray-600 mt-2 font-light"> <!> <!> <!> '), Hl = /* @__PURE__ */ T('<header class="text-center mb-8 relative">'), Rl = /* @__PURE__ */ T('<div class="gallery-slider-container relative overflow-hidden"role=region><div class=slider-wrapper></div><nav class="slider-controls mt-4 flex items-center justify-center gap-4"><button type=button class="slider-prev-btn w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center transition-all duration-300 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4"fill=none viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7"></path></svg></button><div class="slider-dots flex space-x-1.5"role=tablist></div><button type=button class="slider-next-btn w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center transition-all duration-300 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4"fill=none viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), Fl = /* @__PURE__ */ T('<div class="gallery-masonry-container columns-1 sm:columns-2 lg:columns-3">'), ql = /* @__PURE__ */ T('<div class="gallery-grid-container grid"><style jsx>'), Wl = /* @__PURE__ */ T('<h2 class="text-lg fancy-text italic text-white/80 hidden md:block">'), Yl = /* @__PURE__ */ T('<div class="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm rounded-lg z-20"aria-live=polite><div class="flex flex-col items-center space-y-4"><div class="relative w-16 h-16"><div class="absolute inset-0 border-4 border-white/20 rounded-full"></div><div class="absolute inset-0 border-4 border-transparent border-t-white rounded-full animate-spin"></div><div class="absolute inset-2 border-2 border-transparent border-r-white/60 rounded-full animate-spin animate-reverse"></div></div><div class="text-white/80 text-sm font-light">...</div><div class="text-white/60 text-xs"> / '), Jl = /* @__PURE__ */ T('<div class="text-center mb-3 md:hidden"><p class="fancy-text italic text-white/80 text-sm">'), Kl = /* @__PURE__ */ T('<div role=dialog aria-modal=true><div class="lightbox-container max-w-7xl mx-auto px-4 py-4 md:py-8 w-full h-full flex flex-col justify-between"><div class="flex items-center justify-between mb-2 md:mb-4"><div class="flex-1 text-white"></div><div class="flex items-center space-x-3"><button type=button class="lightbox-fullscreen-btn w-10 h-10 flex items-center justify-center text-white/70 hover:text-white transition-colors rounded-full hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-white/50"><svg class="w-5 h-5"viewBox="0 0 24 24"fill=none xmlns=http://www.w3.org/2000/svg aria-hidden=true><path d="M15 3h6v6M9 3H3v6M3 15v6h6M21 15v6h-6"stroke=currentColor stroke-width=2 stroke-linecap=round stroke-linejoin=round></path></svg></button><button type=button class="lightbox-close-btn w-10 h-10 flex items-center justify-center text-white/70 hover:text-white transition-colors rounded-full hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-white/50"><svg class="w-5 h-5"fill=none stroke=currentColor viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M6 18L18 6M6 6l12 12"></path></svg></button></div></div><div class="flex-1 flex items-center justify-center relative overflow-hidden"><div><img class="max-w-full max-h-[70vh] mx-auto object-contain rounded shadow-2xl"></div><div class="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-1 md:px-4 opacity-0 md:opacity-100 group-hover:opacity-100 transition-opacity"><button type=button class="lightbox-nav-btn w-10 h-10 md:w-12 md:h-12 bg-black/30 hover:bg-black/60 text-white/70 hover:text-white rounded-full flex items-center justify-center backdrop-blur-sm transition-all transform hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-white/50"><svg class="w-5 h-5"fill=none stroke=currentColor viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7"></path></svg></button><button type=button class="lightbox-nav-btn w-10 h-10 md:w-12 md:h-12 bg-black/30 hover:bg-black/60 text-white/70 hover:text-white rounded-full flex items-center justify-center backdrop-blur-sm transition-all transform hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-white/50"><svg class="w-5 h-5"fill=none stroke=currentColor viewBox="0 0 24 24"xmlns=http://www.w3.org/2000/svg aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7"></path></svg></button></div></div><div class="mt-2 md:mt-4"><div class="flex items-center justify-center space-x-6"><div class="text-white/70 flex items-center space-x-3"><div class="text-lg fancy-text"> / </div><div class="hidden md:block w-24 h-1 bg-white/20 rounded-full overflow-hidden"><div class="h-full bg-white/80 rounded-full transition-all duration-300"role=progressbar aria-valuemin=1></div></div></div></div><div class="mt-4 hidden md:block"><div class="flex space-x-1.5 justify-center pb-2 overflow-x-auto max-w-full"role=group>'), Xl = /* @__PURE__ */ T('<section role=img><div class="absolute -left-16 top-1/4 w-32 h-32 opacity-10 pointer-events-none rounded-full"aria-hidden=true></div><div class="absolute -right-16 bottom-1/4 w-24 h-24 opacity-10 pointer-events-none rounded-full"aria-hidden=true></div><div class="container mx-auto px-4 relative"><div class="gallery-container relative"></div></div><div class="absolute bottom-0 right-0 w-32 h-32 opacity-5 pointer-events-none transform translate-x-12 translate-y-12"aria-hidden=true><svg viewBox="0 0 200 200"xmlns=http://www.w3.org/2000/svg><path d=M31.9,-31.9C40.4,-21.4,45.8,-8.7,45.1,3.8C44.5,16.4,38.1,28.8,27.6,38.3C17.2,47.8,2.9,54.2,-13.4,53.6C-29.7,53,-48.1,45.3,-55.8,31.1C-63.5,16.9,-60.6,-3.8,-52.1,-19.9C-43.5,-36,-29.3,-47.6,-14.8,-48.8C-0.3,-50,14.1,-40.9,28.4,-32.1Z transform="translate(100 100)">'), Ql = /* @__PURE__ */ T('<div class="slider-slide min-w-full"><div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">'), Zl = /* @__PURE__ */ T('<article><div class="aspect-ratio-container relative">'), er = /* @__PURE__ */ T('<button type=button class="block w-full h-full focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"><div class="absolute inset-0 flex items-center justify-center transition-all duration-300"><div class="text-center text-white relative z-10"><div class="text-2xl font-bold mb-1 drop-shadow-lg">+</div><div class="text-sm font-light opacity-95 drop-shadow-md">', !0, !1, !1), tr = /* @__PURE__ */ T('<a class="block w-full h-full focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw">', !0, !1, !1), lr = /* @__PURE__ */ T('<button type=button role=tab class="slider-dot w-2 h-2 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2">'), Ht = /* @__PURE__ */ T("<article>"), rr = /* @__PURE__ */ T('<button type=button class="block relative w-full focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-auto transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"><div class="absolute inset-0 flex items-center justify-center transition-all duration-300"><div class="text-center text-white relative z-10"><div class="text-2xl font-bold mb-1 drop-shadow-lg">+</div><div class="text-sm font-light opacity-95 drop-shadow-md">', !0, !1, !1), or = /* @__PURE__ */ T('<a class="block relative focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-auto transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw">', !0, !1, !1), nr = /* @__PURE__ */ T('<button type=button class="block w-full h-full relative focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"><div class="absolute inset-0 flex items-center justify-center transition-all duration-300"><div class="text-center text-white relative z-10"><div class="text-2xl font-bold mb-1 drop-shadow-lg">+</div><div class="text-sm font-light opacity-95 drop-shadow-md">', !0, !1, !1), sr = /* @__PURE__ */ T('<a class="block w-full h-full relative focus:outline-none focus:ring-2 focus:ring-offset-2"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw">', !0, !1, !1), ir = /* @__PURE__ */ T('<button type=button><img class="h-full w-full object-cover">');
const ar = (t) => {
  const e = (c, f = "wptbt-gallery-block") => {
    const k = window.wptbtI18n_gallery || {};
    return k[c] ? k[c] : zl(c, f);
  }, {
    title: l = "",
    subtitle: r = "",
    description: n = "",
    images: o = [],
    columns: d = 3,
    maxVisibleImages: s = 12,
    displayMode: g = "grid",
    // 'grid', 'masonry', 'slider'
    hoverEffect: p = "zoom",
    // 'zoom', 'fade', 'slide', 'none'
    textColor: L = "#1F2937",
    accentColor: a = "#DC2626",
    secondaryColor: ve = "#059669",
    fullWidth: K = !1,
    enableLightbox: ie = !0,
    spacing: X = 16,
    imageSize: Me = "medium_large",
    // Nuevas props para SEO
    galleryId: le = "gallery",
    baseUrl: Q = window.location.origin + window.location.pathname,
    organizationName: Z = "",
    websiteName: de = ""
  } = t, [re, Oe] = Y(0), [ze, tl] = Y(0), [lt, vt] = Y(null), [gt, mt] = Y(!1), [rt, yt] = Y(!1), [H, Ne] = Y(null), [ll, rl] = Y(!1), [ol, nl] = Y(0), [oe, Pe] = Y(null), [sl, bt] = Y(!1), [wt, ke] = Y(!1), [Ee, be] = Y(!1), [Re, ue] = Y("fade-in");
  let fe, pt;
  const ge = () => o.slice(0, s), $e = () => Math.max(0, o.length - s), De = () => $e() > 0, Ce = (c, f) => {
    if (c.permalink) return c.permalink;
    const k = c.alt ? c.alt.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") : `image-${f + 1}`;
    return `${Q}#${le}-${k}`;
  }, il = () => {
    const c = {
      "@context": "https://schema.org",
      "@type": "ImageGallery",
      name: l,
      description: n,
      numberOfItems: o.length,
      image: o.map((f, k) => ({
        "@type": "ImageObject",
        url: f.fullUrl || f.url,
        thumbnail: f.url,
        caption: f.caption || f.alt || `${l} - Image ${k + 1}`,
        description: f.description || f.alt || `Gallery image ${k + 1}`,
        width: f.width,
        height: f.height,
        encodingFormat: f.mime || "image/jpeg",
        contentUrl: f.fullUrl || f.url,
        name: f.title || f.alt || `Image ${k + 1}`
      }))
    };
    return Z && (c.author = {
      "@type": "Organization",
      name: Z
    }), JSON.stringify(c);
  }, xt = () => {
    if (g === "slider" && !lt() && !gt()) {
      const c = setInterval(() => {
        $t();
      }, 5e3);
      vt(c);
    }
  }, ot = () => {
    lt() && (clearInterval(lt()), vt(null));
  }, $t = () => {
    Oe((c) => (c + 1) % ze());
  }, al = () => {
    Oe((c) => (c - 1 + ze()) % ze());
  }, cl = (c) => {
    Oe(c);
  }, Fe = (c, f, k) => {
    if (c.preventDefault(), !ie) {
      window.open(f.fullUrl || f.url, "_blank");
      return;
    }
    const ee = Ce(f, k);
    history.pushState({
      galleryId: le,
      imageIndex: k
    }, `${l} - ${f.alt || `Image ${k + 1}`}`, ee), Ct(f, k);
  }, Ct = (c, f) => {
    ie && (ue("fade-out"), bt(!0), yt(!0), ke(!0), document.body.style.overflow = "hidden", document.addEventListener("keydown", We), setTimeout(() => {
      Ne({
        ...c,
        index: f
      }), setTimeout(() => {
        ue("fade-in"), ke(!1);
      }, 50);
    }, 50));
  }, nt = (c) => {
    c.preventDefault(), !(!ie || !De()) && Fe(c, o[s], s);
  }, qe = () => {
    ue("fade-out"), be(!0), history.pushState(null, document.title, Q), clearTimeout(fe), fe = setTimeout(() => {
      bt(!1), yt(!1), Ne(null), be(!1), document.body.style.overflow = "", document.removeEventListener("keydown", We);
    }, 300);
  }, We = (c) => {
    if (rt())
      switch (c.key) {
        case "ArrowLeft":
          St();
          break;
        case "ArrowRight":
          Pt();
          break;
        case "Escape":
          qe();
          break;
      }
  }, dl = () => {
    ke(!1);
  }, St = () => {
    Ee() || (ke(!0), be(!0), ue("slide-right"), clearTimeout(fe), fe = setTimeout(() => {
      var ne;
      const f = ((((ne = H()) == null ? void 0 : ne.index) || 0) - 1 + o.length) % o.length, k = o[f], ee = Ce(k, f);
      history.replaceState({
        galleryId: le,
        imageIndex: f
      }, `${l} - ${k.alt || `Image ${f + 1}`}`, ee), Ne({
        ...k,
        index: f
      }), setTimeout(() => {
        ue("fade-in"), be(!1);
      }, 100);
    }, 200));
  }, Pt = () => {
    Ee() || (ke(!0), be(!0), ue("slide-left"), clearTimeout(fe), fe = setTimeout(() => {
      var ne;
      const f = ((((ne = H()) == null ? void 0 : ne.index) || 0) + 1) % o.length, k = o[f], ee = Ce(k, f);
      history.replaceState({
        galleryId: le,
        imageIndex: f
      }, `${l} - ${k.alt || `Image ${f + 1}`}`, ee), Ne({
        ...k,
        index: f
      }), setTimeout(() => {
        ue("fade-in"), be(!1);
      }, 100);
    }, 200));
  }, ul = (c) => {
    var k;
    if (Ee()) return;
    const f = ((k = H()) == null ? void 0 : k.index) || 0;
    c !== f && (ke(!0), be(!0), c < f ? ue("slide-right") : ue("slide-left"), clearTimeout(fe), fe = setTimeout(() => {
      const ee = o[c], ne = Ce(ee, c);
      history.replaceState({
        galleryId: le,
        imageIndex: c
      }, `${l} - ${ee.alt || `Image ${c + 1}`}`, ne), Ne({
        ...ee,
        index: c
      }), setTimeout(() => {
        ue("fade-in"), be(!1);
      }, 100);
    }, 200));
  }, Le = (c) => c.srcset ? typeof c.srcset == "string" ? c.srcset : Object.entries(c.srcset).map(([f, k]) => `${k} ${f}`).join(", ") : "";
  yl(() => {
    g === "slider" && (tl(Math.ceil(ge().length / 4)), xt());
    const c = (f) => {
      var k;
      ((k = f.state) == null ? void 0 : k.galleryId) === le ? typeof f.state.imageIndex == "number" && Ct(o[f.state.imageIndex], f.state.imageIndex) : rt() && qe();
    };
    return window.addEventListener("popstate", c), () => {
      document.removeEventListener("keydown", We), window.removeEventListener("popstate", c), clearTimeout(fe);
    };
  }), Xe(() => {
    document.removeEventListener("keydown", We), clearTimeout(fe);
  }), Ke(() => {
    !gt() && g === "slider" && xt();
  }), Ke(() => {
    ol() === ge().length && g === "masonry" && rl(!0);
  });
  const _e = () => {
    nl((c) => c + 1);
  }, fl = () => ({
    transform: `translateX(-${re() * 100}%)`,
    transition: "transform 0.8s cubic-bezier(0.4, 0, 0.2, 1)"
  }), st = (() => {
    const c = Math.min(d, 4);
    return {
      small: Math.min(c, 1),
      // 1 columna en móvil para mejor visibilidad
      medium: Math.min(c, 2),
      // 2 columnas en tablet
      large: c
      // Columnas completas en desktop
    };
  })();
  return [(() => {
    var c = Dl();
    return y(c, il), c;
  })(), (() => {
    var c = Xl(), f = c.firstChild, k = f.nextSibling, ee = k.nextSibling, ne = ee.firstChild, kt = ee.nextSibling, hl = kt.firstChild;
    return c.addEventListener("mouseleave", () => mt(!1)), c.addEventListener("mouseenter", () => mt(!0)), u(c, "id", le), Se(c, `solid-gallery-component w-full py-8 md:py-12 relative ${K ? "vw-100" : ""}`), ve != null ? f.style.setProperty("background-color", ve) : f.style.removeProperty("background-color"), a != null ? k.style.setProperty("background-color", a) : k.style.removeProperty("background-color"), y(ee, V(se, {
      when: l || r || n,
      get children() {
        var $ = Hl();
        return y($, V(se, {
          when: r,
          get children() {
            var b = Gl();
            return a != null ? b.style.setProperty("color", a) : b.style.removeProperty("color"), y(b, r), b;
          }
        }), null), y($, V(se, {
          when: l,
          get children() {
            var b = Ul(), E = b.firstChild, I = E.nextSibling, N = I.firstChild;
            return y(E, l), a != null ? I.style.setProperty("background-color", a) : I.style.removeProperty("background-color"), a != null ? N.style.setProperty("background-color", a) : N.style.removeProperty("background-color"), b;
          }
        }), null), y($, V(se, {
          when: n,
          get children() {
            var b = Bl();
            return y(b, n), b;
          }
        }), null), y($, V(se, {
          get when() {
            return De();
          },
          get children() {
            var b = Vl(), E = b.firstChild, I = E.nextSibling, N = I.nextSibling, w = N.nextSibling, h = w.nextSibling, v = h.nextSibling;
            return v.nextSibling, y(b, () => e("Showing"), E), y(b, () => ge().length, I), y(b, () => e("of"), w), y(b, () => o.length, v), y(b, () => e("images"), null), b;
          }
        }), null), $;
      }
    }), ne), y(ne, V(se, {
      when: g === "slider",
      get children() {
        var $ = Rl(), b = $.firstChild, E = b.nextSibling, I = E.firstChild, N = I.firstChild, w = I.nextSibling, h = w.nextSibling, v = h.firstChild, C = pt;
        return typeof C == "function" ? Il(C, $) : pt = $, y(b, V(Ae, {
          get each() {
            return Array(ze()).fill().map((m, P) => P);
          },
          children: (m) => {
            const x = ge().slice(m * 4, m * 4 + 4);
            return (() => {
              var S = Ql(), j = S.firstChild;
              return y(j, V(Ae, {
                each: x,
                children: (A, F) => {
                  const M = m * 4 + F(), Ie = M === ge().length - 1 && De();
                  return (() => {
                    var ae = Zl(), we = ae.firstChild;
                    return ae.addEventListener("mouseleave", () => Pe(null)), ae.addEventListener("mouseenter", () => Pe(M)), Se(ae, `gallery-item effect-${p} overflow-hidden rounded-lg shadow-lg transition-all duration-500 relative`), we.style.setProperty("aspect-ratio", "1/1"), y(we, Ie ? (() => {
                      var D = er(), G = D.firstChild, i = G.nextSibling, B = i.firstChild, U = B.firstChild;
                      U.firstChild;
                      var J = U.nextSibling;
                      return D.$$click = nt, a != null ? D.style.setProperty("focus", a) : D.style.removeProperty("focus"), G.addEventListener("load", _e), i.style.setProperty("backdrop-filter", "blur(8px)"), i.style.setProperty("background-color", "rgba(0, 0, 0, 0.4)"), y(U, $e, null), y(J, () => e("more images")), R((_) => {
                        var q = `${e("View")} ${$e()} ${e("more images")}`, te = A.url, ce = A.alt || e("Gallery image"), he = oe() === M && p === "zoom" ? "scale(1.05)" : "scale(1)", pe = Le(A);
                        return q !== _.e && u(D, "aria-label", _.e = q), te !== _.t && u(G, "src", _.t = te), ce !== _.a && u(G, "alt", _.a = ce), he !== _.o && ((_.o = he) != null ? G.style.setProperty("transform", he) : G.style.removeProperty("transform")), pe !== _.i && u(G, "srcset", _.i = pe), _;
                      }, {
                        e: void 0,
                        t: void 0,
                        a: void 0,
                        o: void 0,
                        i: void 0
                      }), D;
                    })() : (() => {
                      var D = tr(), G = D.firstChild;
                      return D.$$click = (i) => Fe(i, A, M), a != null ? D.style.setProperty("focus", a) : D.style.removeProperty("focus"), G.addEventListener("load", _e), R((i) => {
                        var B = Ce(A, M), U = `${e("View image")}: ${A.alt || e("Gallery image")} ${M + 1}`, J = A.url, _ = A.alt || e("Gallery image"), q = oe() === M && p === "zoom" ? "scale(1.05)" : "scale(1)", te = Le(A);
                        return B !== i.e && u(D, "href", i.e = B), U !== i.t && u(D, "aria-label", i.t = U), J !== i.a && u(G, "src", i.a = J), _ !== i.o && u(G, "alt", i.o = _), q !== i.i && ((i.i = q) != null ? G.style.setProperty("transform", q) : G.style.removeProperty("transform")), te !== i.n && u(G, "srcset", i.n = te), i;
                      }, {
                        e: void 0,
                        t: void 0,
                        a: void 0,
                        o: void 0,
                        i: void 0,
                        n: void 0
                      }), D;
                    })()), R((D) => {
                      var G = oe() === M ? "translateY(-3px)" : "translateY(0)", i = oe() === M ? "0 10px 20px rgba(0,0,0,0.15)" : "0 3px 10px rgba(0,0,0,0.1)";
                      return G !== D.e && ((D.e = G) != null ? ae.style.setProperty("transform", G) : ae.style.removeProperty("transform")), i !== D.t && ((D.t = i) != null ? ae.style.setProperty("box-shadow", i) : ae.style.removeProperty("box-shadow")), D;
                    }, {
                      e: void 0,
                      t: void 0
                    }), ae;
                  })();
                }
              })), S;
            })();
          }
        })), I.$$click = () => {
          ot(), al();
        }, `1px solid ${a}40` != null ? I.style.setProperty("border", `1px solid ${a}40`) : I.style.removeProperty("border"), a != null ? I.style.setProperty("focus", a) : I.style.removeProperty("focus"), u(N, "stroke", L), y(w, V(Ae, {
          get each() {
            return Array(ze()).fill().map((m, P) => P);
          },
          children: (m) => (() => {
            var P = lr();
            return P.$$click = () => {
              ot(), cl(m);
            }, a != null ? P.style.setProperty("focus", a) : P.style.removeProperty("focus"), R((x) => {
              var S = re() === m ? a : "#E9E2D8", j = re() === m ? "scale(1.2)" : "scale(1)", A = re() === m ? "1" : "0.6", F = re() === m, M = `${e("Go to slide")} ${m + 1}`;
              return S !== x.e && ((x.e = S) != null ? P.style.setProperty("background-color", S) : P.style.removeProperty("background-color")), j !== x.t && ((x.t = j) != null ? P.style.setProperty("transform", j) : P.style.removeProperty("transform")), A !== x.a && ((x.a = A) != null ? P.style.setProperty("opacity", A) : P.style.removeProperty("opacity")), F !== x.o && u(P, "aria-selected", x.o = F), M !== x.i && u(P, "aria-label", x.i = M), x;
            }, {
              e: void 0,
              t: void 0,
              a: void 0,
              o: void 0,
              i: void 0
            }), P;
          })()
        })), h.$$click = () => {
          ot(), $t();
        }, `1px solid ${a}40` != null ? h.style.setProperty("border", `1px solid ${a}40`) : h.style.removeProperty("border"), a != null ? h.style.setProperty("focus", a) : h.style.removeProperty("focus"), u(v, "stroke", L), R((m) => {
          var P = e("Image slider"), x = fl(), S = e("Slider navigation"), j = e("Previous slide"), A = e("Slide indicators"), F = e("Next slide");
          return P !== m.e && u($, "aria-label", m.e = P), m.t = Bt(b, x, m.t), S !== m.a && u(E, "aria-label", m.a = S), j !== m.o && u(I, "aria-label", m.o = j), A !== m.i && u(w, "aria-label", m.i = A), F !== m.n && u(h, "aria-label", m.n = F), m;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0
        }), $;
      }
    }), null), y(ne, V(se, {
      when: g === "masonry",
      get children() {
        var $ = Fl();
        return `${X}px` != null ? $.style.setProperty("column-gap", `${X}px`) : $.style.removeProperty("column-gap"), $.style.setProperty("transition", "opacity 0.5s ease"), y($, V(Ae, {
          get each() {
            return ge();
          },
          children: (b, E) => {
            const I = E() === ge().length - 1 && De();
            return (() => {
              var N = Ht();
              return N.addEventListener("mouseleave", () => Pe(null)), N.addEventListener("mouseenter", () => Pe(E())), Se(N, `gallery-item effect-${p} overflow-hidden break-inside-avoid rounded-lg shadow-lg transition-all duration-500 relative`), `${X}px` != null ? N.style.setProperty("margin-bottom", `${X}px`) : N.style.removeProperty("margin-bottom"), y(N, I ? (() => {
                var w = rr(), h = w.firstChild, v = h.nextSibling, C = v.firstChild, m = C.firstChild;
                m.firstChild;
                var P = m.nextSibling;
                return w.$$click = nt, a != null ? w.style.setProperty("focus", a) : w.style.removeProperty("focus"), h.addEventListener("load", _e), v.style.setProperty("backdrop-filter", "blur(8px)"), v.style.setProperty("background-color", "rgba(0, 0, 0, 0.4)"), y(m, $e, null), y(P, () => e("more images")), R((x) => {
                  var S = `${e("View")} ${$e()} ${e("more images")}`, j = b.url, A = b.alt || e("Gallery image"), F = p === "zoom" && oe() === E() ? "scale(1.02)" : "scale(1)", M = Le(b);
                  return S !== x.e && u(w, "aria-label", x.e = S), j !== x.t && u(h, "src", x.t = j), A !== x.a && u(h, "alt", x.a = A), F !== x.o && ((x.o = F) != null ? h.style.setProperty("transform", F) : h.style.removeProperty("transform")), M !== x.i && u(h, "srcset", x.i = M), x;
                }, {
                  e: void 0,
                  t: void 0,
                  a: void 0,
                  o: void 0,
                  i: void 0
                }), w;
              })() : (() => {
                var w = or(), h = w.firstChild;
                return w.$$click = (v) => Fe(v, b, E()), a != null ? w.style.setProperty("focus", a) : w.style.removeProperty("focus"), h.addEventListener("load", _e), R((v) => {
                  var C = Ce(b, E()), m = `${e("View image")}: ${b.alt || e("Gallery image")} ${E() + 1}`, P = b.url, x = b.alt || e("Gallery image"), S = p === "zoom" && oe() === E() ? "scale(1.02)" : "scale(1)", j = Le(b);
                  return C !== v.e && u(w, "href", v.e = C), m !== v.t && u(w, "aria-label", v.t = m), P !== v.a && u(h, "src", v.a = P), x !== v.o && u(h, "alt", v.o = x), S !== v.i && ((v.i = S) != null ? h.style.setProperty("transform", S) : h.style.removeProperty("transform")), j !== v.n && u(h, "srcset", v.n = j), v;
                }, {
                  e: void 0,
                  t: void 0,
                  a: void 0,
                  o: void 0,
                  i: void 0,
                  n: void 0
                }), w;
              })()), R((w) => {
                var h = oe() === E() ? "translateY(-3px) scale(1.01)" : "translateY(0) scale(1)", v = oe() === E() ? "0 10px 20px rgba(0,0,0,0.15)" : "0 3px 10px rgba(0,0,0,0.1)";
                return h !== w.e && ((w.e = h) != null ? N.style.setProperty("transform", h) : N.style.removeProperty("transform")), v !== w.t && ((w.t = v) != null ? N.style.setProperty("box-shadow", v) : N.style.removeProperty("box-shadow")), w;
              }, {
                e: void 0,
                t: void 0
              }), N;
            })();
          }
        })), R((b) => (b = ll() ? "1" : "0.3") != null ? $.style.setProperty("opacity", b) : $.style.removeProperty("opacity")), $;
      }
    }), null), y(ne, V(se, {
      when: g === "grid",
      get children() {
        var $ = ql(), b = $.firstChild;
        return y(b, () => `
                  .gallery-grid-container {
                    grid-template-columns: repeat(${st.small}, minmax(0, 1fr));
                    gap: ${X}px;
                  }
                  @media (min-width: 640px) {
                    .gallery-grid-container {
                      grid-template-columns: repeat(
                        ${st.medium},
                        minmax(0, 1fr)
                      );
                    }
                  }
                  @media (min-width: 1024px) {
                    .gallery-grid-container {
                      grid-template-columns: repeat(
                        ${st.large},
                        minmax(0, 1fr)
                      );
                    }
                  }
                `), y($, V(Ae, {
          get each() {
            return ge();
          },
          children: (E, I) => {
            const N = I() === ge().length - 1 && De();
            return (() => {
              var w = Ht();
              return w.addEventListener("mouseleave", () => Pe(null)), w.addEventListener("mouseenter", () => Pe(I())), Se(w, `gallery-item effect-${p} overflow-hidden relative rounded-lg shadow-sm transition-all duration-300 bg-white`), w.style.setProperty("aspect-ratio", "4/3"), y(w, N ? (() => {
                var h = nr(), v = h.firstChild, C = v.nextSibling, m = C.firstChild, P = m.firstChild;
                P.firstChild;
                var x = P.nextSibling;
                return h.$$click = nt, a != null ? h.style.setProperty("focus", a) : h.style.removeProperty("focus"), v.addEventListener("load", _e), C.style.setProperty("backdrop-filter", "blur(8px)"), C.style.setProperty("background-color", "rgba(0, 0, 0, 0.4)"), y(P, $e, null), y(x, () => e("more images")), R((S) => {
                  var j = `${e("View")} ${$e()} ${e("more images")}`, A = E.url, F = E.alt || e("Gallery image"), M = p === "zoom" && oe() === I() ? "scale(1.02)" : "scale(1)", Ie = Le(E);
                  return j !== S.e && u(h, "aria-label", S.e = j), A !== S.t && u(v, "src", S.t = A), F !== S.a && u(v, "alt", S.a = F), M !== S.o && ((S.o = M) != null ? v.style.setProperty("transform", M) : v.style.removeProperty("transform")), Ie !== S.i && u(v, "srcset", S.i = Ie), S;
                }, {
                  e: void 0,
                  t: void 0,
                  a: void 0,
                  o: void 0,
                  i: void 0
                }), h;
              })() : (() => {
                var h = sr(), v = h.firstChild;
                return h.$$click = (C) => Fe(C, E, I()), a != null ? h.style.setProperty("focus", a) : h.style.removeProperty("focus"), v.addEventListener("load", _e), R((C) => {
                  var m = Ce(E, I()), P = `${e("View image")}: ${E.alt || e("Gallery image")} ${I() + 1}`, x = E.url, S = E.alt || e("Gallery image"), j = p === "zoom" && oe() === I() ? "scale(1.02)" : "scale(1)", A = Le(E);
                  return m !== C.e && u(h, "href", C.e = m), P !== C.t && u(h, "aria-label", C.t = P), x !== C.a && u(v, "src", C.a = x), S !== C.o && u(v, "alt", C.o = S), j !== C.i && ((C.i = j) != null ? v.style.setProperty("transform", j) : v.style.removeProperty("transform")), A !== C.n && u(v, "srcset", C.n = A), C;
                }, {
                  e: void 0,
                  t: void 0,
                  a: void 0,
                  o: void 0,
                  i: void 0,
                  n: void 0
                }), h;
              })()), R((h) => {
                var v = oe() === I() ? "translateY(-2px)" : "translateY(0)", C = oe() === I() ? "0 8px 25px rgba(0,0,0,0.15)" : "0 2px 8px rgba(0,0,0,0.06)";
                return v !== h.e && ((h.e = v) != null ? w.style.setProperty("transform", v) : w.style.removeProperty("transform")), C !== h.t && ((h.t = C) != null ? w.style.setProperty("box-shadow", C) : w.style.removeProperty("box-shadow")), h;
              }, {
                e: void 0,
                t: void 0
              }), w;
            })();
          }
        }), null), $;
      }
    }), null), y(c, V(se, {
      get when() {
        return sl();
      },
      get children() {
        return V(Ml, {
          get children() {
            var $ = Kl(), b = $.firstChild, E = b.firstChild, I = E.firstChild, N = I.nextSibling, w = N.firstChild, h = w.nextSibling, v = E.nextSibling, C = v.firstChild, m = C.firstChild, P = C.nextSibling, x = P.firstChild, S = x.nextSibling, j = v.nextSibling, A = j.firstChild, F = A.firstChild, M = F.firstChild, Ie = M.firstChild, ae = M.nextSibling, we = ae.firstChild, D = A.nextSibling, G = D.firstChild;
            return $.$$click = qe, $.style.setProperty("background-color", "rgba(0,0,0,0.9)"), $.style.setProperty("backdrop-filter", "blur(8px)"), b.$$click = (i) => i.stopPropagation(), y(I, V(se, {
              get when() {
                var i;
                return (i = H()) == null ? void 0 : i.caption;
              },
              get children() {
                var i = Wl();
                return y(i, () => {
                  var B;
                  return (B = H()) == null ? void 0 : B.caption;
                }), i;
              }
            })), w.$$click = () => {
              window.open(H().fullUrl || H().url, "_blank");
            }, h.$$click = qe, y(C, V(se, {
              get when() {
                return wt();
              },
              get children() {
                var i = Yl(), B = i.firstChild, U = B.firstChild, J = U.nextSibling, _ = J.firstChild, q = J.nextSibling, te = q.firstChild;
                return y(J, () => e("Loading image"), _), y(q, () => {
                  var ce;
                  return (((ce = H()) == null ? void 0 : ce.index) || 0) + 1;
                }, te), y(q, () => o.length, null), i;
              }
            }), m), m.addEventListener("load", dl), m.style.setProperty("filter", "drop-shadow(0 12px 24px rgba(0,0,0,0.5))"), m.style.setProperty("transition", "opacity 0.3s ease"), x.$$click = (i) => {
              i.stopPropagation(), St();
            }, S.$$click = (i) => {
              i.stopPropagation(), Pt();
            }, y(j, V(se, {
              get when() {
                var i;
                return (i = H()) == null ? void 0 : i.caption;
              },
              get children() {
                var i = Jl(), B = i.firstChild;
                return y(B, () => {
                  var U;
                  return (U = H()) == null ? void 0 : U.caption;
                }), i;
              }
            }), A), y(M, () => {
              var i;
              return (((i = H()) == null ? void 0 : i.index) || 0) + 1;
            }, Ie), y(M, () => o.length, null), y(G, V(Ae, {
              each: o,
              children: (i, B) => (() => {
                var U = ir(), J = U.firstChild;
                return U.$$click = () => ul(B()), R((_) => {
                  var Ge;
                  var q = `h-12 w-12 rounded overflow-hidden transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-white/50 ${B() === ((Ge = H()) == null ? void 0 : Ge.index) ? "ring-2 ring-offset-2 ring-white opacity-100 scale-110" : "opacity-60 hover:opacity-100"}`, te = Ee(), ce = `${e("Go to image")} ${B() + 1}: ${i.alt || e("Gallery image")}`, he = i.url, pe = i.alt || `${e("Thumbnail")} ${B() + 1}`;
                  return q !== _.e && Se(U, _.e = q), te !== _.t && (U.disabled = _.t = te), ce !== _.a && u(U, "aria-label", _.a = ce), he !== _.o && u(J, "src", _.o = he), pe !== _.i && u(J, "alt", _.i = pe), _;
                }, {
                  e: void 0,
                  t: void 0,
                  a: void 0,
                  o: void 0,
                  i: void 0
                }), U;
              })()
            })), R((i) => {
              var jt, Mt, Ot, zt, Nt, Dt;
              var B = `lightbox fixed inset-0 z-[9999] flex items-center justify-center transition-opacity duration-300 ${rt() ? "opacity-100" : "opacity-0"}`, U = e("Image lightbox"), J = e("View full image"), _ = e("Close lightbox"), q = `relative max-h-full transition-all duration-300 ${Re() === "fade-in" ? "opacity-100 scale-[1]" : Re() === "fade-out" ? "opacity-0 scale-[0.95]" : Re() === "slide-left" ? "opacity-0 translate-x-full" : Re() === "slide-right" ? "opacity-0 -translate-x-full" : ""}`, te = ((jt = H()) == null ? void 0 : jt.fullUrl) || ((Mt = H()) == null ? void 0 : Mt.url), ce = ((Ot = H()) == null ? void 0 : Ot.alt) || e("Gallery image"), he = wt() ? "0.3" : "1", pe = Ee(), Ge = e("Previous image"), Et = Ee(), Lt = e("Next image"), it = `${((((zt = H()) == null ? void 0 : zt.index) || 0) + 1) / o.length * 100}%`, _t = (((Nt = H()) == null ? void 0 : Nt.index) || 0) + 1, It = o.length, At = `${e("Image")} ${(((Dt = H()) == null ? void 0 : Dt.index) || 0) + 1} ${e("of")} ${o.length}`, Tt = e("Image thumbnails");
              return B !== i.e && Se($, i.e = B), U !== i.t && u($, "aria-label", i.t = U), J !== i.a && u(w, "aria-label", i.a = J), _ !== i.o && u(h, "aria-label", i.o = _), q !== i.i && Se(C, i.i = q), te !== i.n && u(m, "src", i.n = te), ce !== i.s && u(m, "alt", i.s = ce), he !== i.h && ((i.h = he) != null ? m.style.setProperty("opacity", he) : m.style.removeProperty("opacity")), pe !== i.r && (x.disabled = i.r = pe), Ge !== i.d && u(x, "aria-label", i.d = Ge), Et !== i.l && (S.disabled = i.l = Et), Lt !== i.u && u(S, "aria-label", i.u = Lt), it !== i.c && ((i.c = it) != null ? we.style.setProperty("width", it) : we.style.removeProperty("width")), _t !== i.w && u(we, "aria-valuenow", i.w = _t), It !== i.m && u(we, "aria-valuemax", i.m = It), At !== i.f && u(we, "aria-label", i.f = At), Tt !== i.y && u(G, "aria-label", i.y = Tt), i;
            }, {
              e: void 0,
              t: void 0,
              a: void 0,
              o: void 0,
              i: void 0,
              n: void 0,
              s: void 0,
              h: void 0,
              r: void 0,
              d: void 0,
              l: void 0,
              u: void 0,
              c: void 0,
              w: void 0,
              m: void 0,
              f: void 0,
              y: void 0
            }), $;
          }
        });
      }
    }), kt), u(hl, "fill", a), R(($) => {
      var b = `${l} - ${e("Image gallery with")} ${o.length} ${e("images")}`, E = {
        color: L,
        "background-image": `
            radial-gradient(circle at 10% 20%, rgba(138, 171, 141, 0.05) 0%, rgba(138, 171, 141, 0) 20%),
            radial-gradient(circle at 90% 80%, rgba(212, 178, 84, 0.07) 0%, rgba(212, 178, 84, 0) 20%)
          `,
        ...K ? {
          "margin-left": "calc(50% - 50vw)",
          "margin-right": "calc(50% - 50vw)",
          width: "100vw",
          "max-width": "100vw"
        } : {}
      };
      return b !== $.e && u(c, "aria-label", $.e = b), $.t = Bt(c, E, $.t), $;
    }, {
      e: void 0,
      t: void 0
    }), c;
  })()];
};
_l(["click"]);
Xt("gallery", ar);
function ut() {
  const t = document.querySelectorAll(".solid-gallery-container");
  t.length !== 0 && t.forEach((e) => {
    try {
      if (e.dataset.solidInitialized === "true") return;
      let l = [];
      try {
        e.dataset.images && (l = JSON.parse(e.dataset.images));
      } catch (o) {
        console.warn("Error al parsear datos de imágenes:", o);
      }
      const r = {
        title: e.dataset.title || "",
        subtitle: e.dataset.subtitle || "",
        description: e.dataset.description || "",
        images: l,
        columns: parseInt(e.dataset.columns || 3, 10),
        displayMode: e.dataset.displayMode || "grid",
        // 'grid', 'masonry', 'slider'
        hoverEffect: e.dataset.hoverEffect || "zoom",
        // 'zoom', 'fade', 'slide', 'none'
        backgroundColor: e.dataset.backgroundColor || "#F9F5F2",
        textColor: e.dataset.textColor || "#5D534F",
        accentColor: e.dataset.accentColor || "#D4B254",
        secondaryColor: e.dataset.secondaryColor || "#8BAB8D",
        fullWidth: e.dataset.fullWidth === "true",
        enableLightbox: e.dataset.enableLightbox !== "false",
        spacing: parseInt(e.dataset.spacing || 16, 10)
      }, n = el.renderComponent("gallery", e, r);
      e._solidDispose = n, console.log("Componente de galería con Solid.js cargado correctamente");
    } catch (l) {
      console.error(
        "Error al inicializar componente de galería con Solid.js:",
        l
      ), e.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de galería: ${l.message}</p>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", ut) : ut();
if ("IntersectionObserver" in window) {
  const t = new IntersectionObserver(
    (e) => {
      e.forEach((l) => {
        if (l.isIntersecting) {
          const r = l.target;
          r.classList.contains("solid-gallery-container") && r.dataset.intersectOnce === "true" && r.dataset.solidInitialized !== "true" && (ut(), r.dataset.intersectOnce = "true"), t.unobserve(l.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  document.querySelectorAll(".solid-gallery-container[data-intersect-once]").forEach((e) => {
    t.observe(e);
  });
}
export {
  ut as initGalleries
};
