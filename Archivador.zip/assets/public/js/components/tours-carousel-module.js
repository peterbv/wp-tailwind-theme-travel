const xt = (e, t) => e === t, $t = Symbol("solid-track"), ae = {
  equals: xt
};
let Ke = tt;
const R = 1, ce = 2, Ye = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var $ = null;
let xe = null, Ct = null, x = null, S = null, z = null, he = 0;
function le(e, t) {
  const r = x, s = $, o = e.length === 0, n = t === void 0 ? s : t, i = o ? Ye : {
    owned: null,
    cleanups: null,
    context: n ? n.context : null,
    owner: n
  }, l = o ? e : () => e(() => B(() => Q(i)));
  $ = i, x = null;
  try {
    return ee(l, !0);
  } finally {
    x = r, $ = s;
  }
}
function M(e, t) {
  t = t ? Object.assign({}, ae, t) : ae;
  const r = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, s = (o) => (typeof o == "function" && (o = o(r.value)), et(r, o));
  return [Ze.bind(r), s];
}
function q(e, t, r) {
  const s = ke(e, t, !1, R);
  Z(s);
}
function Qe(e, t, r) {
  Ke = Et;
  const s = ke(e, t, !1, R);
  s.user = !0, z ? z.push(s) : Z(s);
}
function ie(e, t, r) {
  r = r ? Object.assign({}, ae, r) : ae;
  const s = ke(e, t, !0, 0);
  return s.observers = null, s.observerSlots = null, s.comparator = r.equals || void 0, Z(s), Ze.bind(s);
}
function B(e) {
  if (x === null) return e();
  const t = x;
  x = null;
  try {
    return e();
  } finally {
    x = t;
  }
}
function _t(e) {
  Qe(() => B(e));
}
function $e(e) {
  return $ === null || ($.cleanups === null ? $.cleanups = [e] : $.cleanups.push(e)), e;
}
function Ze() {
  if (this.sources && this.state)
    if (this.state === R) Z(this);
    else {
      const e = S;
      S = null, ee(() => fe(this), !1), S = e;
    }
  if (x) {
    const e = this.observers ? this.observers.length : 0;
    x.sources ? (x.sources.push(this), x.sourceSlots.push(e)) : (x.sources = [this], x.sourceSlots = [e]), this.observers ? (this.observers.push(x), this.observerSlots.push(x.sources.length - 1)) : (this.observers = [x], this.observerSlots = [x.sources.length - 1]);
  }
  return this.value;
}
function et(e, t, r) {
  let s = e.value;
  return (!e.comparator || !e.comparator(s, t)) && (e.value = t, e.observers && e.observers.length && ee(() => {
    for (let o = 0; o < e.observers.length; o += 1) {
      const n = e.observers[o], i = xe && xe.running;
      i && xe.disposed.has(n), (i ? !n.tState : !n.state) && (n.pure ? S.push(n) : z.push(n), n.observers && rt(n)), i || (n.state = R);
    }
    if (S.length > 1e6)
      throw S = [], new Error();
  }, !1)), t;
}
function Z(e) {
  if (!e.fn) return;
  Q(e);
  const t = he;
  St(
    e,
    e.value,
    t
  );
}
function St(e, t, r) {
  let s;
  const o = $, n = x;
  x = $ = e;
  try {
    s = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = R, e.owned && e.owned.forEach(Q), e.owned = null), e.updatedAt = r + 1, st(i);
  } finally {
    x = n, $ = o;
  }
  (!e.updatedAt || e.updatedAt <= r) && (e.updatedAt != null && "observers" in e ? et(e, s) : e.value = s, e.updatedAt = r);
}
function ke(e, t, r, s = R, o) {
  const n = {
    fn: e,
    state: s,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: $,
    context: $ ? $.context : null,
    pure: r
  };
  return $ === null || $ !== Ye && ($.owned ? $.owned.push(n) : $.owned = [n]), n;
}
function ue(e) {
  if (e.state === 0) return;
  if (e.state === ce) return fe(e);
  if (e.suspense && B(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < he); )
    e.state && t.push(e);
  for (let r = t.length - 1; r >= 0; r--)
    if (e = t[r], e.state === R)
      Z(e);
    else if (e.state === ce) {
      const s = S;
      S = null, ee(() => fe(e, t[0]), !1), S = s;
    }
}
function ee(e, t) {
  if (S) return e();
  let r = !1;
  t || (S = []), z ? r = !0 : z = [], he++;
  try {
    const s = e();
    return kt(r), s;
  } catch (s) {
    r || (z = null), S = null, st(s);
  }
}
function kt(e) {
  if (S && (tt(S), S = null), e) return;
  const t = z;
  z = null, t.length && ee(() => Ke(t), !1);
}
function tt(e) {
  for (let t = 0; t < e.length; t++) ue(e[t]);
}
function Et(e) {
  let t, r = 0;
  for (t = 0; t < e.length; t++) {
    const s = e[t];
    s.user ? e[r++] = s : ue(s);
  }
  for (t = 0; t < r; t++) ue(e[t]);
}
function fe(e, t) {
  e.state = 0;
  for (let r = 0; r < e.sources.length; r += 1) {
    const s = e.sources[r];
    if (s.sources) {
      const o = s.state;
      o === R ? s !== t && (!s.updatedAt || s.updatedAt < he) && ue(s) : o === ce && fe(s, t);
    }
  }
}
function rt(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const r = e.observers[t];
    r.state || (r.state = ce, r.pure ? S.push(r) : z.push(r), r.observers && rt(r));
  }
}
function Q(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const r = e.sources.pop(), s = e.sourceSlots.pop(), o = r.observers;
      if (o && o.length) {
        const n = o.pop(), i = r.observerSlots.pop();
        s < o.length && (n.sourceSlots[i] = s, o[s] = n, r.observerSlots[s] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) Q(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) Q(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function Pt(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function st(e, t = $) {
  throw Pt(e);
}
const Tt = Symbol("fallback");
function Re(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function At(e, t, r = {}) {
  let s = [], o = [], n = [], i = 0, l = t.length > 1 ? [] : null;
  return $e(() => Re(n)), () => {
    let d = e() || [], m = d.length, p, c;
    return d[$t], B(() => {
      let E, g, H, W, G, A, L, _, k;
      if (m === 0)
        i !== 0 && (Re(n), n = [], s = [], o = [], i = 0, l && (l = [])), r.fallback && (s = [Tt], o[0] = le((te) => (n[0] = te, r.fallback())), i = 1);
      else if (i === 0) {
        for (o = new Array(m), c = 0; c < m; c++)
          s[c] = d[c], o[c] = le(F);
        i = m;
      } else {
        for (H = new Array(m), W = new Array(m), l && (G = new Array(m)), A = 0, L = Math.min(i, m); A < L && s[A] === d[A]; A++) ;
        for (L = i - 1, _ = m - 1; L >= A && _ >= A && s[L] === d[_]; L--, _--)
          H[_] = o[L], W[_] = n[L], l && (G[_] = l[L]);
        for (E = /* @__PURE__ */ new Map(), g = new Array(_ + 1), c = _; c >= A; c--)
          k = d[c], p = E.get(k), g[c] = p === void 0 ? -1 : p, E.set(k, c);
        for (p = A; p <= L; p++)
          k = s[p], c = E.get(k), c !== void 0 && c !== -1 ? (H[c] = o[p], W[c] = n[p], l && (G[c] = l[p]), c = g[c], E.set(k, c)) : n[p]();
        for (c = A; c < m; c++)
          c in H ? (o[c] = H[c], n[c] = W[c], l && (l[c] = G[c], l[c](c))) : o[c] = le(F);
        o = o.slice(0, i = m), s = d.slice(0);
      }
      return o;
    });
    function F(E) {
      if (n[c] = E, l) {
        const [g, H] = M(c);
        return l[c] = H, t(d[c], g);
      }
      return t(d[c]);
    }
  };
}
function T(e, t) {
  return B(() => e(t || {}));
}
const Lt = (e) => `Stale read from <${e}>.`;
function We(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return ie(At(() => e.each, e.children, t || void 0));
}
function I(e) {
  const t = e.keyed, r = ie(() => e.when, void 0, void 0), s = t ? r : ie(r, void 0, {
    equals: (o, n) => !o == !n
  });
  return ie(
    () => {
      const o = s();
      if (o) {
        const n = e.children;
        return typeof n == "function" && n.length > 0 ? B(
          () => n(
            t ? o : () => {
              if (!B(s)) throw Lt("Show");
              return r();
            }
          )
        ) : n;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function It(e, t, r) {
  let s = r.length, o = t.length, n = s, i = 0, l = 0, d = t[o - 1].nextSibling, m = null;
  for (; i < o || l < n; ) {
    if (t[i] === r[l]) {
      i++, l++;
      continue;
    }
    for (; t[o - 1] === r[n - 1]; )
      o--, n--;
    if (o === i) {
      const p = n < s ? l ? r[l - 1].nextSibling : r[n - l] : d;
      for (; l < n; ) e.insertBefore(r[l++], p);
    } else if (n === l)
      for (; i < o; )
        (!m || !m.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === r[n - 1] && r[l] === t[o - 1]) {
      const p = t[--o].nextSibling;
      e.insertBefore(r[l++], t[i++].nextSibling), e.insertBefore(r[--n], p), t[o] = r[n];
    } else {
      if (!m) {
        m = /* @__PURE__ */ new Map();
        let c = l;
        for (; c < n; ) m.set(r[c], c++);
      }
      const p = m.get(t[i]);
      if (p != null)
        if (l < p && p < n) {
          let c = i, F = 1, E;
          for (; ++c < o && c < n && !((E = m.get(t[c])) == null || E !== p + F); )
            F++;
          if (F > p - l) {
            const g = t[i];
            for (; l < p; ) e.insertBefore(r[l++], g);
          } else e.replaceChild(r[l++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const Ge = "_$DX_DELEGATE";
function Mt(e, t, r, s = {}) {
  let o;
  return le((n) => {
    o = n, t === document ? e() : v(t, e(), t.firstChild ? null : void 0, r);
  }, s.owner), () => {
    o(), t.textContent = "";
  };
}
function C(e, t, r, s) {
  let o;
  const n = () => {
    const l = s ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return l.innerHTML = e, r ? l.content.firstChild.firstChild : s ? l.firstChild : l.content.firstChild;
  }, i = t ? () => B(() => document.importNode(o || (o = n()), !0)) : () => (o || (o = n())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function Dt(e, t = window.document) {
  const r = t[Ge] || (t[Ge] = /* @__PURE__ */ new Set());
  for (let s = 0, o = e.length; s < o; s++) {
    const n = e[s];
    r.has(n) || (r.add(n), t.addEventListener(n, Nt));
  }
}
function D(e, t, r) {
  r == null ? e.removeAttribute(t) : e.setAttribute(t, r);
}
function Ot(e, t) {
  t == null ? e.removeAttribute("class") : e.className = t;
}
function Xe(e, t, r) {
  if (!t) return r ? D(e, "style") : t;
  const s = e.style;
  if (typeof t == "string") return s.cssText = t;
  typeof r == "string" && (s.cssText = r = void 0), r || (r = {}), t || (t = {});
  let o, n;
  for (n in r)
    t[n] == null && s.removeProperty(n), delete r[n];
  for (n in t)
    o = t[n], o !== r[n] && (s.setProperty(n, o), r[n] = o);
  return r;
}
function jt(e, t, r) {
  return B(() => e(t, r));
}
function v(e, t, r, s) {
  if (r !== void 0 && !s && (s = []), typeof t != "function") return de(e, t, s, r);
  q((o) => de(e, t(), o, r), s);
}
function Nt(e) {
  let t = e.target;
  const r = `$$${e.type}`, s = e.target, o = e.currentTarget, n = (d) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: d
  }), i = () => {
    const d = t[r];
    if (d && !t.disabled) {
      const m = t[`${r}Data`];
      if (m !== void 0 ? d.call(t, m, e) : d.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && n(t.host), !0;
  }, l = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const d = e.composedPath();
    n(d[0]);
    for (let m = 0; m < d.length - 2 && (t = d[m], !!i()); m++) {
      if (t._$host) {
        t = t._$host, l();
        break;
      }
      if (t.parentNode === o)
        break;
    }
  } else l();
  n(s);
}
function de(e, t, r, s, o) {
  for (; typeof r == "function"; ) r = r();
  if (t === r) return r;
  const n = typeof t, i = s !== void 0;
  if (e = i && r[0] && r[0].parentNode || e, n === "string" || n === "number") {
    if (n === "number" && (t = t.toString(), t === r))
      return r;
    if (i) {
      let l = r[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), r = K(e, r, s, l);
    } else
      r !== "" && typeof r == "string" ? r = e.firstChild.data = t : r = e.textContent = t;
  } else if (t == null || n === "boolean")
    r = K(e, r, s);
  else {
    if (n === "function")
      return q(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        r = de(e, l, r, s);
      }), () => r;
    if (Array.isArray(t)) {
      const l = [], d = r && Array.isArray(r);
      if (Ce(l, t, r, o))
        return q(() => r = de(e, l, r, s, !0)), () => r;
      if (l.length === 0) {
        if (r = K(e, r, s), i) return r;
      } else d ? r.length === 0 ? Je(e, l, s) : It(e, r, l) : (r && K(e), Je(e, l));
      r = l;
    } else if (t.nodeType) {
      if (Array.isArray(r)) {
        if (i) return r = K(e, r, s, t);
        K(e, r, null, t);
      } else r == null || r === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      r = t;
    }
  }
  return r;
}
function Ce(e, t, r, s) {
  let o = !1;
  for (let n = 0, i = t.length; n < i; n++) {
    let l = t[n], d = r && r[e.length], m;
    if (!(l == null || l === !0 || l === !1)) if ((m = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      o = Ce(e, l, d) || o;
    else if (m === "function")
      if (s) {
        for (; typeof l == "function"; ) l = l();
        o = Ce(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(d) ? d : [d]
        ) || o;
      } else
        e.push(l), o = !0;
    else {
      const p = String(l);
      d && d.nodeType === 3 && d.data === p ? e.push(d) : e.push(document.createTextNode(p));
    }
  }
  return o;
}
function Je(e, t, r = null) {
  for (let s = 0, o = t.length; s < o; s++) e.insertBefore(t[s], r);
}
function K(e, t, r, s) {
  if (r === void 0) return e.textContent = "";
  const o = s || document.createTextNode("");
  if (t.length) {
    let n = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const l = t[i];
      if (o !== l) {
        const d = l.parentNode === e;
        !n && !i ? d ? e.replaceChild(o, l) : e.insertBefore(o, r) : d && l.remove();
      } else n = !0;
    }
  } else e.insertBefore(o, r);
  return [o];
}
const zt = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, Bt = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const r = zt();
  return r[e] ? r[e] : e;
}, nt = {}, Ft = () => document.readyState !== "loading";
function ot(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  nt[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function lt(e) {
  return nt[e] || null;
}
function it(e, t, r = {}) {
  const s = lt(e);
  if (!s)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const o = Mt(() => s(r), t);
    return t.dataset.solidInitialized = "true", o;
  } catch (o) {
    return console.error(`Error al renderizar el componente '${e}':`, o), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${o.message}</p>
      </div>
    `, null;
  }
}
function _e() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const r = t.dataset.solidComponent;
    if (!r || t.dataset.solidInitialized === "true") return;
    let s = {};
    try {
      t.dataset.props && (s = JSON.parse(t.dataset.props));
    } catch (o) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        o
      );
    }
    it(r, t, s);
  });
}
Ft() ? _e() : document.addEventListener("DOMContentLoaded", _e);
const at = {
  registerComponent: ot,
  getComponent: lt,
  renderComponent: it,
  initComponents: _e
};
window.solidCore = at;
var Ht = /* @__PURE__ */ C("<span>"), Ut = /* @__PURE__ */ C('<div class="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2"><span class="text-base sm:text-lg font-bold"></span><span class="text-xs sm:text-sm line-through opacity-75">'), Vt = /* @__PURE__ */ C('<span class="text-base sm:text-lg font-bold">'), qt = /* @__PURE__ */ C('<p class="block text-base italic font-medium mb-1">'), Rt = /* @__PURE__ */ C('<div class="relative inline-block"><h2 class="text-2xl md:text-3xl font-bold mb-2"></h2><div class="absolute -bottom-1 left-1/2 w-16 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), Wt = /* @__PURE__ */ C('<p class="text-gray-600 mt-3 max-w-2xl mx-auto">'), Gt = /* @__PURE__ */ C('<header class="text-center mb-8 relative">'), Xt = /* @__PURE__ */ C('<button type=button class="carousel-prev absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4 sm:w-5 sm:h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7">'), Jt = /* @__PURE__ */ C('<button type=button class="carousel-next absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4 sm:w-5 sm:h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), Kt = /* @__PURE__ */ C('<div class="carousel-dots flex justify-center space-x-2 mt-6">'), Yt = /* @__PURE__ */ C('<section><div class="container mx-auto px-4 relative overflow-y-visible"><div class="tours-carousel-wrapper relative pt-3 pb-6"><div class="carousel-track overflow-x-hidden overflow-y-visible mx-6 sm:mx-8 md:mx-12 py-3"><div class="carousel-slides flex transition-transform duration-600 ease-in-out">'), Qt = /* @__PURE__ */ C('<div class="absolute top-4 right-4 px-3 py-1 rounded-full text-white font-semibold text-sm shadow-md z-10">Special Price'), Zt = /* @__PURE__ */ C('<p class="tour-subtitle text-white/90 text-sm mb-4 line-clamp-3">'), er = /* @__PURE__ */ C('<span class="flex items-center text-white/80"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z">'), tr = /* @__PURE__ */ C('<span class="flex items-center text-white/80"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 10V3L4 14h7v7l9-11h-7z">'), rr = /* @__PURE__ */ C('<div class="text-white font-bold text-center sm:text-right">'), sr = /* @__PURE__ */ C('<article class="tour-card flex-shrink-0 px-2 sm:px-3 transition-all duration-500"><div class="tour-card-inner bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-500 hover:shadow-2xl relative h-80 sm:h-96 md:h-[440px] lg:h-[500px]"><div class="tour-image absolute inset-0 overflow-hidden"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy></div><div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div><div class="tour-content absolute bottom-0 left-0 right-0 p-6 z-10"><h3 class="tour-title fancy-text text-lg font-bold mb-2 line-clamp-2 hover:text-opacity-80 transition-colors"><a class="text-white hover:text-gray-200 transition-colors"></a></h3><div class="tour-meta flex items-center justify-between text-sm text-white/80 mb-4"></div><div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-0"><a class="tour-cta-btn inline-flex items-center justify-center px-4 sm:px-6 py-2 rounded-lg text-white font-medium transition-all duration-300 hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 text-sm sm:text-base"><svg class="w-3 h-3 sm:w-4 sm:h-4 ml-2"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M14 5l7 7m0 0l-7 7m7-7H3">', !0, !1, !1), nr = /* @__PURE__ */ C('<button type=button class="carousel-dot w-3 h-3 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2">');
const or = (e) => {
  const t = (a, w = "wptbt-tours-carousel") => {
    const f = window.wptbtI18n_tours_carousel || {};
    return f[a] ? f[a] : Bt(a, w);
  }, {
    title: r = "",
    subtitle: s = "",
    description: o = "",
    tours: n = [],
    autoplaySpeed: i = 3e3,
    // Velocidad del autoplay en ms
    showDots: l = !0,
    showArrows: d = !0,
    pauseOnHover: m = !0,
    infinite: p = !0,
    slidesToShow: c = 3,
    // Número de tours visibles a la vez
    backgroundColor: F = "#F8FAFC",
    textColor: E = "#1F2937",
    accentColor: g = "#DC2626",
    secondaryColor: H = "#059669",
    fullWidth: W = !1,
    animationDirection: G = "left",
    // "left" | "right"
    // Nuevas props para SEO
    carouselId: A = "tours-carousel",
    baseUrl: L = window.location.origin + window.location.pathname
  } = e, [_, k] = M(0), [te, lr] = M(!0), [Ee, Pe] = M(null), [re, Te] = M(!1), [ir, ct] = M(!1), [ar, ut] = M(0), [Ae, Le] = M(null), [J, Y] = M(!1), [O, ft] = M(c);
  let Ie;
  const [pe, se] = M([]), dt = () => {
    if (!p || n.length === 0) return n;
    const a = Math.max(3, Math.ceil((c + 2) / n.length)), w = [];
    for (let f = 0; f < a; f++)
      w.push(...n.map((U, V) => ({
        ...U,
        uniqueId: `${U.id || V}-${f}`
        // ID único para evitar conflictos
      })));
    return w;
  }, ht = () => p ? n.length : Math.max(0, n.length - O() + 1), Me = () => {
    if (!te() || i <= 0) return;
    me();
    const a = setInterval(() => {
      (!re() || !m) && De();
    }, i);
    Pe(a);
  }, me = () => {
    Ee() && (clearInterval(Ee()), Pe(null));
  }, De = () => {
    J() || (p ? (Y(!0), k((a) => a + 1), setTimeout(() => {
      if (!J()) return;
      const w = [...pe()], f = w.shift();
      f && (w.push(f), se(w), k(0)), Y(!1);
    }, 500)) : k((a) => Math.min(a + 1, n.length - O())));
  }, pt = () => {
    if (!J())
      if (p) {
        Y(!0);
        const w = [...pe()], f = w.pop();
        f && (w.unshift(f), se(w), k(0)), setTimeout(() => {
          Y(!1);
        }, 50);
      } else
        k((a) => Math.max(a - 1, 0));
  }, mt = (a) => {
    k(a);
  };
  _t(() => {
    je();
    const a = () => je();
    window.addEventListener("resize", a), p && n.length > 0 ? (se(dt()), k(0)) : se(n), n.length > O() && Me(), ct(!0), Y(!1), $e(() => {
      window.removeEventListener("resize", a);
    });
  }), $e(() => {
    me();
  }), Qe(() => {
    re() && m ? me() : !re() && te() && !J() && setTimeout(() => {
      !re() && !J() && Me();
    }, 100);
  });
  const gt = () => {
    ut((a) => a + 1);
  }, wt = (a) => {
    const w = a.currency === "USD" ? "$" : a.currency === "PEN" ? "S/" : a.currency === "EUR" ? "€" : "Bs";
    if (!a.price && !a.price_promotion && !a.price_international && !a.price_national)
      return t("Price on request");
    if (a.price_promotion && a.price_original)
      return {
        hasPromotion: !0,
        promotional: `${w}${a.price_promotion}`,
        original: `${w}${a.price_original}`
      };
    let f = a.price_promotion || a.price_national || a.price_international || a.price;
    return f ? {
      hasPromotion: !1,
      promotional: `${w}${f}`
    } : t("Price on request");
  }, yt = (a) => {
    const w = wt(a);
    return typeof w == "string" ? (() => {
      var f = Ht();
      return v(f, w), f;
    })() : w.hasPromotion ? (() => {
      var f = Ut(), U = f.firstChild, V = U.nextSibling;
      return v(U, () => w.promotional), v(V, () => w.original), f;
    })() : (() => {
      var f = Vt();
      return v(f, () => w.promotional), f;
    })();
  }, Oe = (a) => a.permalink || `${L}tours/${a.slug || a.id}`, vt = () => {
    const a = 100 / O();
    return p ? {
      transform: `translateX(${G === "left" ? -_() * a : _() * a}%)`,
      transition: J() ? "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "none"
    } : {
      transform: `translateX(${G === "left" ? -_() * a : _() * a}%)`,
      transition: "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
    };
  }, je = () => {
    const a = window.innerWidth, w = c;
    let f;
    a < 768 ? f = Math.min(w, 1) : a < 1024 ? f = Math.min(w, 2) : f = w, f !== O() && (ft(f), _() > Math.max(0, n.length - f) && k(Math.max(0, n.length - f)));
  };
  return (() => {
    var a = Yt(), w = a.firstChild, f = w.firstChild, U = f.firstChild, V = U.firstChild;
    a.addEventListener("mouseleave", () => Te(!1)), a.addEventListener("mouseenter", () => Te(!0)), D(a, "id", A), Ot(a, `tours-carousel-component w-full py-8 md:py-12 relative ${W ? "vw-100" : ""}`), v(w, T(I, {
      when: r || s || o,
      get children() {
        var u = Gt();
        return v(u, T(I, {
          when: s,
          get children() {
            var b = qt();
            return g != null ? b.style.setProperty("color", g) : b.style.removeProperty("color"), v(b, s), b;
          }
        }), null), v(u, T(I, {
          when: r,
          get children() {
            var b = Rt(), y = b.firstChild, P = y.nextSibling, j = P.firstChild;
            return v(y, r), g != null ? P.style.setProperty("background-color", g) : P.style.removeProperty("background-color"), g != null ? j.style.setProperty("background-color", g) : j.style.removeProperty("background-color"), b;
          }
        }), null), v(u, T(I, {
          when: o,
          get children() {
            var b = Wt();
            return v(b, o), b;
          }
        }), null), u;
      }
    }), f), v(f, T(I, {
      get when() {
        return d && n.length > O();
      },
      get children() {
        return [(() => {
          var u = Xt(), b = u.firstChild;
          return u.$$click = pt, g != null ? u.style.setProperty("focus", g) : u.style.removeProperty("focus"), `2px solid ${g}20` != null ? u.style.setProperty("border", `2px solid ${g}20`) : u.style.removeProperty("border"), D(b, "stroke", E), q(() => D(u, "aria-label", t("Previous tours"))), u;
        })(), (() => {
          var u = Jt(), b = u.firstChild;
          return u.$$click = De, g != null ? u.style.setProperty("focus", g) : u.style.removeProperty("focus"), `2px solid ${g}20` != null ? u.style.setProperty("border", `2px solid ${g}20`) : u.style.removeProperty("border"), D(b, "stroke", E), q(() => D(u, "aria-label", t("Next tours"))), u;
        })()];
      }
    }), U);
    var Ne = Ie;
    return typeof Ne == "function" ? jt(Ne, V) : Ie = V, v(V, T(We, {
      get each() {
        return pe();
      },
      children: (u, b) => (() => {
        var y = sr(), P = y.firstChild, j = P.firstChild, N = j.firstChild, ne = j.nextSibling, ge = ne.nextSibling, ze = ge.firstChild, Be = ze.firstChild, oe = ze.nextSibling, Fe = oe.nextSibling, X = Fe.firstChild, bt = X.firstChild;
        return y.addEventListener("mouseleave", () => Le(null)), y.addEventListener("mouseenter", () => Le(b())), y.style.setProperty("flex-shrink", "0"), N.addEventListener("load", gt), v(P, T(I, {
          get when() {
            return u.price_promotion && u.price_original;
          },
          get children() {
            var h = Qt();
            return g != null ? h.style.setProperty("background-color", g) : h.style.removeProperty("background-color"), h;
          }
        }), ge), v(Be, () => u.title), v(ge, T(I, {
          get when() {
            return u.subtitle;
          },
          get children() {
            var h = Zt();
            return v(h, () => u.subtitle), h;
          }
        }), oe), v(oe, T(I, {
          get when() {
            return u.location;
          },
          get children() {
            var h = er();
            return h.firstChild, v(h, () => u.location, null), h;
          }
        }), null), v(oe, T(I, {
          get when() {
            return u.difficulty;
          },
          get children() {
            var h = tr();
            return h.firstChild, v(h, () => u.difficulty, null), h;
          }
        }), null), g != null ? X.style.setProperty("background-color", g) : X.style.removeProperty("background-color"), g != null ? X.style.setProperty("focus", g) : X.style.removeProperty("focus"), v(X, () => t("View Tour"), bt), v(Fe, T(I, {
          get when() {
            return u.price || u.price_promotion || u.price_international || u.price_national;
          },
          get children() {
            var h = rr();
            return v(h, () => yt(u)), h;
          }
        }), null), q((h) => {
          var we = `${100 / O()}%`, ye = `${100 / O()}%`, ve = Ae() === b() ? "translateY(-4px)" : "translateY(0)", He = u.featured_image || u.image, Ue = u.title, be = Ae() === b() ? "scale(1.1)" : "scale(1)", Ve = Oe(u), qe = Oe(u);
          return we !== h.e && ((h.e = we) != null ? y.style.setProperty("width", we) : y.style.removeProperty("width")), ye !== h.t && ((h.t = ye) != null ? y.style.setProperty("min-width", ye) : y.style.removeProperty("min-width")), ve !== h.a && ((h.a = ve) != null ? y.style.setProperty("transform", ve) : y.style.removeProperty("transform")), He !== h.o && D(N, "src", h.o = He), Ue !== h.i && D(N, "alt", h.i = Ue), be !== h.n && ((h.n = be) != null ? N.style.setProperty("transform", be) : N.style.removeProperty("transform")), Ve !== h.s && D(Be, "href", h.s = Ve), qe !== h.h && D(X, "href", h.h = qe), h;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0,
          s: void 0,
          h: void 0
        }), y;
      })()
    })), v(f, T(I, {
      get when() {
        return l && !p && n.length > O();
      },
      get children() {
        var u = Kt();
        return v(u, T(We, {
          get each() {
            return Array(ht()).fill().map((b, y) => y);
          },
          children: (b) => (() => {
            var y = nr();
            return y.$$click = () => mt(b), g != null ? y.style.setProperty("focus", g) : y.style.removeProperty("focus"), q((P) => {
              var j = _() === b ? g : "#D1D5DB", N = _() === b ? "scale(1.2)" : "scale(1)", ne = `${t("Go to slide")} ${b + 1}`;
              return j !== P.e && ((P.e = j) != null ? y.style.setProperty("background-color", j) : y.style.removeProperty("background-color")), N !== P.t && ((P.t = N) != null ? y.style.setProperty("transform", N) : y.style.removeProperty("transform")), ne !== P.a && D(y, "aria-label", P.a = ne), P;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), y;
          })()
        })), u;
      }
    }), null), q((u) => {
      var b = {
        backgroundColor: F,
        color: E,
        ...W ? {
          "margin-left": "calc(50% - 50vw)",
          "margin-right": "calc(50% - 50vw)",
          width: "100vw",
          "max-width": "100vw"
        } : {}
      }, y = vt();
      return u.e = Xe(a, b, u.e), u.t = Xe(V, y, u.t), u;
    }, {
      e: void 0,
      t: void 0
    }), a;
  })();
};
Dt(["click"]);
ot("tours-carousel", or);
function Se() {
  const e = document.querySelectorAll(".solid-tours-carousel-container");
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      let r = [];
      try {
        t.dataset.tours && (r = JSON.parse(t.dataset.tours));
      } catch (n) {
        console.warn("Error al parsear datos de tours:", n);
      }
      const s = {
        title: t.dataset.title || "",
        subtitle: t.dataset.subtitle || "",
        description: t.dataset.description || "",
        tours: r,
        autoplaySpeed: parseInt(t.dataset.autoplaySpeed || 3e3, 10),
        slidesToShow: parseInt(t.dataset.slidesToShow || 3, 10),
        showDots: t.dataset.showDots === "true",
        showArrows: t.dataset.showArrows === "true",
        pauseOnHover: t.dataset.pauseOnHover === "true",
        infinite: t.dataset.infinite === "true",
        animationDirection: t.dataset.animationDirection || "left",
        backgroundColor: t.dataset.backgroundColor || "#F8FAFC",
        textColor: t.dataset.textColor || "#1F2937",
        accentColor: t.dataset.accentColor || "#DC2626",
        secondaryColor: t.dataset.secondaryColor || "#059669",
        fullWidth: t.dataset.fullWidth === "true"
      }, o = at.renderComponent("tours-carousel", t, s);
      t._solidDispose = o, t.dataset.solidInitialized = "true", console.log("Componente de Tours Carousel con Solid.js cargado correctamente");
    } catch (r) {
      console.error(
        "Error al inicializar componente de Tours Carousel con Solid.js:",
        r
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de Tours Carousel: ${r.message}</p>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", Se) : Se();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((r) => {
        if (r.isIntersecting) {
          const s = r.target;
          s.classList.contains("solid-tours-carousel-container") && s.dataset.intersectOnce === "true" && s.dataset.solidInitialized !== "true" && (Se(), s.dataset.intersectOnce = "true"), e.unobserve(r.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  document.querySelectorAll(".solid-tours-carousel-container[data-intersect-once]").forEach((t) => {
    e.observe(t);
  });
}
export {
  Se as initToursCarousels
};
