const mt = (e, t) => e === t, wt = Symbol("solid-track"), ie = {
  equals: mt
};
let Re = Ye;
const q = 1, ae = 2, We = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
var $ = null;
let ye = null, yt = null, x = null, S = null, N = null, de = 0;
function oe(e, t) {
  const r = x, n = $, o = e.length === 0, s = t === void 0 ? n : t, i = o ? We : {
    owned: null,
    cleanups: null,
    context: s ? s.context : null,
    owner: s
  }, l = o ? e : () => e(() => B(() => Y(i)));
  $ = i, x = null;
  try {
    return Z(l, !0);
  } finally {
    x = r, $ = n;
  }
}
function O(e, t) {
  t = t ? Object.assign({}, ie, t) : ie;
  const r = {
    value: e,
    observers: null,
    observerSlots: null,
    comparator: t.equals || void 0
  }, n = (o) => (typeof o == "function" && (o = o(r.value)), Ke(r, o));
  return [Je.bind(r), n];
}
function V(e, t, r) {
  const n = $e(e, t, !1, q);
  Q(n);
}
function Ge(e, t, r) {
  Re = $t;
  const n = $e(e, t, !1, q);
  n.user = !0, N ? N.push(n) : Q(n);
}
function le(e, t, r) {
  r = r ? Object.assign({}, ie, r) : ie;
  const n = $e(e, t, !0, 0);
  return n.observers = null, n.observerSlots = null, n.comparator = r.equals || void 0, Q(n), Je.bind(n);
}
function B(e) {
  if (x === null) return e();
  const t = x;
  x = null;
  try {
    return e();
  } finally {
    x = t;
  }
}
function vt(e) {
  Ge(() => B(e));
}
function Xe(e) {
  return $ === null || ($.cleanups === null ? $.cleanups = [e] : $.cleanups.push(e)), e;
}
function Je() {
  if (this.sources && this.state)
    if (this.state === q) Q(this);
    else {
      const e = S;
      S = null, Z(() => ue(this), !1), S = e;
    }
  if (x) {
    const e = this.observers ? this.observers.length : 0;
    x.sources ? (x.sources.push(this), x.sourceSlots.push(e)) : (x.sources = [this], x.sourceSlots = [e]), this.observers ? (this.observers.push(x), this.observerSlots.push(x.sources.length - 1)) : (this.observers = [x], this.observerSlots = [x.sources.length - 1]);
  }
  return this.value;
}
function Ke(e, t, r) {
  let n = e.value;
  return (!e.comparator || !e.comparator(n, t)) && (e.value = t, e.observers && e.observers.length && Z(() => {
    for (let o = 0; o < e.observers.length; o += 1) {
      const s = e.observers[o], i = ye && ye.running;
      i && ye.disposed.has(s), (i ? !s.tState : !s.state) && (s.pure ? S.push(s) : N.push(s), s.observers && Qe(s)), i || (s.state = q);
    }
    if (S.length > 1e6)
      throw S = [], new Error();
  }, !1)), t;
}
function Q(e) {
  if (!e.fn) return;
  Y(e);
  const t = de;
  bt(
    e,
    e.value,
    t
  );
}
function bt(e, t, r) {
  let n;
  const o = $, s = x;
  x = $ = e;
  try {
    n = e.fn(t);
  } catch (i) {
    return e.pure && (e.state = q, e.owned && e.owned.forEach(Y), e.owned = null), e.updatedAt = r + 1, Ze(i);
  } finally {
    x = s, $ = o;
  }
  (!e.updatedAt || e.updatedAt <= r) && (e.updatedAt != null && "observers" in e ? Ke(e, n) : e.value = n, e.updatedAt = r);
}
function $e(e, t, r, n = q, o) {
  const s = {
    fn: e,
    state: n,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: t,
    owner: $,
    context: $ ? $.context : null,
    pure: r
  };
  return $ === null || $ !== We && ($.owned ? $.owned.push(s) : $.owned = [s]), s;
}
function ce(e) {
  if (e.state === 0) return;
  if (e.state === ae) return ue(e);
  if (e.suspense && B(e.suspense.inFallback)) return e.suspense.effects.push(e);
  const t = [e];
  for (; (e = e.owner) && (!e.updatedAt || e.updatedAt < de); )
    e.state && t.push(e);
  for (let r = t.length - 1; r >= 0; r--)
    if (e = t[r], e.state === q)
      Q(e);
    else if (e.state === ae) {
      const n = S;
      S = null, Z(() => ue(e, t[0]), !1), S = n;
    }
}
function Z(e, t) {
  if (S) return e();
  let r = !1;
  t || (S = []), N ? r = !0 : N = [], de++;
  try {
    const n = e();
    return xt(r), n;
  } catch (n) {
    r || (N = null), S = null, Ze(n);
  }
}
function xt(e) {
  if (S && (Ye(S), S = null), e) return;
  const t = N;
  N = null, t.length && Z(() => Re(t), !1);
}
function Ye(e) {
  for (let t = 0; t < e.length; t++) ce(e[t]);
}
function $t(e) {
  let t, r = 0;
  for (t = 0; t < e.length; t++) {
    const n = e[t];
    n.user ? e[r++] = n : ce(n);
  }
  for (t = 0; t < r; t++) ce(e[t]);
}
function ue(e, t) {
  e.state = 0;
  for (let r = 0; r < e.sources.length; r += 1) {
    const n = e.sources[r];
    if (n.sources) {
      const o = n.state;
      o === q ? n !== t && (!n.updatedAt || n.updatedAt < de) && ce(n) : o === ae && ue(n, t);
    }
  }
}
function Qe(e) {
  for (let t = 0; t < e.observers.length; t += 1) {
    const r = e.observers[t];
    r.state || (r.state = ae, r.pure ? S.push(r) : N.push(r), r.observers && Qe(r));
  }
}
function Y(e) {
  let t;
  if (e.sources)
    for (; e.sources.length; ) {
      const r = e.sources.pop(), n = e.sourceSlots.pop(), o = r.observers;
      if (o && o.length) {
        const s = o.pop(), i = r.observerSlots.pop();
        n < o.length && (s.sourceSlots[i] = n, o[n] = s, r.observerSlots[n] = i);
      }
    }
  if (e.tOwned) {
    for (t = e.tOwned.length - 1; t >= 0; t--) Y(e.tOwned[t]);
    delete e.tOwned;
  }
  if (e.owned) {
    for (t = e.owned.length - 1; t >= 0; t--) Y(e.owned[t]);
    e.owned = null;
  }
  if (e.cleanups) {
    for (t = e.cleanups.length - 1; t >= 0; t--) e.cleanups[t]();
    e.cleanups = null;
  }
  e.state = 0;
}
function Ct(e) {
  return e instanceof Error ? e : new Error(typeof e == "string" ? e : "Unknown error", {
    cause: e
  });
}
function Ze(e, t = $) {
  throw Ct(e);
}
const _t = Symbol("fallback");
function Fe(e) {
  for (let t = 0; t < e.length; t++) e[t]();
}
function St(e, t, r = {}) {
  let n = [], o = [], s = [], i = 0, l = t.length > 1 ? [] : null;
  return Xe(() => Fe(s)), () => {
    let f = e() || [], h = f.length, d, a;
    return f[wt], B(() => {
      let k, p, F, R, W, T, L, _, E;
      if (h === 0)
        i !== 0 && (Fe(s), s = [], n = [], o = [], i = 0, l && (l = [])), r.fallback && (n = [_t], o[0] = oe((ee) => (s[0] = ee, r.fallback())), i = 1);
      else if (i === 0) {
        for (o = new Array(h), a = 0; a < h; a++)
          n[a] = f[a], o[a] = oe(z);
        i = h;
      } else {
        for (F = new Array(h), R = new Array(h), l && (W = new Array(h)), T = 0, L = Math.min(i, h); T < L && n[T] === f[T]; T++) ;
        for (L = i - 1, _ = h - 1; L >= T && _ >= T && n[L] === f[_]; L--, _--)
          F[_] = o[L], R[_] = s[L], l && (W[_] = l[L]);
        for (k = /* @__PURE__ */ new Map(), p = new Array(_ + 1), a = _; a >= T; a--)
          E = f[a], d = k.get(E), p[a] = d === void 0 ? -1 : d, k.set(E, a);
        for (d = T; d <= L; d++)
          E = n[d], a = k.get(E), a !== void 0 && a !== -1 ? (F[a] = o[d], R[a] = s[d], l && (W[a] = l[d]), a = p[a], k.set(E, a)) : s[d]();
        for (a = T; a < h; a++)
          a in F ? (o[a] = F[a], s[a] = R[a], l && (l[a] = W[a], l[a](a))) : o[a] = oe(z);
        o = o.slice(0, i = h), n = f.slice(0);
      }
      return o;
    });
    function z(k) {
      if (s[a] = k, l) {
        const [p, F] = O(a);
        return l[a] = F, t(f[a], p);
      }
      return t(f[a]);
    }
  };
}
function A(e, t) {
  return B(() => e(t || {}));
}
const kt = (e) => `Stale read from <${e}>.`;
function He(e) {
  const t = "fallback" in e && {
    fallback: () => e.fallback
  };
  return le(St(() => e.each, e.children, t || void 0));
}
function I(e) {
  const t = e.keyed, r = le(() => e.when, void 0, void 0), n = t ? r : le(r, void 0, {
    equals: (o, s) => !o == !s
  });
  return le(
    () => {
      const o = n();
      if (o) {
        const s = e.children;
        return typeof s == "function" && s.length > 0 ? B(
          () => s(
            t ? o : () => {
              if (!B(n)) throw kt("Show");
              return r();
            }
          )
        ) : s;
      }
      return e.fallback;
    },
    void 0,
    void 0
  );
}
function Et(e, t, r) {
  let n = r.length, o = t.length, s = n, i = 0, l = 0, f = t[o - 1].nextSibling, h = null;
  for (; i < o || l < s; ) {
    if (t[i] === r[l]) {
      i++, l++;
      continue;
    }
    for (; t[o - 1] === r[s - 1]; )
      o--, s--;
    if (o === i) {
      const d = s < n ? l ? r[l - 1].nextSibling : r[s - l] : f;
      for (; l < s; ) e.insertBefore(r[l++], d);
    } else if (s === l)
      for (; i < o; )
        (!h || !h.has(t[i])) && t[i].remove(), i++;
    else if (t[i] === r[s - 1] && r[l] === t[o - 1]) {
      const d = t[--o].nextSibling;
      e.insertBefore(r[l++], t[i++].nextSibling), e.insertBefore(r[--s], d), t[o] = r[s];
    } else {
      if (!h) {
        h = /* @__PURE__ */ new Map();
        let a = l;
        for (; a < s; ) h.set(r[a], a++);
      }
      const d = h.get(t[i]);
      if (d != null)
        if (l < d && d < s) {
          let a = i, z = 1, k;
          for (; ++a < o && a < s && !((k = h.get(t[a])) == null || k !== d + z); )
            z++;
          if (z > d - l) {
            const p = t[i];
            for (; l < d; ) e.insertBefore(r[l++], p);
          } else e.replaceChild(r[l++], t[i++]);
        } else i++;
      else t[i++].remove();
    }
  }
}
const Ue = "_$DX_DELEGATE";
function Pt(e, t, r, n = {}) {
  let o;
  return oe((s) => {
    o = s, t === document ? e() : v(t, e(), t.firstChild ? null : void 0, r);
  }, n.owner), () => {
    o(), t.textContent = "";
  };
}
function C(e, t, r, n) {
  let o;
  const s = () => {
    const l = n ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
    return l.innerHTML = e, r ? l.content.firstChild.firstChild : n ? l.firstChild : l.content.firstChild;
  }, i = t ? () => B(() => document.importNode(o || (o = s()), !0)) : () => (o || (o = s())).cloneNode(!0);
  return i.cloneNode = i, i;
}
function At(e, t = window.document) {
  const r = t[Ue] || (t[Ue] = /* @__PURE__ */ new Set());
  for (let n = 0, o = e.length; n < o; n++) {
    const s = e[n];
    r.has(s) || (r.add(s), t.addEventListener(s, It));
  }
}
function D(e, t, r) {
  r == null ? e.removeAttribute(t) : e.setAttribute(t, r);
}
function Tt(e, t) {
  t == null ? e.removeAttribute("class") : e.className = t;
}
function Ve(e, t, r) {
  if (!t) return r ? D(e, "style") : t;
  const n = e.style;
  if (typeof t == "string") return n.cssText = t;
  typeof r == "string" && (n.cssText = r = void 0), r || (r = {}), t || (t = {});
  let o, s;
  for (s in r)
    t[s] == null && n.removeProperty(s), delete r[s];
  for (s in t)
    o = t[s], o !== r[s] && (n.setProperty(s, o), r[s] = o);
  return r;
}
function Lt(e, t, r) {
  return B(() => e(t, r));
}
function v(e, t, r, n) {
  if (r !== void 0 && !n && (n = []), typeof t != "function") return fe(e, t, n, r);
  V((o) => fe(e, t(), o, r), n);
}
function It(e) {
  let t = e.target;
  const r = `$$${e.type}`, n = e.target, o = e.currentTarget, s = (f) => Object.defineProperty(e, "target", {
    configurable: !0,
    value: f
  }), i = () => {
    const f = t[r];
    if (f && !t.disabled) {
      const h = t[`${r}Data`];
      if (h !== void 0 ? f.call(t, h, e) : f.call(t, e), e.cancelBubble) return;
    }
    return t.host && typeof t.host != "string" && !t.host._$host && t.contains(e.target) && s(t.host), !0;
  }, l = () => {
    for (; i() && (t = t._$host || t.parentNode || t.host); ) ;
  };
  if (Object.defineProperty(e, "currentTarget", {
    configurable: !0,
    get() {
      return t || document;
    }
  }), e.composedPath) {
    const f = e.composedPath();
    s(f[0]);
    for (let h = 0; h < f.length - 2 && (t = f[h], !!i()); h++) {
      if (t._$host) {
        t = t._$host, l();
        break;
      }
      if (t.parentNode === o)
        break;
    }
  } else l();
  s(n);
}
function fe(e, t, r, n, o) {
  for (; typeof r == "function"; ) r = r();
  if (t === r) return r;
  const s = typeof t, i = n !== void 0;
  if (e = i && r[0] && r[0].parentNode || e, s === "string" || s === "number") {
    if (s === "number" && (t = t.toString(), t === r))
      return r;
    if (i) {
      let l = r[0];
      l && l.nodeType === 3 ? l.data !== t && (l.data = t) : l = document.createTextNode(t), r = J(e, r, n, l);
    } else
      r !== "" && typeof r == "string" ? r = e.firstChild.data = t : r = e.textContent = t;
  } else if (t == null || s === "boolean")
    r = J(e, r, n);
  else {
    if (s === "function")
      return V(() => {
        let l = t();
        for (; typeof l == "function"; ) l = l();
        r = fe(e, l, r, n);
      }), () => r;
    if (Array.isArray(t)) {
      const l = [], f = r && Array.isArray(r);
      if (ve(l, t, r, o))
        return V(() => r = fe(e, l, r, n, !0)), () => r;
      if (l.length === 0) {
        if (r = J(e, r, n), i) return r;
      } else f ? r.length === 0 ? qe(e, l, n) : Et(e, r, l) : (r && J(e), qe(e, l));
      r = l;
    } else if (t.nodeType) {
      if (Array.isArray(r)) {
        if (i) return r = J(e, r, n, t);
        J(e, r, null, t);
      } else r == null || r === "" || !e.firstChild ? e.appendChild(t) : e.replaceChild(t, e.firstChild);
      r = t;
    }
  }
  return r;
}
function ve(e, t, r, n) {
  let o = !1;
  for (let s = 0, i = t.length; s < i; s++) {
    let l = t[s], f = r && r[e.length], h;
    if (!(l == null || l === !0 || l === !1)) if ((h = typeof l) == "object" && l.nodeType)
      e.push(l);
    else if (Array.isArray(l))
      o = ve(e, l, f) || o;
    else if (h === "function")
      if (n) {
        for (; typeof l == "function"; ) l = l();
        o = ve(
          e,
          Array.isArray(l) ? l : [l],
          Array.isArray(f) ? f : [f]
        ) || o;
      } else
        e.push(l), o = !0;
    else {
      const d = String(l);
      f && f.nodeType === 3 && f.data === d ? e.push(f) : e.push(document.createTextNode(d));
    }
  }
  return o;
}
function qe(e, t, r = null) {
  for (let n = 0, o = t.length; n < o; n++) e.insertBefore(t[n], r);
}
function J(e, t, r, n) {
  if (r === void 0) return e.textContent = "";
  const o = n || document.createTextNode("");
  if (t.length) {
    let s = !1;
    for (let i = t.length - 1; i >= 0; i--) {
      const l = t[i];
      if (o !== l) {
        const f = l.parentNode === e;
        !s && !i ? f ? e.replaceChild(o, l) : e.insertBefore(o, r) : f && l.remove();
      } else s = !0;
    }
  } else e.insertBefore(o, r);
  return [o];
}
const Dt = () => {
  const e = {};
  return Object.keys(window).forEach((t) => {
    t.startsWith("wptbtI18n_") && Object.assign(e, window[t]);
  }), window.wptbtI18n && Object.assign(e, window.wptbtI18n), e;
}, Ot = (e, t) => {
  if (typeof window.wp < "u" && typeof window.wp.i18n < "u")
    return window.wp.i18n.__(e, t || "wp-tailwind-blocks");
  const r = Dt();
  return r[e] ? r[e] : e;
}, et = {}, jt = () => document.readyState !== "loading";
function tt(e, t) {
  if (typeof e != "string" || e.trim() === "") {
    console.error("El nombre del componente debe ser una cadena válida");
    return;
  }
  if (typeof t != "function") {
    console.error(
      `El componente ${e} debe ser una función válida de Solid.js`
    );
    return;
  }
  et[e] = t, console.log(`Componente '${e}' registrado correctamente`);
}
function rt(e) {
  return et[e] || null;
}
function nt(e, t, r = {}) {
  const n = rt(e);
  if (!n)
    return console.error(`El componente '${e}' no está registrado`), null;
  if (!t || !(t instanceof HTMLElement))
    return console.error(
      "Se requiere un contenedor DOM válido para renderizar el componente"
    ), null;
  try {
    for (; t.firstChild; )
      t.removeChild(t.firstChild);
    const o = Pt(() => n(r), t);
    return t.dataset.solidInitialized = "true", o;
  } catch (o) {
    return console.error(`Error al renderizar el componente '${e}':`, o), t.innerHTML = `
      <div class="p-4 bg-red-100 text-red-800 rounded-md">
        <p>Error al cargar el componente: ${o.message}</p>
      </div>
    `, null;
  }
}
function be() {
  const e = document.querySelectorAll("[data-solid-component]");
  e.length !== 0 && e.forEach((t) => {
    const r = t.dataset.solidComponent;
    if (!r || t.dataset.solidInitialized === "true") return;
    let n = {};
    try {
      t.dataset.props && (n = JSON.parse(t.dataset.props));
    } catch (o) {
      console.warn(
        `Error al parsear propiedades para ${r}:`,
        o
      );
    }
    nt(r, t, n);
  });
}
jt() ? be() : document.addEventListener("DOMContentLoaded", be);
const st = {
  registerComponent: tt,
  getComponent: rt,
  renderComponent: nt,
  initComponents: be
};
window.solidCore = st;
var Mt = /* @__PURE__ */ C("<span>"), Nt = /* @__PURE__ */ C('<div class="flex items-center gap-2"><span class="text-lg font-bold"></span><span class="text-sm line-through opacity-75">'), Bt = /* @__PURE__ */ C('<span class="text-lg font-bold">'), zt = /* @__PURE__ */ C('<p class="block text-base italic font-medium mb-1">'), Ft = /* @__PURE__ */ C('<div class="relative inline-block"><h2 class="text-2xl md:text-3xl font-bold mb-2"></h2><div class="absolute -bottom-1 left-1/2 w-16 h-0.5 transform -translate-x-1/2"aria-hidden=true><div class="absolute left-1/2 top-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2">'), Ht = /* @__PURE__ */ C('<p class="text-gray-600 mt-3 max-w-2xl mx-auto">'), Ut = /* @__PURE__ */ C('<header class="text-center mb-8 relative">'), Vt = /* @__PURE__ */ C('<button type=button class="carousel-prev absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-5 h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 19l-7-7 7-7">'), qt = /* @__PURE__ */ C('<button type=button class="carousel-next absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300 hover:shadow-xl hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-5 h-5"fill=none viewBox="0 0 24 24"aria-hidden=true><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M9 5l7 7-7 7">'), Rt = /* @__PURE__ */ C('<div class="carousel-dots flex justify-center space-x-2 mt-6">'), Wt = /* @__PURE__ */ C('<section><div class="container mx-auto px-4 relative"><div class="tours-carousel-wrapper relative"><div class="carousel-track overflow-hidden mx-12"><div class="carousel-slides flex transition-transform duration-600 ease-in-out">'), Gt = /* @__PURE__ */ C('<div class="absolute top-4 right-4 px-3 py-1 rounded-full text-white font-semibold text-sm shadow-md z-10">Special Price'), Xt = /* @__PURE__ */ C('<p class="tour-subtitle text-white/90 text-sm mb-4 line-clamp-3">'), Jt = /* @__PURE__ */ C('<span class="flex items-center text-white/80"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M15 11a3 3 0 11-6 0 3 3 0 016 0z">'), Kt = /* @__PURE__ */ C('<span class="flex items-center text-white/80"><svg class="w-4 h-4 mr-1"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M13 10V3L4 14h7v7l9-11h-7z">'), Yt = /* @__PURE__ */ C('<div class="text-white font-bold">'), Qt = /* @__PURE__ */ C('<article class="tour-card flex-shrink-0 px-3 transition-all duration-500"><div class="tour-card-inner bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-500 hover:shadow-2xl relative h-96 md:h-[500px]"><div class="tour-image absolute inset-0 overflow-hidden"><img class="w-full h-full object-cover transition-transform duration-700"loading=lazy></div><div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div><div class="tour-content absolute bottom-0 left-0 right-0 p-6 z-10"><h3 class="tour-title fancy-text text-lg font-bold mb-2 line-clamp-2 hover:text-opacity-80 transition-colors"><a class="text-white hover:text-gray-200 transition-colors"></a></h3><div class="tour-meta flex items-center justify-between text-sm text-white/80 mb-4"></div><div class="flex items-center justify-between"><a class="tour-cta-btn inline-flex items-center justify-center px-6 py-2 rounded-lg text-white font-medium transition-all duration-300 hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2"><svg class="w-4 h-4 ml-2"fill=none stroke=currentColor viewBox="0 0 24 24"><path stroke-linecap=round stroke-linejoin=round stroke-width=2 d="M14 5l7 7m0 0l-7 7m7-7H3">', !0, !1, !1), Zt = /* @__PURE__ */ C('<button type=button class="carousel-dot w-3 h-3 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2">');
const er = (e) => {
  const t = (c, y = "wptbt-tours-carousel") => {
    const m = window.wptbtI18n_tours_carousel || {};
    return m[c] ? m[c] : Ot(c, y);
  }, {
    title: r = "",
    subtitle: n = "",
    description: o = "",
    tours: s = [],
    autoplaySpeed: i = 3e3,
    // Velocidad del autoplay en ms
    showDots: l = !0,
    showArrows: f = !0,
    pauseOnHover: h = !0,
    infinite: d = !0,
    slidesToShow: a = 3,
    // Número de tours visibles a la vez
    backgroundColor: z = "#F8FAFC",
    textColor: k = "#1F2937",
    accentColor: p = "#DC2626",
    secondaryColor: F = "#059669",
    fullWidth: R = !1,
    animationDirection: W = "left",
    // "left" | "right"
    // Nuevas props para SEO
    carouselId: T = "tours-carousel",
    baseUrl: L = window.location.origin + window.location.pathname
  } = e, [_, E] = O(0), [ee, tr] = O(!0), [Ce, _e] = O(null), [te, Se] = O(!1), [rr, ot] = O(!1), [nr, lt] = O(0), [ke, Ee] = O(null), [X, K] = O(!1);
  let Pe;
  const [he, re] = O([]), it = () => {
    if (!d || s.length === 0) return s;
    const c = Math.max(3, Math.ceil((a + 2) / s.length)), y = [];
    for (let m = 0; m < c; m++)
      y.push(...s.map((H, U) => ({
        ...H,
        uniqueId: `${H.id || U}-${m}`
        // ID único para evitar conflictos
      })));
    return y;
  }, at = () => d ? s.length : Math.max(0, s.length - a + 1), Ae = () => {
    if (!ee() || i <= 0) return;
    pe();
    const c = setInterval(() => {
      (!te() || !h) && Te();
    }, i);
    _e(c);
  }, pe = () => {
    Ce() && (clearInterval(Ce()), _e(null));
  }, Te = () => {
    X() || (d ? (K(!0), E((c) => c + 1), setTimeout(() => {
      if (!X()) return;
      const y = [...he()], m = y.shift();
      m && (y.push(m), re(y), E(0)), K(!1);
    }, 500)) : E((c) => Math.min(c + 1, s.length - a)));
  }, ct = () => {
    if (!X())
      if (d) {
        K(!0);
        const y = [...he()], m = y.pop();
        m && (y.unshift(m), re(y), E(0)), setTimeout(() => {
          K(!1);
        }, 50);
      } else
        E((c) => Math.max(c - 1, 0));
  }, ut = (c) => {
    E(c);
  };
  vt(() => {
    d && s.length > 0 ? (re(it()), E(0)) : re(s), s.length > a && Ae(), ot(!0), K(!1);
  }), Xe(() => {
    pe();
  }), Ge(() => {
    te() && h ? pe() : !te() && ee() && !X() && setTimeout(() => {
      !te() && !X() && Ae();
    }, 100);
  });
  const ft = () => {
    lt((c) => c + 1);
  }, dt = (c) => {
    const y = c.currency === "USD" ? "$" : c.currency === "PEN" ? "S/" : c.currency === "EUR" ? "€" : "Bs";
    if (!c.price && !c.price_promotion && !c.price_international && !c.price_national)
      return t("Price on request");
    if (c.price_promotion && c.price_original)
      return {
        hasPromotion: !0,
        promotional: `${y}${c.price_promotion}`,
        original: `${y}${c.price_original}`
      };
    let m = c.price_promotion || c.price_national || c.price_international || c.price;
    return m ? {
      hasPromotion: !1,
      promotional: `${y}${m}`
    } : t("Price on request");
  }, ht = (c) => {
    const y = dt(c);
    return typeof y == "string" ? (() => {
      var m = Mt();
      return v(m, y), m;
    })() : y.hasPromotion ? (() => {
      var m = Nt(), H = m.firstChild, U = H.nextSibling;
      return v(H, () => y.promotional), v(U, () => y.original), m;
    })() : (() => {
      var m = Bt();
      return v(m, () => y.promotional), m;
    })();
  }, Le = (c) => c.permalink || `${L}tours/${c.slug || c.id}`, pt = () => {
    const c = 100 / a;
    return d ? {
      transform: `translateX(${W === "left" ? -_() * c : _() * c}%)`,
      transition: X() ? "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)" : "none"
    } : {
      transform: `translateX(${W === "left" ? -_() * c : _() * c}%)`,
      transition: "transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
    };
  };
  return (() => {
    var c = Wt(), y = c.firstChild, m = y.firstChild, H = m.firstChild, U = H.firstChild;
    c.addEventListener("mouseleave", () => Se(!1)), c.addEventListener("mouseenter", () => Se(!0)), D(c, "id", T), Tt(c, `tours-carousel-component w-full py-8 md:py-12 relative ${R ? "vw-100" : ""}`), v(y, A(I, {
      when: r || n || o,
      get children() {
        var u = Ut();
        return v(u, A(I, {
          when: n,
          get children() {
            var b = zt();
            return p != null ? b.style.setProperty("color", p) : b.style.removeProperty("color"), v(b, n), b;
          }
        }), null), v(u, A(I, {
          when: r,
          get children() {
            var b = Ft(), w = b.firstChild, P = w.nextSibling, j = P.firstChild;
            return v(w, r), p != null ? P.style.setProperty("background-color", p) : P.style.removeProperty("background-color"), p != null ? j.style.setProperty("background-color", p) : j.style.removeProperty("background-color"), b;
          }
        }), null), v(u, A(I, {
          when: o,
          get children() {
            var b = Ht();
            return v(b, o), b;
          }
        }), null), u;
      }
    }), m), v(m, A(I, {
      get when() {
        return f && s.length > a;
      },
      get children() {
        return [(() => {
          var u = Vt(), b = u.firstChild;
          return u.$$click = ct, p != null ? u.style.setProperty("focus", p) : u.style.removeProperty("focus"), `2px solid ${p}20` != null ? u.style.setProperty("border", `2px solid ${p}20`) : u.style.removeProperty("border"), D(b, "stroke", k), V(() => D(u, "aria-label", t("Previous tours"))), u;
        })(), (() => {
          var u = qt(), b = u.firstChild;
          return u.$$click = Te, p != null ? u.style.setProperty("focus", p) : u.style.removeProperty("focus"), `2px solid ${p}20` != null ? u.style.setProperty("border", `2px solid ${p}20`) : u.style.removeProperty("border"), D(b, "stroke", k), V(() => D(u, "aria-label", t("Next tours"))), u;
        })()];
      }
    }), H);
    var Ie = Pe;
    return typeof Ie == "function" ? Lt(Ie, U) : Pe = U, v(U, A(He, {
      get each() {
        return he();
      },
      children: (u, b) => (() => {
        var w = Qt(), P = w.firstChild, j = P.firstChild, M = j.firstChild, ne = j.nextSibling, ge = ne.nextSibling, De = ge.firstChild, Oe = De.firstChild, se = De.nextSibling, je = se.nextSibling, G = je.firstChild, gt = G.firstChild;
        return w.addEventListener("mouseleave", () => Ee(null)), w.addEventListener("mouseenter", () => Ee(b())), `${100 / a}%` != null ? w.style.setProperty("width", `${100 / a}%`) : w.style.removeProperty("width"), `${100 / a}%` != null ? w.style.setProperty("min-width", `${100 / a}%`) : w.style.removeProperty("min-width"), w.style.setProperty("flex-shrink", "0"), M.addEventListener("load", ft), v(P, A(I, {
          get when() {
            return u.price_promotion && u.price_original;
          },
          get children() {
            var g = Gt();
            return p != null ? g.style.setProperty("background-color", p) : g.style.removeProperty("background-color"), g;
          }
        }), ge), v(Oe, () => u.title), v(ge, A(I, {
          get when() {
            return u.subtitle;
          },
          get children() {
            var g = Xt();
            return v(g, () => u.subtitle), g;
          }
        }), se), v(se, A(I, {
          get when() {
            return u.location;
          },
          get children() {
            var g = Jt();
            return g.firstChild, v(g, () => u.location, null), g;
          }
        }), null), v(se, A(I, {
          get when() {
            return u.difficulty;
          },
          get children() {
            var g = Kt();
            return g.firstChild, v(g, () => u.difficulty, null), g;
          }
        }), null), p != null ? G.style.setProperty("background-color", p) : G.style.removeProperty("background-color"), p != null ? G.style.setProperty("focus", p) : G.style.removeProperty("focus"), v(G, () => t("View Tour"), gt), v(je, A(I, {
          get when() {
            return u.price || u.price_promotion || u.price_international || u.price_national;
          },
          get children() {
            var g = Yt();
            return v(g, () => ht(u)), g;
          }
        }), null), V((g) => {
          var me = ke() === b() ? "translateY(-8px)" : "translateY(0)", Me = u.featured_image || u.image, Ne = u.title, we = ke() === b() ? "scale(1.1)" : "scale(1)", Be = Le(u), ze = Le(u);
          return me !== g.e && ((g.e = me) != null ? w.style.setProperty("transform", me) : w.style.removeProperty("transform")), Me !== g.t && D(M, "src", g.t = Me), Ne !== g.a && D(M, "alt", g.a = Ne), we !== g.o && ((g.o = we) != null ? M.style.setProperty("transform", we) : M.style.removeProperty("transform")), Be !== g.i && D(Oe, "href", g.i = Be), ze !== g.n && D(G, "href", g.n = ze), g;
        }, {
          e: void 0,
          t: void 0,
          a: void 0,
          o: void 0,
          i: void 0,
          n: void 0
        }), w;
      })()
    })), v(m, A(I, {
      get when() {
        return l && !d && s.length > a;
      },
      get children() {
        var u = Rt();
        return v(u, A(He, {
          get each() {
            return Array(at()).fill().map((b, w) => w);
          },
          children: (b) => (() => {
            var w = Zt();
            return w.$$click = () => ut(b), p != null ? w.style.setProperty("focus", p) : w.style.removeProperty("focus"), V((P) => {
              var j = _() === b ? p : "#D1D5DB", M = _() === b ? "scale(1.2)" : "scale(1)", ne = `${t("Go to slide")} ${b + 1}`;
              return j !== P.e && ((P.e = j) != null ? w.style.setProperty("background-color", j) : w.style.removeProperty("background-color")), M !== P.t && ((P.t = M) != null ? w.style.setProperty("transform", M) : w.style.removeProperty("transform")), ne !== P.a && D(w, "aria-label", P.a = ne), P;
            }, {
              e: void 0,
              t: void 0,
              a: void 0
            }), w;
          })()
        })), u;
      }
    }), null), V((u) => {
      var b = {
        backgroundColor: z,
        color: k,
        ...R ? {
          "margin-left": "calc(50% - 50vw)",
          "margin-right": "calc(50% - 50vw)",
          width: "100vw",
          "max-width": "100vw"
        } : {}
      }, w = pt();
      return u.e = Ve(c, b, u.e), u.t = Ve(U, w, u.t), u;
    }, {
      e: void 0,
      t: void 0
    }), c;
  })();
};
At(["click"]);
tt("tours-carousel", er);
function xe() {
  const e = document.querySelectorAll(".solid-tours-carousel-container");
  e.length !== 0 && e.forEach((t) => {
    try {
      if (t.dataset.solidInitialized === "true") return;
      let r = [];
      try {
        t.dataset.tours && (r = JSON.parse(t.dataset.tours));
      } catch (s) {
        console.warn("Error al parsear datos de tours:", s);
      }
      const n = {
        title: t.dataset.title || "",
        subtitle: t.dataset.subtitle || "",
        description: t.dataset.description || "",
        tours: r,
        autoplaySpeed: parseInt(t.dataset.autoplaySpeed || 3e3, 10),
        slidesToShow: parseInt(t.dataset.slidesToShow || 3, 10),
        showDots: t.dataset.showDots === "true",
        showArrows: t.dataset.showArrows === "true",
        pauseOnHover: t.dataset.pauseOnHover === "true",
        infinite: t.dataset.infinite === "true",
        animationDirection: t.dataset.animationDirection || "left",
        backgroundColor: t.dataset.backgroundColor || "#F8FAFC",
        textColor: t.dataset.textColor || "#1F2937",
        accentColor: t.dataset.accentColor || "#DC2626",
        secondaryColor: t.dataset.secondaryColor || "#059669",
        fullWidth: t.dataset.fullWidth === "true"
      }, o = st.renderComponent("tours-carousel", t, n);
      t._solidDispose = o, t.dataset.solidInitialized = "true", console.log("Componente de Tours Carousel con Solid.js cargado correctamente");
    } catch (r) {
      console.error(
        "Error al inicializar componente de Tours Carousel con Solid.js:",
        r
      ), t.innerHTML = `
        <div class="p-4 bg-red-100 text-red-800 rounded-md">
          <p>Error al cargar el componente de Tours Carousel: ${r.message}</p>
        </div>
      `;
    }
  });
}
document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", xe) : xe();
if ("IntersectionObserver" in window) {
  const e = new IntersectionObserver(
    (t) => {
      t.forEach((r) => {
        if (r.isIntersecting) {
          const n = r.target;
          n.classList.contains("solid-tours-carousel-container") && n.dataset.intersectOnce === "true" && n.dataset.solidInitialized !== "true" && (xe(), n.dataset.intersectOnce = "true"), e.unobserve(r.target);
        }
      });
    },
    { threshold: 0.25 }
  );
  document.querySelectorAll(".solid-tours-carousel-container[data-intersect-once]").forEach((t) => {
    e.observe(t);
  });
}
export {
  xe as initToursCarousels
};
